// ==========================================================================
//  DATA DEFINITIONS (Lore Added, NEW CHARACTERS ADDED)
// ==========================================================================
const squabblemon = {
  Rasta: {
    name: "Rastamon",
    type: "Plant",
    ability: "Natural Cure",
    stats: { hp: 200, attack: 150, defense: 130, speed: 130 },
    sprite: "https://i.imgur.com/OH3B6YT.png",
    lore: "Chill vibes only. Prefers napping in sunbeams to actual squabbling.",
    moves: [
      {
        name: "Dreadlock Whip",
        type: "Plant",
        power: 50,
        accuracy: 95,
        pp: 15,
        maxPP: 15,
        effect: "none",
      },
      {
        name: "6 Rasclaat Eggs?!",
        type: "Fire",
        power: 70,
        accuracy: 85,
        pp: 10,
        maxPP: 10,
        effect: "sleep",
      },
      {
        name: "Irie Recharge",
        type: "Plant",
        power: 0,
        accuracy: 100,
        pp: 10,
        maxPP: 10,
        effect: "heal",
      },
    ],
  },
  Fitness: {
    name: "Fitness Bro",
    type: "Fire",
    ability: "Guts",
    stats: { hp: 230, attack: 170, defense: 130, speed: 120 },
    sprite: "https://i.imgur.com/YeMI4sr.png",
    lore: "NEVER skips leg day. Or arm day. Or any day. Fueled by pure gainz.",
    moves: [
      {
        name: "Squat Slap",
        type: "Normal",
        power: 45,
        accuracy: 90,
        pp: 15,
        maxPP: 15,
        effect: "none",
      },
      {
        name: "Protein Powder Burn",
        type: "Fire",
        power: 45,
        accuracy: 85,
        pp: 5,
        maxPP: 5,
        effect: "burn",
      },
      {
        name: "Flex on ‘Em",
        type: "Normal",
        power: 0,
        accuracy: 100,
        pp: 10,
        maxPP: 10,
        effect: "raiseDefense",
      },
    ],
  },
  Techy: {
    name: "Techy",
    type: "Electric",
    ability: "Download",
    stats: { hp: 170, attack: 150, defense: 150, speed: 190 },
    sprite: "https://i.imgur.com/m7Rup7S.png",
    lore: "Runs on caffeine and pure code. Might DDoS you for fun.",
    moves: [
      {
        name: "Keyboard Smash",
        type: "Electric",
        power: 60,
        accuracy: 90,
        pp: 15,
        maxPP: 15,
        effect: "paralysis",
      },
      {
        name: "404 Headshot",
        type: "Dark",
        power: 80,
        accuracy: 80,
        pp: 5,
        maxPP: 5,
        effect: "none",
      },
      {
        name: "Caffeine Overload",
        type: "Electric",
        power: 0,
        accuracy: 100,
        pp: 10,
        maxPP: 10,
        effect: "raiseSpeed",
      },
    ],
  },
  Vibe: {
    name: "Cool Vibe YN",
    type: "Water",
    ability: "Torrent",
    stats: { hp: 190, attack: 170, defense: 130, speed: 150 },
    sprite: "https://i.imgur.com/2n71aSJ.png",
    lore: "Smooth operator. Always hydrated and ready to slide into the DMs.",
    moves: [
      {
        name: "Splash Dat Ass",
        type: "Water",
        power: 50,
        accuracy: 95,
        pp: 15,
        maxPP: 15,
        effect: "wet",
      },
      {
        name: "Wave Check Fade",
        type: "Water",
        power: 70,
        accuracy: 85,
        pp: 10,
        maxPP: 10,
        effect: "sleep",
      },
      {
        name: "Call Girls for Gang",
        type: "Water",
        power: 0,
        accuracy: 100,
        pp: 5,
        maxPP: 5,
        effect: "heal",
      },
    ],
  },
  "9-5": {
    name: "9-5 Homie",
    type: "Rock",
    ability: "Sturdy",
    stats: { hp: 210, attack: 130, defense: 150, speed: 180 },
    sprite: "https://i.imgur.com/UkE9crR.png",
    lore: "Just trying to make it to Friday. Powered by lukewarm coffee.",
    moves: [
      {
        name: "Cubicle Clapback",
        type: "Normal",
        power: 50,
        accuracy: 90,
        pp: 15,
        maxPP: 15,
        effect: "none",
      },
      {
        name: "Overtime Overload",
        type: "Electric",
        power: 65,
        accuracy: 85,
        pp: 10,
        maxPP: 10,
        effect: "paralysis",
      },
      {
        name: "PTO Prayer",
        type: "Normal",
        power: 0,
        accuracy: 100,
        pp: 5,
        maxPP: 5,
        effect: "heal",
      },
    ],
  },
  "All Jokes Roaster": {
    name: "All Jokes Roaster",
    type: "Air",
    ability: "Prankster",
    stats: { hp: 180, attack: 170, defense: 110, speed: 180 },
    sprite: "https://i.imgur.com/qRtemtQ.png",
    lore: "Can't take anything seriously. Will ratio you into oblivion.",
    moves: [
      {
        name: "Ratio’d Receipts",
        type: "Air",
        power: 40,
        accuracy: 100,
        pp: 15,
        maxPP: 15,
        effect: "none",
      },
      {
        name: "Clapback Inferno",
        type: "Fire",
        power: 55,
        accuracy: 90,
        pp: 10,
        maxPP: 10,
        effect: "burn",
      },
      {
        name: "Dodge the Shade",
        type: "Air",
        power: 0,
        accuracy: 100,
        pp: 15,
        maxPP: 15,
        effect: "raiseSpeed",
      },
    ],
  },
  "Closet Nerd": {
    name: "Closet Nerd",
    type: "Dark",
    ability: "Unaware",
    stats: { hp: 200, attack: 140, defense: 100, speed: 170 },
    sprite: "https://i.imgur.com/knA2Yxz.png",
    lore: "Knows more about anime than you know about yourself. Don't ask.",
    moves: [
      {
        name: "Manga Smack",
        type: "Normal",
        power: 60,
        accuracy: 95,
        pp: 15,
        maxPP: 15,
        effect: "none",
      },
      {
        name: "Weeb Roast",
        type: "Fire",
        power: 55,
        accuracy: 85,
        pp: 10,
        maxPP: 10,
        effect: "burn",
      },
      {
        name: "Incognito Glow-Up",
        type: "Dark",
        power: 0,
        accuracy: 100,
        pp: 10,
        maxPP: 10,
        effect: "raiseDefense",
      },
    ],
  },
  Dysfunctional: {
    name: "Dysfunctional YN",
    type: "Fire",
    ability: "Anger Point",
    stats: { hp: 160, attack: 190, defense: 90, speed: 140 },
    sprite: "https://i.imgur.com/yA0lUbo.png",
    lore: "A walking disaster, but somehow still functioning. Handle with care.",
    moves: [
      {
        name: "Hot Mess Slap",
        type: "Fire",
        power: 55,
        accuracy: 90,
        pp: 15,
        maxPP: 15,
        effect: "burn",
      },
      {
        name: "Chaos Cookout",
        type: "Fire",
        power: 85,
        accuracy: 75,
        pp: 5,
        maxPP: 5,
        effect: "recoil",
      },
      {
        name: "Trainwreck Tantrum",
        type: "Normal",
        power: 0,
        accuracy: 100,
        pp: 15,
        maxPP: 15,
        effect: "raiseAttack",
      },
    ],
  },
  "Functional Addict": {
    name: "Functional Addict",
    type: "Water",
    ability: "Hydration",
    stats: { hp: 200, attack: 150, defense: 100, speed: 130 },
    sprite: "https://i.imgur.com/G3xfSjU.png",
    lore: "Runs on liquids that aren't always water. Surprisingly coherent.",
    moves: [
      {
        name: "Sip & Splash",
        type: "Water",
        power: 45,
        accuracy: 100,
        pp: 15,
        maxPP: 15,
        effect: "wet",
      },
      {
        name: "Henny Haze",
        type: "Dark",
        power: 60,
        accuracy: 90,
        pp: 10,
        maxPP: 10,
        effect: "sleep",
      },
      {
        name: "Sober Up Sis",
        type: "Normal",
        power: 0,
        accuracy: 100,
        pp: 5,
        maxPP: 5,
        effect: "heal",
      },
    ],
  },
  "Gamer Unemployed": {
    name: "Gamer Unemployed",
    type: "Dark",
    ability: "Truant",
    stats: { hp: 210, attack: 150, defense: 190, speed: 150 },
    sprite: "https://i.imgur.com/b5pnt7o.png",
    lore: "Peak performance involves Cheetos and minimal movement. Hasn't seen the sun in weeks.",
    moves: [
      {
        name: "Cheeto Dust Jab",
        type: "Normal",
        power: 50,
        accuracy: 95,
        pp: 15,
        maxPP: 15,
        effect: "none",
      },
      {
        name: "WiFi Crash",
        type: "Electric",
        power: 65,
        accuracy: 85,
        pp: 10,
        maxPP: 10,
        effect: "paralysis",
      },
      {
        name: "Couch Potato Power",
        type: "Normal",
        power: 0,
        accuracy: 100,
        pp: 10,
        maxPP: 10,
        effect: "raiseAttack",
      },
    ],
  },
  Gamer: {
    name: "Gamer",
    type: "Dark",
    ability: "Technician",
    stats: { hp: 190, attack: 195, defense: 90, speed: 180 },
    sprite: "https://i.imgur.com/vFvQKap.png",
    lore: "All about the K/D ratio. Might rage quit if things go badly.",
    moves: [
      {
        name: "Controller Chuck",
        type: "Normal",
        power: 50,
        accuracy: 95,
        pp: 15,
        maxPP: 15,
        effect: "none",
      },
      {
        name: "Loud Ass Logout",
        type: "Dark",
        power: 85,
        accuracy: 85,
        pp: 5,
        maxPP: 5,
        effect: "recoil",
      },
      {
        name: "Tryhard Trigger",
        type: "Normal",
        power: 0,
        accuracy: 100,
        pp: 10,
        maxPP: 10,
        effect: "raiseAttack",
      },
    ],
  },
  "Houseless Hustler": {
    name: "Homeless YN",
    type: "Rock",
    ability: "Sand Veil",
    stats: { hp: 220, attack: 170, defense: 110, speed: 120 },
    sprite: "https://i.imgur.com/LRVrieF.png",
    lore: "Resourceful survivor. Turns trash into treasure, and opponents into dust.",
    moves: [
      {
        name: "Cardboard Cut",
        type: "Normal",
        power: 50,
        accuracy: 95,
        pp: 15,
        maxPP: 15,
        effect: "none",
      },
      {
        name: "Sidewalk Stomp",
        type: "Rock",
        power: 60,
        accuracy: 85,
        pp: 10,
        maxPP: 10,
        effect: "lowerSpeed",
      },
      {
        name: "Hustle Hard",
        type: "Normal",
        power: 0,
        accuracy: 100,
        pp: 10,
        maxPP: 10,
        effect: "raiseDefense",
      },
    ],
  },
  "Night Stalker": {
    name: "Serial Shooter",
    type: "Dark",
    ability: "Intimidate",
    stats: { hp: 160, attack: 200, defense: 100, speed: 180 },
    sprite: "https://i.imgur.com/Kwe1HpA.png",
    lore: "Moves in the shadows. Definitely gives off creepy vibes.",
    moves: [
      {
        name: "Knife Nightcap",
        type: "Dark",
        power: 45,
        accuracy: 85,
        pp: 10,
        maxPP: 10,
        effect: "sleep",
      },
      {
        name: "Stalk & Snooze",
        type: "Dark",
        power: 90,
        accuracy: 65,
        pp: 5,
        maxPP: 5,
        effect: "none",
      },
      {
        name: "Killer Instinct",
        type: "Dark",
        power: 0,
        accuracy: 100,
        pp: 10,
        maxPP: 10,
        effect: "raiseAttack",
      },
    ],
  },
  Earthy: {
    name: "Earthy Dude",
    type: "Plant",
    ability: "Chlorophyll",
    stats: { hp: 210, attack: 120, defense: 200, speed: 100 },
    sprite: "https://i.imgur.com/1SuHgnZ.png",
    lore: "One with nature. Probably smells faintly of patchouli and dirt.",
    moves: [
      {
        name: "Flea Market Maul",
        type: "Plant",
        power: 40,
        accuracy: 100,
        pp: 15,
        maxPP: 15,
        effect: "wet",
      },
      {
        name: "Woke Boulder Yeet",
        type: "Rock",
        power: 65,
        accuracy: 85,
        pp: 10,
        maxPP: 10,
        effect: "lowerSpeed",
      },
      {
        name: "Shea Butter Armor",
        type: "Plant",
        power: 0,
        accuracy: 100,
        pp: 10,
        maxPP: 10,
        effect: "raiseDefense",
      },
    ],
  },
  "Techbro Rich": {
    name: "Techbro Rich",
    type: "Electric",
    ability: "Motor Drive",
    stats: { hp: 180, attack: 180, defense: 120, speed: 190 },
    sprite: "https://i.imgur.com/eJpAcGt.png",
    lore: "Disrupting the Squabblemon scene, one NFT at a time. Very rich.",
    moves: [
      {
        name: "Tesla Taze",
        type: "Electric",
        power: 55,
        accuracy: 90,
        pp: 15,
        maxPP: 15,
        effect: "paralysis",
      },
      {
        name: "NFT Nuke",
        type: "Normal",
        power: 85,
        accuracy: 70,
        pp: 5,
        maxPP: 5,
        effect: "none",
      },
      {
        name: "VC Funded Flex",
        type: "Electric",
        power: 0,
        accuracy: 100,
        pp: 10,
        maxPP: 10,
        effect: "raiseSpeed",
      },
    ],
  },
  Plug: {
    name: "Plug",
    type: "Electric",
    ability: "Static",
    stats: { hp: 190, attack: 160, defense: 130, speed: 170 },
    sprite: "https://i.imgur.com/Mal7dZQ.png",
    lore: "Got the connections. Always knows a guy who knows a guy.",
    moves: [
      {
        name: "Pack Seizure",
        type: "Electric",
        power: 45,
        accuracy: 85,
        pp: 15,
        maxPP: 15,
        effect: "paralysis",
      },
      {
        name: "Bad Deal",
        type: "Electric",
        power: 60,
        accuracy: 85,
        pp: 10,
        maxPP: 10,
        effect: "lowerSpeed",
      },
      {
        name: "Trap Phone Ting",
        type: "Dark",
        power: 0,
        accuracy: 100,
        pp: 10,
        maxPP: 10,
        effect: "raiseAttack",
      },
    ],
  },
  Scammer: {
    name: "Scammer",
    type: "Dark",
    ability: "Imposter",
    stats: { hp: 170, attack: 150, defense: 110, speed: 190 },
    sprite: "https://i.imgur.com/tvAPXl8.png",
    lore: "Probably not who they say they are. Watch your wallet.",
    moves: [
      {
        name: "Catfish Swipe",
        type: "Dark",
        power: 50,
        accuracy: 95,
        pp: 15,
        maxPP: 15,
        effect: "none",
      },
      {
        name: "Cash App Cripple",
        type: "Electric",
        power: 75,
        accuracy: 80,
        pp: 10,
        maxPP: 10,
        effect: "paralysis",
      },
      {
        name: "Fake Link Flick",
        type: "Dark",
        power: 5,
        accuracy: 100,
        pp: 10,
        maxPP: 10,
        effect: "raiseSpeed",
      },
    ],
  },
  "Smoker Jr": {
    name: "Smoker Jr",
    type: "Air",
    ability: "Cloud Nine",
    stats: { hp: 190, attack: 120, defense: 130, speed: 150 },
    sprite: "https://i.imgur.com/vdaAi7h.png",
    lore: "Permanently hazy. Might forget what move it was using mid-battle.",
    moves: [
      {
        name: "Cloud Cough",
        type: "Air",
        power: 40,
        accuracy: 100,
        pp: 15,
        maxPP: 15,
        effect: "lowerAccuracy",
      },
      {
        name: "Bong Rip Blast",
        type: "Fire",
        power: 45,
        accuracy: 95,
        pp: 15,
        maxPP: 15,
        effect: "sleep",
      },
      {
        name: "Smoke Screen Stunt",
        type: "Normal",
        power: 0,
        accuracy: 100,
        pp: 10,
        maxPP: 10,
        effect: "raiseDefense",
      },
    ],
  },
  Suburban: {
    name: "Suburban Kid",
    type: "Normal",
    ability: "Simple",
    stats: { hp: 180, attack: 130, defense: 140, speed: 200 },
    sprite: "https://i.imgur.com/LKtVgCn.png",
    lore: "Just grilled. Enjoys well-maintained lawns and quiet evenings.",
    moves: [
      {
        name: "Lawnmower Lash",
        type: "Plant",
        power: 50,
        accuracy: 95,
        pp: 15,
        maxPP: 15,
        effect: "none",
      },
      {
        name: "BBQ Blaze",
        type: "Fire",
        power: 55,
        accuracy: 85,
        pp: 10,
        maxPP: 10,
        effect: "burn",
      },
      {
        name: "Picket Fence",
        type: "Normal",
        power: 0,
        accuracy: 100,
        pp: 10,
        maxPP: 10,
        effect: "raiseDefense",
      },
    ],
  },
  "Ganger Blue": {
    name: "Ganger Blue",
    type: "Dark",
    ability: "Intimidate",
    stats: { hp: 190, attack: 170, defense: 130, speed: 150 },
    sprite: "https://i.imgur.com/7THvTR0.png",
    lore: "Claims this block. Don't make eye contact for too long.",
    moves: [
      {
        name: "Crip Corner Check",
        type: "Dark",
        power: 60,
        accuracy: 95,
        pp: 15,
        maxPP: 15,
        effect: "paralysis",
      },
      {
        name: "Mean Mug",
        type: "Normal",
        power: 0,
        accuracy: 100,
        pp: 10,
        maxPP: 10,
        effect: "lowerAttack",
      },
      {
        name: "Block Buster DP",
        type: "Rock",
        power: 75,
        accuracy: 85,
        pp: 10,
        maxPP: 10,
        effect: "none",
      },
    ],
  },
  "Ganger Red": {
    name: "Ganger Red",
    type: "Fire",
    ability: "Guts",
    stats: { hp: 180, attack: 165, defense: 120, speed: 165 },
    sprite: "https://i.imgur.com/DP4RBGB.png",
    lore: "Rival crew. Always ready to throw down and prove their turf is better.",
    moves: [
      {
        name: "Rival Rush",
        type: "Normal",
        power: 45,
        accuracy: 100,
        pp: 15,
        maxPP: 15,
        effect: "none",
      },
      {
        name: "Heated Exchange",
        type: "Fire",
        power: 80,
        accuracy: 75,
        pp: 10,
        maxPP: 10,
        effect: "burn",
      },
      {
        name: "Tag Team",
        type: "Normal",
        power: 0,
        accuracy: 100,
        pp: 10,
        maxPP: 10,
        effect: "raiseAttack",
      },
    ],
  },
  Coone: {
    name: "Coone",
    type: "Dark",
    ability: "Trader",
    stats: { hp: 170, attack: 130, defense: 110, speed: 195 },
    sprite: "https://i.imgur.com/CSvkuRk.png",
    lore: "Loves chaos and garbage cans. Surprisingly quick.",
    moves: [
      {
        name: "Side Switcher",
        type: "Normal",
        power: 40,
        accuracy: 100,
        pp: 20,
        maxPP: 20,
        effect: "none",
      },
      {
        name: "Imposter Syndrome",
        type: "Normal",
        power: 0,
        accuracy: 100,
        pp: 5,
        maxPP: 5,
        effect: "heal",
      },
      {
        name: "red pill pop",
        type: "Dark",
        power: 65,
        accuracy: 85,
        pp: 15,
        maxPP: 15,
        effect: "lowerDefense",
      },
    ],
  },
  Rapper: {
    name: "Rapper",
    type: "Normal",
    ability: "Technician",
    stats: { hp: 200, attack: 160, defense: 130, speed: 140 },
    sprite: "https://i.imgur.com/HcWNwJT.png",
    lore: "Spits hot fire... lyrically, mostly. Always working on the next mixtape.",
    moves: [
      {
        name: "Mic Drop",
        type: "Normal",
        power: 60,
        accuracy: 85,
        pp: 10,
        maxPP: 10,
        effect: "none",
      },
      {
        name: "5 Fingers of Death",
        type: "Air",
        power: 70,
        accuracy: 65,
        pp: 5,
        maxPP: 5,
        effect: "raiseSpeed",
      },
      {
        name: "Groupie Rush",
        type: "Dark",
        power: 60,
        accuracy: 100,
        pp: 10,
        maxPP: 10,
        effect: "lowerAttack",
      },
      {
        name: "Social Media Crashout",
        type: "Dark",
        power: 60,
        accuracy: 100,
        pp: 10,
        maxPP: 10,
        effect: "recoil",
      },
    ],
  },
  "Bikelife YN": {
    name: "Bikelife YN",
    type: "Electric",
    ability: "Motor Drive",
    stats: { hp: 185, attack: 150, defense: 125, speed: 190 },
    sprite: "https://i.imgur.com/i6xU3C7.png",
    lore: "Swerving through traffic and battles. Speed is everything.",
    moves: [
      {
        name: "Wheelie Whip",
        type: "Normal",
        power: 55,
        accuracy: 95,
        pp: 15,
        maxPP: 15,
        effect: "none",
      },
      {
        name: "Exhaust Burn",
        type: "Fire",
        power: 60,
        accuracy: 90,
        pp: 10,
        maxPP: 10,
        effect: "burn",
      },
      {
        name: "Ride Out",
        type: "Electric",
        power: 0,
        accuracy: 100,
        pp: 10,
        maxPP: 10,
        effect: "raiseSpeed",
      },
      {
        name: "High-Speed Trick",
        type: "normal",
        power: 60,
        accuracy: 100,
        pp: 10,
        maxPP: 10,
        effect: "lowerAttack",
      },
    ],
  },
  Hooper: {
    name: "Hooper",
    type: "Fire",
    ability: "Guts",
    stats: { hp: 210, attack: 175, defense: 140, speed: 135 },
    sprite: "https://i.imgur.com/nmL74YQ.png",
    lore: "Got handles and heart. Plays above the rim and talks trash.",
    moves: [
      {
        name: "Ankle Breaker Combo",
        type: "Normal",
        power: 55,
        accuracy: 85,
        pp: 15,
        maxPP: 15,
        effect: "lowerSpeed",
      },
      {
        name: "Heat Check",
        type: "Fire",
        power: 75,
        accuracy: 75,
        pp: 10,
        maxPP: 10,
        effect: "none",
      },
      {
        name: "Hoop Harder",
        type: "Normal",
        power: 70,
        accuracy: 85,
        pp: 10,
        maxPP: 10,
        effect: "flinch",
      },
      {
        name: "Support Bunny",
        type: "normal",
        power: 0,
        accuracy: 100,
        pp: 5,
        maxPP: 5,
        effect: "heal",
      },
    ],
  },
  "Live Streamer": {
    name: "Live Streamer",
    type: "Electric",
    ability: "Technician",
    stats: { hp: 175, attack: 120, defense: 115, speed: 185 },
    sprite: "https://i.imgur.com/3rCsqGF.png",
    lore: "'Yo, chat! Smash that like button!' Always online, never AFK.",
    moves: [
      {
        name: "Stan Sumbission",
        type: "Normal",
        power: 40,
        accuracy: 100,
        pp: 20,
        maxPP: 20,
        effect: "none",
      },
      {
        name: "Follower Frenzy",
        type: "Normal",
        power: 10,
        accuracy: 100,
        pp: 10,
        maxPP: 10,
        effect: "raiseSpeed",
      },
      {
        name: "Donate Debuff",
        type: "Dark",
        power: 50,
        accuracy: 90,
        pp: 10,
        maxPP: 10,
        effect: "lowerDefense",
      },
    ],
  },
  "Officer Oink": {
    name: "Officer Oink",
    type: "Normal",
    ability: "Intimidate",
    stats: { hp: 230, attack: 150, defense: 160, speed: 90 },
    sprite: "https://i.imgur.com/AdCwGHp.png",
    lore: "Laying down the law, one donut break at a time.",
    moves: [
      {
        name: "Profile",
        type: "Normal",
        power: 65,
        accuracy: 95,
        pp: 15,
        maxPP: 15,
        effect: "none",
      },
      {
        name: "Body Cam Crusher",
        type: "Normal",
        power: 0,
        accuracy: 90,
        pp: 10,
        maxPP: 10,
        effect: "lowerSpeed",
      },
      {
        name: "Backup Call",
        type: "Normal",
        power: 0,
        accuracy: 100,
        pp: 5,
        maxPP: 5,
        effect: "raiseDefense",
      },
    ],
  },
  Snitch: {
    name: "Snitch",
    type: "Dark",
    ability: "Unaware",
    stats: { hp: 160, attack: 110, defense: 100, speed: 175 },
    sprite: "https://i.imgur.com/OOZM6eu.png",
    lore: "Always listening, always watching. Tells everything.",
    moves: [
      {
        name: "Tattle Tale",
        type: "Dark",
        power: 30,
        accuracy: 100,
        pp: 20,
        maxPP: 20,
        effect: "lowerDefense",
      },
      {
        name: "Run, Hide & Hate",
        type: "Normal",
        power: 0,
        accuracy: 100,
        pp: 15,
        maxPP: 15,
        effect: "raiseEvasion",
      },
      {
        name: "Expose Weakness",
        type: "Dark",
        power: 50,
        accuracy: 100,
        pp: 15,
        maxPP: 15,
        effect: "none",
      },
    ],
  },
  Cornball: {
    name: "Cornball",
    type: "Normal",
    ability: "Simple",
    stats: { hp: 210, attack: 100, defense: 120, speed: 110 },
    sprite: "https://i.imgur.com/yUUA3of.png",
    lore: "Tries way too hard to be cool. Tells terrible jokes.",
    moves: [
      {
        name: "Dad Joke",
        type: "Normal",
        power: 40,
        accuracy: 95,
        pp: 20,
        maxPP: 20,
        effect: "none",
      },
      {
        name: "Scare the Hoes",
        type: "Normal",
        power: 0,
        accuracy: 90,
        pp: 10,
        maxPP: 10,
        effect: "lowerSpeed",
      },
      {
        name: "Try Hard",
        type: "Normal",
        power: 60,
        accuracy: 90,
        pp: 15,
        maxPP: 15,
        effect: "recoil",
        effectChance: 0.1,
      },
      {
        name: "Trauma Dump",
        type: "Dark",
        power: 15,
        accuracy: 100,
        pp: 5,
        maxPP: 5,
        effect: "heal",
      },
    ],
  },
  "Jittery Junkman": {
    name: "Cracked Head",
    type: "Poison",
    ability: "Technician",
    stats: { hp: 150, attack: 140, defense: 90, speed: 195 },
    sprite: "https://i.imgur.com/cl7GtvK.png",
    lore: "Moves fast, thinks faster... maybe too fast. Always looking for the next score.",
    moves: [
      {
        name: "Scrap Scramble",
        type: "Poison",
        power: 40,
        accuracy: 100,
        pp: 15,
        maxPP: 20,
        effect: "poison",
      },
      {
        name: "Twitchy Takedown",
        type: "Normal",
        power: 60,
        accuracy: 85,
        pp: 15,
        maxPP: 15,
        effect: "none",
      },
      {
        name: "Fiending Focus",
        type: "Poison",
        power: 0,
        accuracy: 100,
        pp: 10,
        maxPP: 10,
        effect: "raiseSpeed",
      },
      {
        name: "Pookie Push",
        type: "Rock",
        power: 60,
        accuracy: 100,
        pp: 10,
        maxPP: 10,
        effect: "raiseEvasion",
      },
    ],
  },
};
const abilities = {
  "Natural Cure": "Heals status conditions upon switching out.",
  Guts: "Attack is boosted by 50% if statused (burn, paralysis, sleep, poison, freeze).",
  Download:
    "Compares opponent's Defense and Special Defense. Raises user's Attack or Special Attack corresponding to the lower stat.",
  Torrent: "Powers up Water-type moves by 50% when at 1/3 HP or less.",
  Sturdy:
    "If the Pokémon is at full HP, it survives one hit with at least 1 HP. Immune to OHKO moves.",
  Prankster: "Status moves have +1 priority.",
  Unaware:
    "Ignores the opponent's stat changes when attacking or taking damage.",
  "Anger Point": "Maximizes Attack stat if hit by a critical hit.",
  Hydration: "Heals status conditions at the end of the turn if it is raining.",
  Truant: "The Pokémon loafs around and can't attack every other turn.",
  Technician: "Powers up moves with a base power of 60 or less by 50%.",
  "Sand Veil":
    "Boosts Evasion by 25% during a sandstorm. Immune to sandstorm damage.",
  Intimidate:
    "Lowers the opponent's Attack stat by one stage upon entering battle.",
  Chlorophyll: "Doubles Speed stat during harsh sunlight.",
  "Motor Drive":
    "Raises Speed by one stage if hit by an Electric-type move; grants immunity to Electric-type moves.",
  Static: "30% chance of paralyzing an opponent when hit by a contact move.",
  Imposter: "Transforms into the opponent upon entering battle.",
  "Cloud Nine": "Negates all weather effects while the Pokémon is active.",
  Simple: "The Pokémon's stat changes are doubled.",
  "Poison Touch":
    "30% chance of poisoning the target when using a contact move.",
};
const typeAdvantages = {
  Fire: { strong: ["Plant"], weak: ["Water", "Rock"] },
  Plant: { strong: ["Rock", "Water"], weak: ["Fire", "Air"] },
  Rock: { strong: ["Electric", "Fire", "Air"], weak: ["Plant", "Water"] },
  Water: { strong: ["Fire", "Rock"], weak: ["Electric", "Plant"] },
  Electric: { strong: ["Water", "Air"], weak: ["Rock", "Plant"] },
  Air: { strong: ["Plant"], weak: ["Electric", "Rock"] },
  Dark: { strong: [], weak: ["Normal"] },
  Normal: { strong: [], weak: ["Rock", "Poison"] },
  Poison: { strong: ["Plant"], weak: ["Rock", "Ground"] },
}; // Added Poison
const battleBackgrounds = [
  "https://i.imgur.com/PamT0O9.png",
  "https://i.imgur.com/EQqkKah.jpeg",
  "https://i.imgur.com/f9mzhRU.png",
  "https://i.imgur.com/5vRDadh.png",
  "https://i.imgur.com/m9NrIpy.png",
  "https://i.imgur.com/pEs4HJ5.jpeg",
  "https://i.imgur.com/VTeIMuN.png",
  "https://i.imgur.com/LhIaHVy.png",
  "https://i.imgur.com/OdKFwva.png",
];
const effects = {
  fireAttack: "https://i.gifer.com/PVYG.gif",
  fireStatus: "https://i.gifer.com/PVYG.gif",
  waterAttack: "https://i.gifer.com/YlW9.gif",
  waterStatus: "https://i.gifer.com/X5Nb.gif",
  waterBuff: "https://i.gifer.com/3q60.gif",
  electricAttack: "https://i.gifer.com/Z9pp.gif",
  electricStatus: "https://i.gifer.com/Z9pp.gif",
  plantAttack: "https://i.imgur.com/iOeteHQ.png",
  rockAttack: "https://i.gifer.com/56i2.gif",
  airAttack: "https://i.gifer.com/3klP.gif",
  darkAttack: "https://i.gifer.com/WXfF.gif",
  darkStatus: "https://i.gifer.com/3iCN.gif",
  darkBuff: "https://i.gifer.com/Dzpn.gif",
  normalAttack: "https://i.gifer.com/Yecx.gif",
  poisonAttack: "https://i.gifer.com/X5Nb.gif",
  poisonStatus: "https://i.gifer.com/3iCN.gif",
  sleepStatus: "https://i.imgur.com/hFYQ7oe.gif",
  healEffect: "https://i.imgur.com/684Bb2r.gif",
  lightEffect: "https://i.gifer.com/OkV7.gif",
  genericBuff: "https://i.gifer.com/XZ5L.gif",
  genericDebuff: "https://i.gifer.com/3iCN.gif",
  blastAttack: "https://i.gifer.com/XZ5N.gif",
  moneyAttack: "https://i.gifer.com/xt.gif",
  earthyAttack: "https://i.gifer.com/56i2.gif",
  scammerBuff: "https://i.gifer.com/3BBS.gif",
  scammerEffect: "https://i.gifer.com/y7.gif",
  nineToFiveBuff: "https://i.gifer.com/yvL.gif",
  plugEffect: "https://i.gifer.com/3vIR.gif",
  plugDysSerBuff: "https://i.gifer.com/YyBN.gif",
  smokerFuncBuff: "https://i.gifer.com/1pOk.gif",
  winHands: "https://i.gifer.com/1uIf.gif",
  winScreen: "https://i.gifer.com/ZJF0.gif",
  loseScreen: "https://i.gifer.com/Z6W8.gif",
  jcoleHeal: "https://i.imgur.com/684Bb2r.gif",
  nbaBuff: "https://i.gifer.com/YyBN.gif",
  weedSleep: "https://i.imgur.com/hFYQ7oe.gif",
};

// ==========================================================================
//  BATTLE STATE VARIABLES
// ==========================================================================
let playerTeam = [];
let opponentTeam = [];
let activePlayerIndex = 0;
let activeOpponentIndex = 0;
let playerCurrentHP = 0;
let opponentCurrentHP = 0;
let playerStages = { attack: 0, defense: 0, speed: 0, accuracy: 0, evasion: 0 };
let opponentStages = {
  attack: 0,
  defense: 0,
  speed: 0,
  accuracy: 0,
  evasion: 0,
};
let playerStatus = { type: null, turns: 0 };
let opponentStatus = { type: null, turns: 0 };
let itemsUsed = {
  jcole: false,
  nbayoungboy: false,
  weed: false,
  crashdummy: false,
};
let crashDummyActive = false;
let isPlayerTurn = true;
let playerMove = null;
let fadeCounter = 0;
let floatingLogTimeout = null;

// ==========================================================================
//  DOM ELEMENTS
// ==========================================================================
let dom = {};

// ==========================================================================
//  INITIALIZATION & TEAM SELECTION
// ==========================================================================
document.addEventListener("DOMContentLoaded", () => {
  cacheDOMElements();
  populateCharacterList();
  setupTeamSlots();
  dom.startButton.onclick = () => {
    if (playerTeam.length === 3) {
      startBattle();
    }
  };
});
function cacheDOMElements() {
  dom.selectionScreen = document.getElementById("selection-screen");
  dom.battleScreen = document.getElementById("battle-screen");
  dom.gameOverScreen = document.getElementById("game-over");
  dom.switchScreen = document.getElementById("switch-screen");
  dom.characterList = document.getElementById("character-list");
  dom.teamSlots = document.getElementById("team-slots");
  dom.startButton = document.getElementById("start-battle");
  dom.playerSprite = document.getElementById("player-sprite");
  dom.opponentSprite = document.getElementById("opponent-sprite");
  dom.playerName = document.getElementById("player-name");
  dom.opponentName = document.getElementById("opponent-name");
  dom.playerHP = document.getElementById("player-hp");
  dom.opponentHP = document.getElementById("opponent-hp");
  dom.playerHPFill = document.getElementById("player-hp-fill");
  dom.opponentHPFill = document.getElementById("opponent-hp-fill");
  dom.playerStatusIcon = document.getElementById("player-status-icon");
  dom.opponentStatusIcon = document.getElementById("opponent-status-icon");
  dom.movesDiv = document.getElementById("moves");
  dom.itemsDiv = document.getElementById("items");
  dom.battleLog = document.getElementById("battle-log");
  dom.switchOptions = document.getElementById("switch-options");
  dom.gameOverMessage = document.getElementById("game-over-message");
  dom.fadeCounter = document.getElementById("fade-counter");
  dom.winLoseGif = document.getElementById("win-lose-gif");
  dom.continueButton = document.getElementById("continue-battle");
  dom.moveTooltip = document.getElementById("move-tooltip");
  dom.floatingLog = document.getElementById("floating-log");
  dom.fadeDisplay = document.getElementById("fade-display");
  dom.opponentInfoText = document.getElementById("opponent-info-text");
}
function populateCharacterList() {
  if (!dom.characterList) return;
  dom.characterList.innerHTML = "";
  if (!squabblemon || Object.keys(squabblemon).length === 0) return;
  Object.values(squabblemon).forEach((mon) => {
    try {
      if (!mon || typeof mon !== "object") return;
      const card = document.createElement("div");
      card.className = "character-card";
      card.innerHTML = `<img src="${mon.sprite || ""}" alt="${
        mon.name || "Unknown"
      }"><p>${mon.name || "???"}</p>`;
      card.onclick = () => selectTeamMember(mon, card);
      dom.characterList.appendChild(card);
    } catch (e) {
      console.error(`Error creating card for ${mon?.name || "Unknown"}:`, e);
    }
  });
}
function setupTeamSlots() {
  dom.teamSlots.innerHTML = "";
  for (let i = 0; i < 3; i++) {
    const slot = document.createElement("div");
    slot.className = "team-slot";
    dom.teamSlots.appendChild(slot);
  }
}
function selectTeamMember(monData, cardElement) {
  const monName = monData.name;
  const isSelected = playerTeam.some((m) => m.name === monName);
  if (!isSelected && playerTeam.length < 3) {
    const newMonInstance = JSON.parse(JSON.stringify(monData));
    newMonInstance.currentHP = newMonInstance.stats.hp;
    newMonInstance.moves.forEach((m) => (m.pp = m.maxPP));
    playerTeam.push(newMonInstance);
    cardElement.classList.add("selected");
  } else if (isSelected) {
    playerTeam = playerTeam.filter((m) => m.name !== monName);
    cardElement.classList.remove("selected");
  }
  updateTeamPreview();
}
function updateTeamPreview() {
  const slots = dom.teamSlots.children;
  for (let i = 0; i < 3; i++) {
    slots[i].innerHTML = "";
    if (playerTeam[i]) {
      const img = document.createElement("img");
      img.src = playerTeam[i].sprite;
      img.alt = playerTeam[i].name;
      slots[i].appendChild(img);
    }
  }
  dom.startButton.disabled = playerTeam.length !== 3;
}

// ==========================================================================
//  BATTLE START & CORE UI UPDATES
// ==========================================================================
function startBattle() {
  if (!dom.selectionScreen || !dom.battleScreen) {
    console.error("FATAL: UI screens missing!");
    addToLog("Error: UI screens missing.", true);
    return;
  }
  activePlayerIndex = 0;
  activeOpponentIndex = 0;
  resetStagesAndStatus();
  crashDummyActive = false;
  if (
    !dom.continueButton.style.display ||
    dom.continueButton.style.display === "none"
  ) {
    console.log("Resetting items for new game.");
    resetItems();
  } else {
    console.log("Continuing game, items not reset.");
  }
  playerCurrentHP = playerTeam[activePlayerIndex]?.currentHP || 0;
  opponentTeam = [];
  const availableMons = Object.values(squabblemon).filter(
    (mon) => !playerTeam.some((p) => p.name === mon.name)
  );
  while (opponentTeam.length < 3 && availableMons.length > 0) {
    const randomIndex = Math.floor(Math.random() * availableMons.length);
    const mon = JSON.parse(JSON.stringify(availableMons[randomIndex]));
    mon.currentHP = mon.stats.hp;
    mon.moves.forEach((m) => (m.pp = m.maxPP));
    mon.fainted = false;
    opponentTeam.push(mon);
    availableMons.splice(randomIndex, 1);
  }
  if (opponentTeam.length < 3) {
    console.warn("Could not generate full unique opponent team.");
    const allMons = Object.values(squabblemon);
    while (opponentTeam.length < 3) {
      const mon = JSON.parse(
        JSON.stringify(allMons[Math.floor(Math.random() * allMons.length)])
      );
      mon.currentHP = mon.stats.hp;
      mon.moves.forEach((m) => (m.pp = m.maxPP));
      mon.fainted = false;
      if (!opponentTeam.some((o) => o.name === mon.name)) {
        opponentTeam.push(mon);
      }
    }
  }
  opponentCurrentHP = opponentTeam[activeOpponentIndex]?.currentHP || 0;
  if (battleBackgrounds.length > 0) {
    const bgUrl =
      battleBackgrounds[Math.floor(Math.random() * battleBackgrounds.length)];
    dom.battleScreen.style.backgroundImage = `url('${bgUrl}')`;
  } else {
    dom.battleScreen.style.backgroundImage = "none";
    dom.battleScreen.style.backgroundColor = "#5d7d5c";
  }
  dom.selectionScreen.style.display = "none";
  dom.battleScreen.style.display = "flex";
  updateBattleUI();
  updateMoveButtons();
  updateItemButtons();
  clearBattleLog();
  clearFloatingLog();
  updateFadeDisplay();
  updateOpponentInfoBox();
  addToLog(
    `Opponent sends out ${
      opponentTeam[activeOpponentIndex]?.name || "Unknown"
    }!`,
    true
  );
  addToLog(`Go ${playerTeam[activePlayerIndex]?.name || "Unknown"}!`, true);
  isPlayerTurn = true;
}
function resetStagesAndStatus() {
  playerStages = { attack: 0, defense: 0, speed: 0, accuracy: 0, evasion: 0 };
  opponentStages = { attack: 0, defense: 0, speed: 0, accuracy: 0, evasion: 0 };
  playerStatus = { type: null, turns: 0 };
  opponentStatus = { type: null, turns: 0 };
}
function resetItems() {
  console.log("Items reset");
  itemsUsed = {
    jcole: false,
    nbayoungboy: false,
    weed: false,
    crashdummy: false,
  };
}
function updateBattleUI() {
  const playerMon = playerTeam[activePlayerIndex];
  if (playerMon && playerCurrentHP > 0) {
    dom.playerSprite.src = crashDummyActive
      ? "https://i.imgur.com/eV7Ki9I.gif"
      : playerMon.sprite;
    dom.playerSprite.classList.remove("faint-animation");
    dom.playerSprite.style.opacity = 1;
    dom.playerName.textContent = crashDummyActive
      ? "Crash Dummy"
      : playerMon.name;
    dom.playerHP.textContent = `${Math.max(0, playerCurrentHP)}/${
      playerMon.stats.hp
    }`;
    dom.playerHPFill.style.width = `${Math.max(
      0,
      (playerCurrentHP / playerMon.stats.hp) * 100
    )}%`;
    updateStatusIcon(dom.playerStatusIcon, playerStatus);
  } else if (playerMon) {
    dom.playerSprite.classList.add("faint-animation");
    dom.playerSprite.style.opacity = 0.5;
    dom.playerName.textContent = playerMon.name;
    dom.playerHP.textContent = `0/${playerMon.stats.hp}`;
    dom.playerHPFill.style.width = "0%";
    updateStatusIcon(dom.playerStatusIcon, { type: null, turns: 0 });
  }
  const opponentMon = opponentTeam[activeOpponentIndex];
  if (opponentMon && opponentCurrentHP > 0) {
    dom.opponentSprite.src = opponentMon.sprite;
    dom.opponentSprite.classList.remove("faint-animation");
    dom.opponentSprite.style.opacity = 1;
    dom.opponentName.textContent = opponentMon.name;
    dom.opponentHP.textContent = `${Math.max(0, opponentCurrentHP)}/${
      opponentMon.stats.hp
    }`;
    dom.opponentHPFill.style.width = `${Math.max(
      0,
      (opponentCurrentHP / opponentMon.stats.hp) * 100
    )}%`;
    updateStatusIcon(dom.opponentStatusIcon, opponentStatus);
  } else if (opponentMon) {
    dom.opponentSprite.classList.add("faint-animation");
    dom.opponentSprite.style.opacity = 0.5;
    dom.opponentName.textContent = opponentMon.name;
    dom.opponentHP.textContent = `0/${opponentMon.stats.hp}`;
    dom.opponentHPFill.style.width = "0%";
    updateStatusIcon(dom.opponentStatusIcon, { type: null, turns: 0 });
  }
}
function updateStatusIcon(iconElement, status) {
  if (!iconElement) return;
  iconElement.textContent = "";
  iconElement.className = "status-icon";
  if (status.type) {
    switch (status.type) {
      case "burn":
        iconElement.textContent = "BRN";
        iconElement.classList.add("burn");
        break;
      case "paralysis":
        iconElement.textContent = "PAR";
        iconElement.classList.add("paralysis");
        break;
      case "sleep":
        iconElement.textContent = "SLP";
        iconElement.classList.add("sleep");
        break;
      case "wet":
        iconElement.textContent = "WET";
        iconElement.classList.add("wet");
        break;
      case "poison":
        iconElement.textContent = "PSN";
        iconElement.classList.add("poison");
        break;
    }
  }
}
function updateMoveButtons() {
  dom.movesDiv.innerHTML = "";
  const playerMon = playerTeam[activePlayerIndex];
  if (playerMon) {
    playerMon.moves.forEach((move, index) => {
      const button = document.createElement("button");
      button.classList.add("pixel-button");
      button.innerHTML = `${move.name} (${move.pp}/${move.maxPP})`;
      button.dataset.moveIndex = index;
      button.dataset.power = move.power;
      button.dataset.accuracy = move.accuracy;
      button.dataset.effect = move.effect || "none";
      button.dataset.type = move.type || playerMon.type;
      button.onclick = () => useMove(index);
      button.disabled =
        move.pp <= 0 ||
        !isPlayerTurn ||
        playerStatus.type === "sleep" ||
        playerCurrentHP <= 0;
      button.addEventListener("mouseenter", showMoveTooltip);
      button.addEventListener("mouseleave", hideMoveTooltip);
      dom.movesDiv.appendChild(button);
    });
  }
}
function showMoveTooltip(event) {
  const button = event.target;
  const tooltip = dom.moveTooltip;
  const playerMon = playerTeam[activePlayerIndex];
  const moveIndex = parseInt(button.dataset.moveIndex);
  const move = playerMon?.moves[moveIndex];
  if (!move) return;
  tooltip.innerHTML = `Type: ${move.type || playerMon.type}<br>Pow: ${
    button.dataset.power
  }<br>Acc: ${button.dataset.accuracy}<br>Eff: ${button.dataset.effect}`;
  tooltip.style.display = "block";
  const rect = button.getBoundingClientRect();
  tooltip.style.left = `${rect.left + window.scrollX}px`;
  tooltip.style.top = `${
    rect.top + window.scrollY - tooltip.offsetHeight - 5
  }px`;
  if (rect.top - tooltip.offsetHeight - 5 < 0) {
    tooltip.style.top = `${rect.bottom + window.scrollY + 5}px`;
  }
  if (rect.left + tooltip.offsetWidth > window.innerWidth) {
    tooltip.style.left = `${
      rect.right + window.scrollX - tooltip.offsetWidth
    }px`;
  }
}
function hideMoveTooltip() {
  dom.moveTooltip.style.display = "none";
}
function updateItemButtons() {
  dom.itemsDiv.querySelectorAll("button").forEach((button) => {
    const action = button.getAttribute("onclick");
    let isDisabled =
      !isPlayerTurn || playerStatus.type === "sleep" || playerCurrentHP <= 0;
    if (action && !isDisabled) {
      const itemMatch = action.match(/useItem\('([^']+)'\)/);
      if (itemMatch) {
        const item = itemMatch[1];
        isDisabled = itemsUsed[item];
      } else if (button.id === "toggle-switch") {
        const alivePlayerYNs = playerTeam.filter(
          (yn) => yn.currentHP > 0
        ).length;
        isDisabled = alivePlayerYNs <= 1;
      }
    }
    button.disabled = isDisabled;
  });
}
function disableMovesAndItems() {
  document
    .querySelectorAll("#moves button, #items button")
    .forEach((button) => (button.disabled = true));
}
function enableMovesAndItems() {
  updateMoveButtons();
  updateItemButtons();
}
function updateFadeDisplay() {
  if (dom.fadeDisplay) {
    dom.fadeDisplay.textContent = `Fades: ${fadeCounter}`;
  }
}
function updateOpponentInfoBox() {
  const opponentMon = opponentTeam[activeOpponentIndex];
  if (dom.opponentInfoText && opponentMon) {
    dom.opponentInfoText.textContent = opponentMon.lore || "No info available.";
  } else if (dom.opponentInfoText) {
    dom.opponentInfoText.textContent = "";
  }
}
function clearBattleLog() {
  if (dom.battleLog) dom.battleLog.innerHTML = "";
}
function clearFloatingLog() {
  if (dom.floatingLog) dom.floatingLog.classList.remove("visible");
}
function addToLog(message, isImportant = false) {
  if (dom.battleLog) {
    dom.battleLog.innerHTML +=
      message.replace(/<span .*?>/g, "").replace(/<\/span>/g, "") + "<br>";
    dom.battleLog.scrollTop = dom.battleLog.scrollHeight;
  }
  if (isImportant && dom.floatingLog) {
    showFloatingLog(message);
  }
}
function showFloatingLog(message, duration = 2500) {
  if (!dom.floatingLog) return;
  clearTimeout(floatingLogTimeout);
  dom.floatingLog.innerHTML = message;
  dom.floatingLog.classList.add("visible");
  floatingLogTimeout = setTimeout(() => {
    dom.floatingLog.classList.remove("visible");
  }, duration);
}
async function determineTurn(playerMoveData, opponentMoveData) {
  const playerMon = playerTeam[activePlayerIndex];
  const opponentMon = opponentTeam[activeOpponentIndex];
  let battleEnded = false;
  if (
    !playerMon ||
    !opponentMon ||
    playerCurrentHP <= 0 ||
    opponentCurrentHP <= 0
  ) {
    console.warn("determineTurn called with invalid state or fainted mon.");
    battleEnded = await checkBattleEnd();
    if (!battleEnded && playerCurrentHP > 0 && opponentCurrentHP > 0) {
      isPlayerTurn = true;
      enableMovesAndItems();
    }
    return;
  }
  const playerSpeed = calculateEffectiveSpeed(
    playerMon,
    playerStages,
    playerStatus
  );
  const opponentSpeed = calculateEffectiveSpeed(
    opponentMon,
    opponentStages,
    opponentStatus
  );
  const playerGoesFirst = playerSpeed >= opponentSpeed;
  /* Don't clear logs here */ try {
    if (playerGoesFirst) {
      if (playerCurrentHP > 0) {
        await executeAction(playerMon, opponentMon, playerMoveData, true);
        battleEnded = await checkBattleEnd();
      }
      if (!battleEnded && opponentCurrentHP > 0) {
        await executeAction(opponentMon, playerMon, opponentMoveData, false);
        battleEnded = await checkBattleEnd();
      }
    } else {
      if (opponentCurrentHP > 0) {
        await executeAction(opponentMon, playerMon, opponentMoveData, false);
        battleEnded = await checkBattleEnd();
      }
      if (!battleEnded && playerCurrentHP > 0) {
        await executeAction(playerMon, opponentMon, playerMoveData, true);
        battleEnded = await checkBattleEnd();
      }
    }
    if (!battleEnded && playerCurrentHP > 0) {
      await applyEndOfTurnStatus(true);
      battleEnded = await checkBattleEnd();
    }
    if (!battleEnded && opponentCurrentHP > 0) {
      await applyEndOfTurnStatus(false);
      battleEnded = await checkBattleEnd();
    }
  } catch (error) {
    console.error("!!!! Error during turn execution !!!!", error);
    addToLog(
      `<span style="color:red; font-weight:bold;">An error occurred! ${error.message}</span>`,
      true
    );
    battleEnded = true;
  }
  if (!battleEnded && playerCurrentHP > 0 && opponentCurrentHP > 0) {
    isPlayerTurn = true;
    enableMovesAndItems();
    addToLog("--- Your Turn ---");
  } else {
    isPlayerTurn = false;
    disableMovesAndItems();
  }
  updateBattleUI();
}
function calculateEffectiveSpeed(mon, stages, status) {
  if (!mon) return 0;
  let speed = mon.stats.speed;
  const stageMod = calculateStatModifier(stages.speed);
  speed *= stageMod;
  if (status.type === "paralysis") {
    speed *= 0.5;
  }
  return Math.floor(speed);
}
function calculateStatModifier(stage) {
  if (stage > 0) {
    return (2 + stage) / 2;
  } else if (stage < 0) {
    return 2 / (2 + Math.abs(stage));
  } else {
    return 1;
  }
}
async function useMove(moveIndex) {
  try {
    if (!isPlayerTurn || !playerTeam[activePlayerIndex]) {
      return;
    }
    const playerMon = playerTeam[activePlayerIndex];
    const move = playerMon.moves[moveIndex];
    if (!move) {
      console.error("Invalid move index:", moveIndex);
      return;
    }
    if (move.pp <= 0) {
      clearFloatingLog();
      addToLog(`${move.name} has no PP left!`, true);
      return;
    }
    if (playerStatus.type === "sleep") {
      console.log("useMove: Player is asleep.");
      clearFloatingLog();
      addToLog(
        `${playerMon.name} is fast asleep! <span style='font-size:1.5em;'>💤</span>`,
        true
      );
      playerStatus.turns--;
      let wokeUp = false;
      if (playerStatus.turns <= 0) {
        await delay(500);
        addToLog(`${playerMon.name} woke up!`, true);
        playerStatus.type = null;
        updateBattleUI();
        wokeUp = true;
      }
      isPlayerTurn = false;
      disableMovesAndItems();
      await delay(1000);
      const opponentMove = chooseSmartAIMove();
      if (opponentMove && opponentMove.pp > 0) {
        opponentMove.pp--;
        const oppMon = opponentTeam[activeOpponentIndex];
        const oppMoveIndex = oppMon?.moves.findIndex(
          (m) => m.name === opponentMove.name
        );
        if (oppMon && oppMoveIndex !== -1)
          oppMon.moves[oppMoveIndex].pp = opponentMove.pp;
      }
      console.log(
        "useMove (Sleep): Calling determineTurn (player action=null)"
      );
      await determineTurn(null, opponentMove || null);
      return;
    } else if (playerStatus.type === "paralysis" && Math.random() < 0.25) {
      console.log("useMove: Player is fully paralyzed.");
      clearFloatingLog();
      addToLog(
        `${playerMon.name} is paralyzed! It can't move! <span style='font-size:1.2em; color: orange;'>⚡</span>`,
        true
      );
      triggerEffect("player-sprite", effects.electricStatus);
      isPlayerTurn = false;
      disableMovesAndItems();
      await delay(1000);
      const opponentMove = chooseSmartAIMove();
      if (opponentMove && opponentMove.pp > 0) {
        opponentMove.pp--;
        const oppMon = opponentTeam[activeOpponentIndex];
        const oppMoveIndex = oppMon?.moves.findIndex(
          (m) => m.name === opponentMove.name
        );
        if (oppMon && oppMoveIndex !== -1)
          oppMon.moves[oppMoveIndex].pp = opponentMove.pp;
      }
      console.log(
        "useMove (Paralysis): Calling determineTurn (player action=null)"
      );
      await determineTurn(null, opponentMove || null);
      return;
    }
    isPlayerTurn = false;
    disableMovesAndItems();
    move.pp--;
    playerMove = move;
    updateMoveButtons();
    const opponentMove = chooseSmartAIMove();
    console.log(
      `useMove: Opponent chose: ${
        opponentMove?.name || "None/Paralyzed/Asleep"
      }`
    );
    if (opponentMove && opponentMove.pp > 0) {
      opponentMove.pp--;
      const oppMon = opponentTeam[activeOpponentIndex];
      const oppMoveIndex = oppMon?.moves.findIndex(
        (m) => m.name === opponentMove.name
      );
      if (oppMon && oppMoveIndex !== -1) {
        oppMon.moves[oppMoveIndex].pp = opponentMove.pp;
      }
    }
    console.log(
      `useMove: Calling determineTurn (player: ${playerMove?.name}, opponent: ${
        opponentMove?.name || "None"
      })`
    );
    await determineTurn(playerMove, opponentMove || null);
    console.log("useMove: determineTurn call completed.");
  } catch (error) {
    console.error("!!!! Error within useMove !!!!", error);
    addToLog(
      `<span style="color:red; font-weight:bold;">Error processing move! ${error.message}</span>`,
      true
    );
    isPlayerTurn = false;
    disableMovesAndItems();
  }
}
async function useItem(item) {
  if (!isPlayerTurn || playerStatus.type === "sleep") return;
  if (itemsUsed[item]) {
    clearFloatingLog();
    addToLog(`You've already used ${item}!`, true);
    return;
  }
  isPlayerTurn = false;
  disableMovesAndItems();
  clearFloatingLog();
  itemsUsed[item] = true;
  updateItemButtons();
  playerMove = null;
  const playerMon = playerTeam[activePlayerIndex];
  const opponentMon = opponentTeam[activeOpponentIndex];
  switch (item) {
    case "jcole":
      const healAmount = Math.floor(playerMon.stats.hp * 0.5);
      const healedHP = Math.min(
        playerMon.stats.hp,
        playerCurrentHP + healAmount
      );
      const actualHeal = healedHP - playerCurrentHP;
      if (actualHeal > 0) {
        playerCurrentHP = healedHP;
        playerMon.currentHP = playerCurrentHP;
        addToLog(
          `J Cole CD bumps some real shit, healing ${playerMon.name} for ${actualHeal} HP!`,
          true
        );
        triggerEffect("player-sprite", effects.jcoleHeal);
      } else {
        addToLog(`${playerMon.name} is already at full health!`, true);
        itemsUsed[item] = false;
        updateItemButtons();
      }
      break;
    case "nbayoungboy":
      const atkBoost = changeStatStage(true, "attack", 2);
      const defDrop = changeStatStage(true, "defense", -1);
      addToLog(
        `NBA Youngboy CD slaps hard! ${playerMon.name}'s Attack ${
          atkBoost ? "sharply rose!" : "won't go higher!"
        } <span class="stat-up">▲▲</span> Defense ${
          defDrop ? "fell!" : "won't go lower!"
        } <span class="stat-down">▼</span>`,
        true
      );
      triggerEffect("player-sprite", effects.nbaBuff);
      break;
    case "weed":
      if (!opponentStatus.type) {
        opponentStatus.type = "sleep";
        opponentStatus.turns = Math.floor(Math.random() * 3) + 1;
        addToLog(
          `Man, this weed was so strong, it put ${opponentMon.name} to sleep! <span style='font-size:1.5em;'>💤</span> (${opponentStatus.turns} turns)`,
          true
        );
        triggerEffect("opponent-sprite", effects.weedSleep);
      } else {
        addToLog(`${opponentMon.name} is already affected by a status!`, true);
        itemsUsed[item] = false;
        updateItemButtons();
      }
      break;
    case "crashdummy":
      crashDummyActive = true;
      addToLog(
        `${playerMon.name} sent out a Crash Dummy to take the next hit!`,
        true
      );
      break;
  }
  updateBattleUI();
  await delay(1200);
  const opponentMove = chooseSmartAIMove();
  if (opponentMove && opponentMove.pp > 0) {
    opponentMove.pp--;
    const oppMon = opponentTeam[activeOpponentIndex];
    const oppMoveIndex = oppMon.moves.findIndex(
      (m) => m.name === opponentMove.name
    );
    if (oppMoveIndex !== -1) {
      oppMon.moves[oppMoveIndex].pp = opponentMove.pp;
    }
  }
  await determineTurn(null, opponentMove || null);
}
function switchYN() {
  if (!isPlayerTurn || playerStatus.type === "sleep") return;
  const alivePlayerYNs = playerTeam.filter(
    (yn, index) => yn.currentHP > 0 && index !== activePlayerIndex
  );
  if (alivePlayerYNs.length === 0) {
    clearFloatingLog();
    addToLog("No other YN available to switch!", true);
    return;
  }
  isPlayerTurn = false;
  disableMovesAndItems();
  showSwitchScreen(false);
}
function showSwitchScreen(isForced) {
  dom.switchOptions.innerHTML = "";
  const currentMonName = playerTeam[activePlayerIndex]?.name;
  playerTeam.forEach((yn, index) => {
    if (yn.currentHP > 0 && (isForced || index !== activePlayerIndex)) {
      const card = document.createElement("div");
      card.className = "character-card";
      let statusText = "";
      card.innerHTML = `<img src="${yn.sprite}" alt="${yn.name}"><p>${yn.name}<br><small>HP: ${yn.currentHP}/${yn.stats.hp} ${statusText}</small></p>`;
      card.onclick = async () => {
        await performSwitch(index, isForced);
      };
      dom.switchOptions.appendChild(card);
    }
  });
  const cancelButton = dom.switchScreen.querySelector("button");
  if (cancelButton)
    cancelButton.style.display = isForced ? "none" : "inline-block";
  dom.switchScreen.style.display = "block";
  clearFloatingLog();
  addToLog(
    isForced
      ? `${currentMonName} fainted! Choose your next YN!`
      : `Choose who to switch in...`,
    true
  );
}
async function performSwitch(newIndex, isForced) {
  dom.switchScreen.style.display = "none";
  const oldMon = playerTeam[activePlayerIndex];
  const newMon = playerTeam[newIndex];
  if (oldMon?.ability === "Natural Cure" && playerStatus.type) {
    addToLog(
      `${oldMon.name}'s Natural Cure activated! It was cured of ${playerStatus.type}!`,
      true
    );
    playerStatus = { type: null, turns: 0 };
    updateStatusIcon(dom.playerStatusIcon, playerStatus);
    await delay(800);
  }
  if (oldMon) oldMon.currentHP = playerCurrentHP;
  activePlayerIndex = newIndex;
  playerCurrentHP = newMon.currentHP;
  playerStages = { attack: 0, defense: 0, speed: 0, accuracy: 0, evasion: 0 };
  playerStatus = { type: null, turns: 0 };
  crashDummyActive = false;
  addToLog(
    `${oldMon?.name || "Someone"} switches out! Go ${newMon.name}!`,
    true
  );
  updateBattleUI();
  await delay(1000);
  updateOpponentInfoBox();
  /* Update lore box on switch */ if (newMon.ability === "Download") {
    const opponentDef =
      opponentTeam[activeOpponentIndex].stats.defense *
      calculateStatModifier(opponentStages.defense);
    if (changeStatStage(true, "attack", 1)) {
      addToLog(
        `${newMon.name}'s Download activated! Its Attack rose! <span class="stat-up">▲</span>`,
        true
      );
      await delay(800);
    }
  }
  if (isForced) {
    isPlayerTurn = true;
    enableMovesAndItems();
    updateBattleUI();
    addToLog("--- Your Turn ---");
  } else {
    updateBattleUI();
    const opponentMove = chooseSmartAIMove();
    if (opponentMove && opponentMove.pp > 0) {
      opponentMove.pp--;
      const oppMon = opponentTeam[activeOpponentIndex];
      const oppMoveIndex = oppMon.moves.findIndex(
        (m) => m.name === opponentMove.name
      );
      if (oppMoveIndex !== -1) oppMon.moves[oppMoveIndex].pp = opponentMove.pp;
    }
    await determineTurn(null, opponentMove || null);
  }
}
function cancelSwitch() {
  dom.switchScreen.style.display = "none";
  isPlayerTurn = true;
  enableMovesAndItems();
  clearBattleLog();
  addToLog("Choose an action.");
}
function chooseSmartAIMove() {
  const opponentMon = opponentTeam[activeOpponentIndex];
  const playerMon = playerTeam[activePlayerIndex];
  if (!opponentMon) return null;
  if (opponentStatus.type === "sleep") {
    return null;
  }
  if (opponentStatus.type === "paralysis" && Math.random() < 0.25) {
    return null;
  }
  const availableMoves = opponentMon.moves.filter((move) => move.pp > 0);
  if (availableMoves.length === 0) return null;
  const canHeal = opponentCurrentHP < opponentMon.stats.hp * 0.4;
  const canSetup = Object.values(opponentStages).some((stage) => stage < 2);
  const canDebuff =
    Object.values(playerStages).some((stage) => stage > -2) ||
    !playerStatus.type;
  const healMoves = availableMoves.filter((m) => m.effect === "heal");
  if (canHeal && healMoves.length > 0) return healMoves[0];
  const superEffectiveMoves = availableMoves.filter((m) => {
    const moveType = m.type || opponentMon.type;
    return m.power > 0 && getTypeEffectiveness(moveType, playerMon?.type) > 1;
  });
  if (superEffectiveMoves.length > 0 && Math.random() < 0.7) {
    return superEffectiveMoves.reduce(
      (best, current) => (current.power > best.power ? current : best),
      superEffectiveMoves[0]
    );
  }
  const statusMoves = availableMoves.filter(
    (m) =>
      [
        "burn",
        "sleep",
        "paralysis",
        "wet",
        "lowerSpeed",
        "lowerAccuracy",
        "lowerDefense",
        "lowerAttack",
        "poison",
      ].includes(m.effect) && !playerStatus.type
  );
  if (canDebuff && statusMoves.length > 0 && Math.random() < 0.4) {
    return statusMoves[Math.floor(Math.random() * statusMoves.length)];
  }
  const buffMoves = availableMoves.filter(
    (m) =>
      [
        "raiseAttack",
        "raiseDefense",
        "raiseSpeed",
        "raiseAccuracy",
        "raiseEvasion",
      ].includes(m.effect) &&
      opponentStages[m.effect.replace("raise", "").toLowerCase()] < 6
  );
  if (canSetup && buffMoves.length > 0 && Math.random() < 0.3) {
    return buffMoves[Math.floor(Math.random() * buffMoves.length)];
  }
  const stabMoves = availableMoves.filter(
    (m) => m.power > 0 && (m.type || opponentMon.type) === opponentMon.type
  );
  if (stabMoves.length > 0 && Math.random() < 0.5) {
    return stabMoves.reduce(
      (best, current) => (current.power > best.power ? current : best),
      stabMoves[0]
    );
  }
  const damagingMoves = availableMoves.filter((move) => move.power > 0);
  if (damagingMoves.length > 0) {
    return damagingMoves.reduce(
      (best, current) => (current.power > best.power ? current : best),
      damagingMoves[0]
    );
  }
  return availableMoves[Math.floor(Math.random() * availableMoves.length)];
}
async function executeAction(attacker, defender, move, isPlayerTurn) {
  const attackerName =
    attacker?.name || (isPlayerTurn ? "Player's YN" : "Opponent's YN");
  const attackerStatus = isPlayerTurn ? playerStatus : opponentStatus;
  const spriteId = isPlayerTurn ? "player-sprite" : "opponent-sprite";
  if (!move) {
    if (attackerStatus.type === "sleep") {
      addToLog(
        `${attackerName} is fast asleep! <span style='font-size:1.5em;'>💤</span>`,
        true
      );
      attackerStatus.turns--;
      if (attackerStatus.turns <= 0) {
        await delay(500);
        addToLog(`${attackerName} woke up!`, true);
        attackerStatus.type = null;
        updateBattleUI();
      }
    } else if (attackerStatus.type === "paralysis") {
      addToLog(
        `${attackerName} is paralyzed! It can't move! <span style='font-size:1.2em; color: orange;'>⚡</span>`,
        true
      );
      triggerEffect(spriteId, effects.electricStatus);
    } else {
      addToLog(`${attackerName} couldn't move!`, true);
    }
    await delay(1000);
    return;
  }
  await performMove(attacker, defender, move, isPlayerTurn);
}
async function performMove(attacker, defender, move, isPlayer) {
  const attackerStages = isPlayer ? playerStages : opponentStages;
  const defenderStages = isPlayer ? opponentStages : playerStages;
  const attackerStatus = isPlayer ? playerStatus : opponentStatus;
  const defenderStatus = isPlayer ? opponentStatus : playerStatus;
  const attackerSpriteId = isPlayer ? "player-sprite" : "opponent-sprite";
  const defenderSpriteId = isPlayer ? "opponent-sprite" : "player-sprite";
  const attackerSprite = document.getElementById(attackerSpriteId);
  const defenderSprite = document.getElementById(defenderSpriteId);
  if (!attacker || !defender || !move) {
    console.error("Missing data in performMove");
    return;
  }
  let defenderCurrentHP = isPlayer ? opponentCurrentHP : playerCurrentHP;
  const moveName = move.name;
  addToLog(`--- ${attacker.name} used ${moveName}! ---`);
  addAnimationClass(attackerSprite, "attack-animation");
  await delay(700);
  const accuracyCheckPassed = checkAccuracy(
    move,
    attackerStages,
    defenderStages
  );
  if (!accuracyCheckPassed) {
    addToLog(`${attacker.name}'s attack missed!`, true);
    await delay(1000);
    return;
  }
  let damage = 0;
  let wasCrit = false;
  let actualDamageDealt = 0;
  if (move.power > 0) {
    const moveType = move.type || attacker.type;
    const typeMod = getTypeEffectiveness(moveType, defender?.type);
    let stabBonus = attacker.type === moveType ? 1.5 : 1;
    let critical = 1;
    const critChance = 1 / 16;
    if (Math.random() < critChance) {
      critical = 1.5;
      wasCrit = true;
    }
    const attackStat = attacker.stats.attack;
    const defenseStat = defender?.stats.defense || 50;
    const effectiveAttack = calculateEffectiveStatWithStages(
      attackStat,
      attackerStages.attack,
      wasCrit ? "attack_crit" : "attack",
      attacker.ability === "Guts" && attackerStatus.type,
      attackerStatus.type === "burn"
    );
    const effectiveDefense = calculateEffectiveStatWithStages(
      defenseStat,
      defenderStages.defense,
      wasCrit ? "defense_crit" : "defense"
    );
    damage = Math.floor(
      ((((attacker.level || 50) * 2) / 5 + 2) * move.power * effectiveAttack) /
        effectiveDefense /
        50 +
        2
    );
    const randomFactor = Math.random() * 0.15 + 0.85;
    damage = Math.floor(damage * stabBonus * typeMod * critical * randomFactor);
    damage = Math.max(1, damage);
    if (
      defender?.ability === "Sturdy" &&
      defenderCurrentHP === defender.stats.hp &&
      damage >= defenderCurrentHP
    ) {
      damage = defenderCurrentHP - 1;
      addToLog(`${defender.name} endured the hit with Sturdy!`, true);
      await delay(500);
    }
    const targetIsCrashDummy = !isPlayer && crashDummyActive;
    if (targetIsCrashDummy) {
      addToLog(
        `Crash Dummy took the hit (${damage} damage) and crumpled!`,
        true
      );
      crashDummyActive = false;
      updateBattleUI();
      actualDamageDealt = 0;
    } else {
      let hpBeforeDamage = defenderCurrentHP;
      defenderCurrentHP = Math.max(0, defenderCurrentHP - damage);
      if (isPlayer) {
        opponentCurrentHP = defenderCurrentHP;
        if (opponentTeam[activeOpponentIndex])
          opponentTeam[activeOpponentIndex].currentHP = opponentCurrentHP;
      } else {
        playerCurrentHP = defenderCurrentHP;
        if (playerTeam[activePlayerIndex])
          playerTeam[activePlayerIndex].currentHP = playerCurrentHP;
      }
      actualDamageDealt = hpBeforeDamage - defenderCurrentHP;
      let damageMsg = `It dealt ${actualDamageDealt} damage!`;
      if (wasCrit)
        damageMsg += ` <span class="crit-hit">(Critical hit!)</span>`;
      if (stabBonus > 1) damageMsg += ` (STAB)`;
      if (typeMod > 1)
        damageMsg += ` <span class="effective">(Super effective!)</span>`;
      else if (typeMod < 1)
        damageMsg += ` <span class="not-effective">(Not very effective...)</span>`;
      addToLog(damageMsg, true);
      triggerEffect(defenderSpriteId, getAttackEffect(attacker, move));
      addAnimationClass(defenderSprite, "damage-animation");
      updateBattleUI();
      await delay(800);
    }
    if (
      move.effect === "recoil" &&
      actualDamageDealt > 0 &&
      !targetIsCrashDummy
    ) {
      const recoilDamage = Math.max(1, Math.floor(actualDamageDealt / 4));
      addToLog(`${attacker.name} took ${recoilDamage} recoil damage!`, true);
      let attackerCurrentHP = isPlayer ? playerCurrentHP : opponentCurrentHP;
      attackerCurrentHP = Math.max(0, attackerCurrentHP - recoilDamage);
      if (isPlayer) {
        playerCurrentHP = attackerCurrentHP;
        if (playerTeam[activePlayerIndex])
          playerTeam[activePlayerIndex].currentHP = playerCurrentHP;
      } else {
        opponentCurrentHP = attackerCurrentHP;
        if (opponentTeam[activeOpponentIndex])
          opponentTeam[activeOpponentIndex].currentHP = opponentCurrentHP;
      }
      addAnimationClass(attackerSprite, "damage-animation");
      updateBattleUI();
      await delay(800);
    }
  }
  if (
    (move.power === 0 || actualDamageDealt > 0) &&
    !crashDummyActive &&
    defender &&
    defenderCurrentHP > 0
  ) {
    await applyMoveEffect(
      attacker,
      defender,
      move,
      isPlayer,
      attackerStages,
      defenderStages,
      attackerStatus,
      defenderStatus
    );
  }
  updateBattleUI();
}
function checkAccuracy(move, attackerStages, defenderStages) {
  if (move.accuracy === 100 || move.accuracy === true) return true;
  const accStage = attackerStages.accuracy;
  const evaStage = defenderStages.evasion;
  const stageMultiplier = calculateStatModifier(accStage - evaStage);
  const hitChance = (move.accuracy / 100) * stageMultiplier;
  return Math.random() < hitChance;
}
function calculateEffectiveStatWithStages(
  baseStat,
  stage,
  type,
  applyGuts = false,
  applyBurn = false
) {
  let modifier = 1;
  if (type.includes("attack") && applyGuts) {
    modifier *= 1.5;
  }
  let effectiveStage = stage;
  if (type === "attack_crit" && stage < 0) effectiveStage = 0;
  if (type === "defense_crit" && stage > 0) effectiveStage = 0;
  modifier *= calculateStatModifier(effectiveStage);
  if (type === "attack" && applyBurn) {
    modifier *= 0.5;
  }
  return Math.max(1, Math.floor(baseStat * modifier));
}
async function applyMoveEffect(
  attacker,
  defender,
  move,
  isPlayer,
  attackerStages,
  defenderStages,
  attackerStatus,
  defenderStatus
) {
  const effect = move.effect;
  if (!effect || effect === "none") return;
  const effectChance = move.effectChance || 0.3;
  const applyEffect = move.power === 0 || Math.random() < effectChance;
  const targetSpriteId = isPlayer ? "opponent-sprite" : "player-sprite";
  const userSpriteId = isPlayer ? "player-sprite" : "opponent-sprite";
  const targetStatus = isPlayer ? opponentStatus : playerStatus;
  if (applyEffect) {
    let statusApplied = false;
    let statChanged = false;
    let healOccurred = false;
    switch (effect) {
      case "burn":
        if (!targetStatus.type) {
          targetStatus.type = "burn";
          addToLog(`${defender.name} was burned! 🔥`, true);
          triggerEffect(targetSpriteId, effects.fireStatus);
          statusApplied = true;
        }
        break;
      case "sleep":
        if (!targetStatus.type) {
          targetStatus.type = "sleep";
          targetStatus.turns = Math.floor(Math.random() * 3) + 1;
          addToLog(
            `${defender.name} fell asleep! <span style='font-size:1.5em;'>💤</span> (${targetStatus.turns} turns)`,
            true
          );
          triggerEffect(targetSpriteId, effects.sleepStatus);
          statusApplied = true;
        }
        break;
      case "paralysis":
        if (!targetStatus.type) {
          targetStatus.type = "paralysis";
          addToLog(
            `${defender.name} was paralyzed! <span style='font-size:1.2em; color: orange;'>⚡</span>`,
            true
          );
          triggerEffect(targetSpriteId, effects.electricStatus);
          statusApplied = true;
        }
        break;
      case "wet":
        if (!targetStatus.type) {
          targetStatus.type = "wet";
          targetStatus.turns = Math.floor(Math.random() * 3) + 2;
          let logMsg = `${defender.name} got drenched! 💧`;
          if (changeStatStage(!isPlayer, "speed", -1)) {
            logMsg += ` Its speed fell! <span class="stat-down">▼</span>`;
            statChanged = true;
          }
          addToLog(logMsg + ` (${targetStatus.turns} turns)`, true);
          triggerEffect(targetSpriteId, effects.waterStatus);
          statusApplied = true;
        }
        break;
      case "poison":
        if (!targetStatus.type) {
          targetStatus.type = "poison";
          addToLog(`${defender.name} was poisoned!`, true);
          triggerEffect(targetSpriteId, effects.poisonStatus);
          statusApplied = true;
        }
        break;
      case "raiseAttack":
        statChanged = changeStatStage(isPlayer, "attack", 1);
        if (statChanged) {
          addToLog(
            `${attacker.name}'s Attack rose! <span class="stat-up">▲</span>`,
            true
          );
          triggerEffect(userSpriteId, effects.genericBuff);
        }
        break;
      case "raiseDefense":
        statChanged = changeStatStage(isPlayer, "defense", 1);
        if (statChanged) {
          addToLog(
            `${attacker.name}'s Defense rose! <span class="stat-up">▲</span>`,
            true
          );
          triggerEffect(userSpriteId, effects.genericBuff);
        }
        break;
      case "raiseSpeed":
        statChanged = changeStatStage(isPlayer, "speed", 1);
        if (statChanged) {
          addToLog(
            `${attacker.name}'s Speed rose! <span class="stat-up">▲</span>`,
            true
          );
          triggerEffect(userSpriteId, effects.genericBuff);
        }
        break;
      case "raiseAccuracy":
        statChanged = changeStatStage(isPlayer, "accuracy", 1);
        if (statChanged) {
          addToLog(
            `${attacker.name}'s Accuracy rose! <span class="stat-up">▲</span>`,
            true
          );
          triggerEffect(userSpriteId, effects.lightEffect);
        }
        break;
      case "raiseEvasion":
        statChanged = changeStatStage(isPlayer, "evasion", 1);
        if (statChanged) {
          addToLog(
            `${attacker.name}'s Evasion rose! <span class="stat-up">▲</span>`,
            true
          );
          triggerEffect(userSpriteId, effects.darkBuff);
        }
        break;
      case "lowerAttack":
        statChanged = changeStatStage(!isPlayer, "attack", -1);
        if (statChanged) {
          addToLog(
            `${defender.name}'s Attack fell! <span class="stat-down">▼</span>`,
            true
          );
          triggerEffect(targetSpriteId, effects.genericDebuff);
        }
        break;
      case "lowerDefense":
        statChanged = changeStatStage(!isPlayer, "defense", -1);
        if (statChanged) {
          addToLog(
            `${defender.name}'s Defense fell! <span class="stat-down">▼</span>`,
            true
          );
          triggerEffect(targetSpriteId, effects.genericDebuff);
        }
        break;
      case "lowerSpeed":
        statChanged = changeStatStage(!isPlayer, "speed", -1);
        if (statChanged) {
          addToLog(
            `${defender.name}'s Speed fell! <span class="stat-down">▼</span>`,
            true
          );
          triggerEffect(targetSpriteId, effects.genericDebuff);
        }
        break;
      case "lowerAccuracy":
        statChanged = changeStatStage(!isPlayer, "accuracy", -1);
        if (statChanged) {
          addToLog(
            `${defender.name}'s Accuracy fell! <span class="stat-down">▼</span>`,
            true
          );
          triggerEffect(targetSpriteId, effects.genericDebuff);
        }
        break;
      case "lowerEvasion":
        statChanged = changeStatStage(!isPlayer, "evasion", -1);
        if (statChanged) {
          addToLog(
            `${defender.name}'s Evasion fell! <span class="stat-down">▼</span>`,
            true
          );
          triggerEffect(targetSpriteId, effects.genericDebuff);
        }
        break;
      case "heal":
        const healAmount = Math.floor(attacker.stats.hp * 0.25);
        let currentAttackerHP = isPlayer ? playerCurrentHP : opponentCurrentHP;
        const healedHP = Math.min(
          attacker.stats.hp,
          currentAttackerHP + healAmount
        );
        const actualHeal = healedHP - currentAttackerHP;
        if (actualHeal > 0) {
          if (isPlayer) {
            playerCurrentHP = healedHP;
            playerTeam[activePlayerIndex].currentHP = playerCurrentHP;
          } else {
            opponentCurrentHP = healedHP;
            opponentTeam[activeOpponentIndex].currentHP = opponentCurrentHP;
          }
          addToLog(`${attacker.name} restored ${actualHeal} HP!`, true);
          triggerEffect(userSpriteId, effects.healEffect);
          healOccurred = true;
        } else {
          addToLog(`${attacker.name} is already at full HP!`);
        }
        break;
      case "flinch":
        addToLog(`${defender.name} flinched!`);
        break;
      default:
        break;
    }
    if (statusApplied || statChanged || healOccurred) {
      updateBattleUI();
      await delay(800);
    } else if (
      !statChanged &&
      (effect.startsWith("raise") || effect.startsWith("lower"))
    ) {
      if (effect.startsWith("raise"))
        addToLog(
          `${attacker.name}'s ${effect.substring(5)} won't go any higher!`
        );
      else
        addToLog(
          `${defender.name}'s ${effect.substring(5)} won't go any lower!`
        );
      await delay(500);
    } else if (
      !statusApplied &&
      ["burn", "sleep", "paralysis", "wet", "poison"].includes(effect)
    ) {
      addToLog(`But it failed!`);
      await delay(500);
    }
  }
}
function changeStatStage(isPlayerTarget, stat, amount) {
  const stages = isPlayerTarget ? playerStages : opponentStages;
  const currentStage = stages[stat];
  if ((amount > 0 && currentStage >= 6) || (amount < 0 && currentStage <= -6))
    return false;
  stages[stat] = Math.max(-6, Math.min(6, currentStage + amount));
  return true;
}
function getAttackEffect(attacker, move) {
  if (move.name === "NFT Nuke") return effects.moneyAttack;
  if (move.name === "Boulder Yeet" && attacker.name === "Earthy")
    return effects.earthyAttack;
  if (move.name === "Cash App Cripple" && attacker.name === "Scammer")
    return effects.scammerEffect;
  const effectType = move.effect;
  if (effectType === "burn") return effects.fireAttack;
  if (effectType === "paralysis") return effects.electricAttack;
  if (effectType === "wet") return effects.waterAttack;
  if (effectType === "sleep") return effects.darkAttack;
  if (effectType === "poison") return effects.poisonAttack;
  const moveType = move.type || attacker.type;
  switch (moveType) {
    case "Fire":
      return effects.fireAttack;
    case "Water":
      return effects.waterAttack;
    case "Electric":
      return effects.electricAttack;
    case "Plant":
      return effects.plantAttack;
    case "Rock":
      return effects.rockAttack;
    case "Air":
      return effects.airAttack;
    case "Dark":
      return effects.darkAttack;
    case "Poison":
      return effects.poisonAttack;
    default:
      return effects.normalAttack;
  }
}
function triggerEffect(spriteId, effectUrl) {
  const spriteElement = document.getElementById(spriteId);
  if (!spriteElement || !effectUrl) return;
  const existingOverlay =
    spriteElement.parentElement?.querySelector(".effect-overlay");
  if (existingOverlay) {
    existingOverlay.remove();
  }
  const overlay = document.createElement("img");
  overlay.src = effectUrl;
  overlay.className = "effect-overlay";
  if (spriteElement.parentElement) {
    spriteElement.parentElement.appendChild(overlay);
    setTimeout(() => {
      if (overlay && overlay.parentElement) {
        overlay.remove();
      }
    }, 1200);
  } else {
    console.error("Sprite parent not found for effect");
  }
}
async function applyEndOfTurnStatus(isPlayer) {
  const target = isPlayer
    ? playerTeam[activePlayerIndex]
    : opponentTeam[activeOpponentIndex];
  const status = isPlayer ? playerStatus : opponentStatus;
  const spriteId = isPlayer ? "player-sprite" : "opponent-sprite";
  if (!target || !status.type) return;
  let hpChanged = false;
  let statusCured = false;
  switch (status.type) {
    case "burn":
      const burnDamage = Math.max(1, Math.floor(target.stats.hp / 16));
      let targetCurrentHP = isPlayer ? playerCurrentHP : opponentCurrentHP;
      targetCurrentHP = Math.max(0, targetCurrentHP - burnDamage);
      if (isPlayer) {
        playerCurrentHP = targetCurrentHP;
        target.currentHP = playerCurrentHP;
      } else {
        opponentCurrentHP = targetCurrentHP;
        target.currentHP = opponentCurrentHP;
      }
      addToLog(
        `${target.name} is hurt by its burn! (${burnDamage} damage) 🔥`,
        true
      );
      triggerEffect(spriteId, effects.fireStatus);
      hpChanged = true;
      await delay(700);
      break;
    case "poison":
      const poisonDamage = Math.max(1, Math.floor(target.stats.hp / 8));
      let poisonTargetHP = isPlayer ? playerCurrentHP : opponentCurrentHP;
      poisonTargetHP = Math.max(0, poisonTargetHP - poisonDamage);
      if (isPlayer) {
        playerCurrentHP = poisonTargetHP;
        target.currentHP = playerCurrentHP;
      } else {
        opponentCurrentHP = poisonTargetHP;
        target.currentHP = opponentCurrentHP;
      }
      addToLog(
        `${target.name} is hurt by poison! (${poisonDamage} damage)`,
        true
      );
      triggerEffect(spriteId, effects.poisonStatus);
      hpChanged = true;
      await delay(700);
      break;
    case "wet":
      status.turns--;
      if (status.turns <= 0) {
        addToLog(`${target.name} dried off!`, true);
        status.type = null;
        statusCured = true;
        await delay(500);
      }
      break;
  }
  if (hpChanged || statusCured) {
    updateBattleUI();
  }
}
function getTypeEffectiveness(moveType, defenderType) {
  if (!moveType || !defenderType) return 1;
  const advantages = typeAdvantages[moveType];
  if (!advantages) return 1;
  if (advantages.strong?.includes(defenderType)) return 2;
  if (advantages.weak?.includes(defenderType)) return 0.5;
  return 1;
}
async function checkBattleEnd() {
  // Add check at beginning - if game over screen is already showing, don't proceed
  if (dom.gameOverScreen.style.display === "block") {
    return true; // Already ended
  }

  let playerFainted = playerCurrentHP <= 0;
  let opponentFainted = opponentCurrentHP <= 0;

  if (playerFainted) {
    const faintedMon = playerTeam[activePlayerIndex];
    if (faintedMon && !faintedMon.fainted) {
      faintedMon.fainted = true;
      addToLog(`${faintedMon.name} fainted!`, true);
      addAnimationClass(dom.playerSprite, "faint-animation");
      triggerEffect("player-sprite", effects.loseScreen);
      await delay(1500);
    } else if (!faintedMon && playerCurrentHP <= 0) {
      addToLog("Your YN fainted!", true);
      await delay(1500);
    }
    const alivePlayerYNs = playerTeam.filter((yn) => yn.currentHP > 0);
    if (alivePlayerYNs.length > 0) {
      showSwitchScreen(true);
      return true;
    } else {
      if (
        !dom.gameOverScreen.style.display ||
        dom.gameOverScreen.style.display === "none"
      ) {
        addToLog(`The Gang is down! You lose the fade!`, true);
        await delay(1000);
        endGame("You lose!", false);
      }
      return true;
    }
  }
  if (opponentFainted) {
    const faintedMon = opponentTeam[activeOpponentIndex];
    if (faintedMon && !faintedMon.fainted) {
      faintedMon.fainted = true;
      addToLog(`${faintedMon.name} fainted!`, true);
      addAnimationClass(dom.opponentSprite, "faint-animation");
      triggerEffect("opponent-sprite", effects.winHands);
      await delay(1500);
    } else if (!faintedMon && opponentCurrentHP <= 0) {
      addToLog("Opponent's YN fainted!", true);
      await delay(1500);
    }
    const nextOpponentIndex = opponentTeam.findIndex(
      (yn, index) => yn.currentHP > 0 && !yn.fainted
    ); // Ensure next opponent isn't also marked fainted
    if (nextOpponentIndex !== -1) {
      activeOpponentIndex = nextOpponentIndex;
      opponentCurrentHP = opponentTeam[activeOpponentIndex].currentHP;
      opponentStages = {
        attack: 0,
        defense: 0,
        speed: 0,
        accuracy: 0,
        evasion: 0,
      };
      opponentStatus = { type: null, turns: 0 };
      const nextOpponentName = opponentTeam[activeOpponentIndex].name;
      addToLog(`Opponent sends out ${nextOpponentName}!`, true);
      updateBattleUI();
      updateOpponentInfoBox();
      await delay(1500);
      return false;
    } else {
      if (
        !dom.gameOverScreen.style.display ||
        dom.gameOverScreen.style.display === "none"
      ) {
        addToLog(`Enemy team is down! The Gang wins this fade!`, true);
        fadeCounter++;
        updateFadeDisplay();
        await delay(1000);
        endGame("You win this fade!", true);
      }
      return true;
    }
  }
  return false;
}
function endGame(message, isWin) {
  isPlayerTurn = false;
  disableMovesAndItems();
  dom.gameOverMessage.textContent = message;
  dom.fadeCounter.textContent = `Fades Won: ${fadeCounter}`;
  dom.winLoseGif.src = isWin ? effects.winScreen : effects.loseScreen;
  dom.winLoseGif.style.display = "block";
  dom.continueButton.style.display = isWin ? "inline-block" : "none";
  dom.gameOverScreen.style.display = "block";
}
function continueBattle() {
  console.log("continueBattle: Called.");
  dom.gameOverScreen.style.display = "none";
  dom.winLoseGif.style.display = "none";
  playerTeam.forEach((mon) => {
    if (mon.currentHP > 0) {
      const healAmount = Math.floor(mon.stats.hp * 0.5);
      mon.currentHP = Math.min(mon.stats.hp, mon.currentHP + healAmount);
    }
    mon.fainted = false;
    mon.moves.forEach((move) => {
      move.pp = Math.min(move.maxPP, move.pp + 5);
    });
  });
  crashDummyActive = false;
  console.log("continueBattle: Calling startBattle...");
  startBattle();
  console.log("continueBattle: Finished.");
}
function restartGame() {
  dom.gameOverScreen.style.display = "none";
  dom.winLoseGif.style.display = "none";
  dom.battleScreen.style.display = "none";
  dom.selectionScreen.style.display = "block";
  playerTeam = [];
  opponentTeam = [];
  activePlayerIndex = 0;
  activeOpponentIndex = 0;
  playerCurrentHP = 0;
  opponentCurrentHP = 0;
  resetStagesAndStatus();
  resetItems();
  crashDummyActive = false;
  isPlayerTurn = true;
  playerMove = null;
  fadeCounter = 0;
  document
    .querySelectorAll(".character-card.selected")
    .forEach((card) => card.classList.remove("selected"));
  updateTeamPreview();
  clearBattleLog();
  clearFloatingLog();
  updateFadeDisplay();
  if (dom.opponentInfoText) dom.opponentInfoText.textContent = "";
}
function delay(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}
function addAnimationClass(element, className) {
  element.classList.remove(className);
  void element.offsetWidth;
  const handleAnimationEnd = () => {
    if (element.classList.contains(className)) {
      element.classList.remove(className);
    }
    element.removeEventListener("animationend", handleAnimationEnd);
  };
  element.addEventListener("animationend", handleAnimationEnd);
  element.classList.add(className);
}
function share(platform) {
  const resultText = opponentTeam.every((yn) => yn.currentHP <= 0 || yn.fainted)
    ? "won"
    : "lost";
  const playerNames = playerTeam.map((m) => m.name).join(", ");
  const opponentNames = opponentTeam.map((m) => m.name).join(", ");
  const text = `I ${resultText} a Squabblemon battle! My Gang (${playerNames}) vs (${opponentNames}). Fades Won: ${fadeCounter} #Squabblemon`;
  const url = encodeURIComponent("https://your-squabblemon-game-link.com");
  let shareUrl;
  switch (platform) {
    case "facebook":
      shareUrl = `https://www.facebook.com/sharer/sharer.php?u=${url}"e=${encodeURIComponent(
        text
      )}`;
      break;
    case "reddit":
      shareUrl = `https://www.reddit.com/submit?url=${url}&title=${encodeURIComponent(
        text
      )}`;
      break;
    case "bluesky":
      shareUrl = `https://bsky.app/intent/compose?text=${encodeURIComponent(
        text + " " + url
      )}`;
      break;
  }
  if (shareUrl) {
    window.open(shareUrl, "_blank", "noopener,noreferrer");
  }
}

// End of script.js
