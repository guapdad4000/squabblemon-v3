import { PVP_SUPPORT } from './basePvpBalance';
import { selectedCards, fakeMarriage } from './selectedWave';
import { selectedReveal, selectedArrived, selectedMoved, selectedGain, selectedDamage, selectedResolved, type SelectedTools } from './selectedAbilities';
import { bossNpcCards } from './bossNpcCards';
import { streetLegendsCards } from './streetLegendsWave';
import { maryMackRoundEnd, maryMackRoundStart } from './maryMack';
import { streetLegendsReveal, streetLegendsPreventGain, streetLegendsGain, streetLegendsMoved, streetLegendsArrival, streetLegendsAfterPlay, streetLegendsRoundStart, streetLegendsCanMove, streetLegendsCleansed, streetLegendsTax, streetLegendsPaidAudit, streetLegendsIntercept, streetLegendsFinishIntercept, streetLegendsDistrictMarks, type StreetLegendsTools } from './streetLegendsAbilities';
import { MUSIC_CHARACTER_IDS, musicIndustryWaveCards } from './musicIndustryWave';
import { musicReveal, musicResolved, musicAfterPlay, musicMoved, musicDamage, musicGain, musicAfterAction, musicRoundEnd, musicRoundStart, musicCanMove, musicCleansed, musicDistrictMarks, type MusicTools, type MusicEntranceOutcome } from './musicIndustryAbilities';
import { HOMECOMING_KIT_IDS, homecomingReveal, homecomingArrival, homecomingAfterPlay, homecomingRoundEnd, type HomecomingTools } from './homecomingAbilities';
import { homecomingCards } from './homecomingWave';
import { isActiveOngoing } from './rosterBalance';
import { isHomelessCharacter } from './homelessFamily';
import { canEchoCreativeEntrance, creativeStatusApplied, creativePreventDamage, creativeCanCross, REPLACED_BONDS, CREATIVE_KITS, creativeAbilityResolved, creativeReveal, creativeMoved, creativeBeforeEntrance, creativeAfterPlay, creativeAfterAction, creativeDamage, creativeShieldBroken, creativeIntercept, creativeFinishIntercept, creativeAnchor, creativeAppeal, creativeCleansed, creativeRefund, creativeRoundEnd, creativeRoundStart, creativeAutomaticRoutes, creativeDistrictMarks, type CreativeMark, type CreativeTools } from './creativeReworks';
export { blockbusterExtraCost } from './blockbusterRules';
import { blockbusterWaveCards } from './blockbusterWave';
import { resolveBlockbusterWave, blockbusterExtraCost, type LaneDamage, type DiceResult, type BlockbusterTools } from './blockbusterRules';
import { canonicalElement, cards, catalogCardByEngineId, catalogIdsToEngineIds, decks, DECK_SIZE, MAX_MOTION, districts as legacyDistricts, type Card, type Deck } from './data';
import { validateDistrictSnapshot, type DistrictSnapshot, type DistrictDisplay } from './districts';
import { expansionCards } from './blockExpansion';
import { streetWaveCards } from './streetWave';
import { mythicLegendCards } from './mythicLegends';
import { CANNOT_LOSE_HANDS_CARD_IDS, GANG_BY_CARD_ID, GANG_LABEL, isMythicalTripleOg, TRIPLE_OG_LANE, UNSILENCEABLE_CARD_IDS, tripleOgCards, type GangColor } from './tripleOgs';
import { characterWaveCards } from './characterWave';
import { fairytaleCards } from './fairytaleWave';
import { neighborhoodWaveCards, DEMARIO_MUSHROOM, LUIGION_POWERED } from './neighborhoodWave';
import { cellblockWaveCards } from './cellblockWave';
import { afterHoursWaveCards } from './afterHoursWave';
import { elementalBondWaveCards } from './elementalBondWave';
import { sideOzWaveCards, sideOzWaveFactions } from './sideOzWave';
import { storyCharacterWaveCards } from './storyCharacterWave';
import { squabblehouseWaveCards, squabblehouseStaffCardIds } from './squabblehouseWave';
import {
  CONTINUOUS_POWER_DEPARTURES, rawCombatPower, syncContinuousPower,
} from './continuousPower';
export { createDistrictSnapshot, validateDistrictSnapshot, DISTRICT_CATALOG } from './districts';
export type { DistrictSnapshot, DistrictId, DistrictDisplay } from './districts';
import {
  createAbilityUpgradeSnapshot, snapshotUpgradesForCard, validateAbilityUpgradeSnapshot,
  type AbilityUpgradeSnapshot,
} from "./abilityUpgrades";
import type { CardProgressionMap } from "./cardProgression";
export {
  createAbilityUpgradeSnapshot, snapshotUpgradesForCard, unlockedAbilityUpgrades,
  validateAbilityUpgradeSnapshot, ABILITY_UPGRADE_SNAPSHOT_VERSION,
} from "./abilityUpgrades";
export type { AbilityUpgradeSnapshot, CardAbilityUpgradeSnapshot } from "./abilityUpgrades";
import { elementalWaveCards } from './elementalWave';

export { isMythicalTripleOg };

export type Owner = 'player' | 'cpu';
export type Phase = 'player' | 'cpu-reveal' | 'resolved' | 'complete';
export type Lane = 0 | 1 | 2;
export type StoryTrigger =
  | { readonly kind: "round"; readonly atLeast: number }
  | { readonly kind: "total-power"; readonly owner: Owner; readonly atLeast: number }
  | { readonly kind: "districts-held"; readonly owner: Owner; readonly atLeast: number };
export type StoryEffect =
  | { readonly kind: "motion"; readonly owner: Owner; readonly amount: number }
  | { readonly kind: "reinforcement"; readonly owner: Owner; readonly cardId: string; readonly allowDuplicate?: boolean }
  | { readonly kind: "draw"; readonly owner: Owner; readonly amount: number }
  | { readonly kind: "lane-power"; readonly owner: Owner | "both"; readonly lane: Lane; readonly amount: number }
  | { readonly kind: "lane-lock"; readonly owner: Owner | "both"; readonly lanes: readonly Lane[] };
export const DEFAULT_MATCH_ROUND_LIMIT = 6;
export type StoryObjectiveCriterion =
  | { readonly kind: "win" }
  | { readonly kind: "districts-held"; readonly owner: Owner; readonly atLeast: number }
  | { readonly kind: "specific-districts-held"; readonly owner: Owner; readonly lanes: readonly Lane[] }
  | { readonly kind: "squabble-used"; readonly owner: Owner; readonly used: boolean }
  | { readonly kind: "motion-remaining"; readonly owner: Owner; readonly atLeast: number }
  | { readonly kind: "cards-moved"; readonly owner: Owner; readonly atLeast: number };
export type StoryStarObjective = {
  readonly id: string;
  readonly description: string;
  /** Missing only on encounters saved before objective criteria were introduced. */
  readonly criterion?: StoryObjectiveCriterion;
  /** Victory goals still require a win when collecting a missing star on a replay. */
  readonly requiresWin?: boolean;
};
export type StoryEncounterSnapshot = {
  readonly id: string;
  readonly activity?: { readonly kind: string; readonly seed: string; readonly normalized: boolean; readonly previousCardIds?: readonly string[] };
  readonly enemy: {
    readonly id: string;
    readonly name: string;
    readonly portraitAssetId: string;
    readonly deckId: string;
    readonly cardIds: readonly string[];
    readonly behaviorProfile: string;
  };
  readonly battlefieldAssetId: string;
  readonly cinematic?: {
    readonly videoAssetId: string;
    readonly posterAssetId: string;
    readonly environmentAssetId: string;
  };
  readonly passive?: {
    readonly name: string;
    readonly description: string;
  };
  readonly soundHooks: Readonly<Record<string, string>>;
  /** Defaults to six for legacy snapshots and standard matches. */
  readonly roundLimit?: number;
  readonly modifiers?: {
    readonly startingMotion?: Partial<Readonly<Record<Owner, number>>>;
    readonly handSize?: Partial<Readonly<Record<Owner, number>>>;
    readonly laneLocks?: readonly { readonly round: number; readonly owner: Owner | "both"; readonly lanes: readonly Lane[] }[];
    readonly roundMotionDeltas?: readonly { readonly round: number; readonly owner: Owner; readonly amount: number }[];
    readonly lanePowerBonuses?: readonly { readonly owner: Owner | "both"; readonly lane: Lane; readonly amount: number }[];
    readonly reinforcements?: readonly { readonly round: number; readonly owner: Owner; readonly cardId: string; readonly allowDuplicate?: boolean }[];
  };
  readonly phases?: readonly {
    readonly id: string;
    readonly name: string;
    readonly description?: string;
    readonly trigger: StoryTrigger;
    readonly onEnter?: readonly StoryEffect[];
  }[];
  readonly starObjectives?: readonly StoryStarObjective[];
};
export type StoryRuntime = {
  activePhaseIndex: number;
  appliedEffectIds: string[];
  lanePowerBonuses: { owner: Owner | "both"; lane: Lane; amount: number }[];
  laneLocks: { owner: Owner | "both"; lanes: Lane[] }[];
  /** Deck slots already dealt early by a named reinforcement. */
  drawnReserveIndexes?: Partial<Record<Owner, number[]>>;
  /** Outside-deck character reinforcements remain one identity after leaving play. */
  reinforcedCharacterIds?: Partial<Record<Owner, string[]>>;
};
export type Statuses = { frozen: boolean; silenced: boolean; protected: boolean; blocked: boolean; uncounterable: boolean; weakened: boolean; locked: boolean; boosted: boolean; burnStacks: number };
export type CardInstance = Card & {
  instanceId: string; cardId: string; owner: Owner; lane: Lane | null; playedRound: number | null;
  basePower: number; powerModifier: number; continuousPower?: number; moved: boolean; statuses: Statuses; lastEffectNote: string;
  /** Bounded progress for the creative card kits. */
  creativeEntranceSucceeded?: boolean;
  creativeTipIds?: string[];
  creativeUsed?: Record<string, boolean>;
  creativeVisits?: Lane[];
  creativeAhead?: boolean;
  creativeRound?: number;
  creativeCount?: number;
  creativeTarget?: string;
  creativeLane?: Lane;
  /** Imposter keeps Scammer's identity/artwork while adopting a printed passive. */
  copiedAbilityCardId?: string;
  /** Leroy keeps his awakened portrait after Golden Glow successfully resolves. */
  goldenGlow?: boolean;
  networkBoosts?: number;
  /** Homeless Legend may refuse destruction once per match. */
  legendSaved?: boolean;
  recoverableDamage?: number;
  idolId?: string;
  fanRound?: number;
  waveTrainingUsed?: boolean;
  /** Recruitment changes match control once; collection ownership never changes. */
  swookieRecruited?: boolean;
  /** Caffeine consumes printed Hands, so bouncing cannot heal its cost. */
  rainmakerCrashes?: number;
  rainmakerRefundUsed?: boolean;
  /** Mary charges once at round end and transforms once per instance. */
  maryCents?: number;
  maryCollectionRound?: number;
  maryElephant?: boolean;
  maryTransformUsed?: boolean;
  /** Lil Blue's once-only cover for the next deployed friendly card. */
  blueCoverReady?: boolean;
  /** OG Red Night gets one steal opportunity per round for three rounds total. */
  redNightStartRound?: number;
  redNightLastRound?: number;
  homecomingEncores?: number;
  homecomingEncoreRound?: number;
  /** A Luigion deployment can consume only one Mushroom, never from an echo. */
  luigionMushroomUsed?: boolean;
  waveOnce?: Partial<Record<'alice' | 'bonnetgirl' | 'undercova' | 'oz', boolean>>;
  waveRounds?: Partial<Record<'tinman' | 'lion' | 'ronald' | 'trapvamp' | 'squabblecook' | 'godofhookah', number>>;
  aliceReady?: boolean;
  /** Mr Rabbit's one-use discount granted when this character last returned to hand. */
  rabbitReturnDiscount?: boolean;
  /** Set on a character put on by INITIATION; purely an identity tag. */
  gangTag?: GangColor;
  /** LOOK OUT is watching for the opponent's next district. */
  lookoutReady?: boolean;
  /** A lookout can make at most three calls, and at most one each round. */
  lookoutCalls?: number;
  lookoutCallRound?: number;
  bankedMotion?: number;
  burnSource?: { instanceId: string; owner: Owner };
  wildInvestment?: number;
  wildEmptyWallet?: boolean;
  /** Owner is the occupied enemy side; sourceOwner receives any kill credit. */
  smileBomb?: { sourceInstanceId: string; sourceOwner: Owner; detonatesAtRound: number };
  /** One FINNAM! resolution per owner per round, including echoes. */
  guapRound?: number;
  /** Buddy's battle-only form persists on the instance, including in replay frames. */
  buddyForm?: 'earth' | 'squabble-earth';
  /** Monotonic summon/play order; movement never changes which card arrived last. */
  arrivalOrder?: number;
  /** Round-end resolution for the normal form's delayed growth. */
  buddyGrowthAtRound?: number;
  /** Buddy Bud metadata; tokens are engine-created and never part of a deck. */
  buddyBud?: { readonly sourceInstanceId: string; readonly sproutsAtRound: number; readonly sprouted: boolean };
  /** The transformed form's active-through round; effects expire at its start. */
  buddyEarthExpiresAtRound?: number;
  /** Sports Prodigy's one-time delayed comeback window survives snapshots and replay. */
  sportsComebackArmed?: boolean;
  sportsComebackUsed?: boolean;
  sportsComebackUntilRound?: number;
  /** Squabblehouse per-instance round marks are replay-safe and reset by round comparison. */
  squabblehouseEffectRound?: number;
  squabblehouseGuardRound?: number;
  squabblehouseSecurityRound?: number;
  squabblehouseTeknicianRound?: number;
  squabblehouseTeknicianRevealRound?: number;
  squabblehouseManagerRound?: number;
  squabblehouseBusBoyPatrolRound?: number;
  squabblehouseBusBoyDirection?: -1 | 1;
  /** Cashier's instance-scoped movement lock lasts through this round number. */
  squabblehouseCannotMoveThroughRound?: number;
};

export type EffectKind = 'ability' | 'fire' | 'water' | 'move' | 'blocked' | 'story';
export type EffectLogEntry = {
  sequence: number; round: number; type: EventType; timing: 'instant' | 'timed';
  duration: EventDuration | null; source: EventParticipant | null; targets: EventParticipant[];
  scores: { before: ScoreState[]; after: ScoreState[] };
  resources: { before: ResourceState; after: ResourceState };
  state: { before: RoundState; after: RoundState };
  replay: { before: ReplayState; after: ReplayState };
  // Kept as presentation fields so existing battle UI can consume the authoritative event stream.
  cardInstanceId: string; cardId: string; owner: Owner; lane: Lane; kind: EffectKind; note: string;
  /** Present only for a card-growth upgrade resolution, never client supplied. */
  abilityMetadata?: {
    readonly upgradeId: string; readonly upgradeName: string; readonly sourceCardId: string;
    readonly sourceInstanceId: string; readonly targetInstanceIds: readonly string[];
    readonly result: "applied";
  };
};
export type ReplayState = Pick<Match,
  'round' | 'phase' | 'playerHand' | 'cpuHand' | 'boards' | 'playerMotion' | 'cpuMotion' |
  'nextArrivalOrder' | 'afterParty' | 'laneDamage' | 'diceResult' | 'undercovaPayouts' |
  'swookieRecruitment' | 'rainmakerPayouts' | 'foodzCommunityServed' |
  'playerDrawIndex' | 'cpuDrawIndex' | 'squabbleUsed' | 'plugDiscountLane' |
  'cheapBuffsUsed' | 'timedEffects' | 'discountTokens' | 'nextDiscountOrder' | 'landlordTaxUsed' |
  'creativeMarks' | 'districtTraps' | 'janitorReversals' | 'lastMovedAlly' | 'roundMovedIds' | 'entranceHistory' | 'guapRounds' | 'cheshireRounds' | 'electricPlays' | 'leaderRounds' | 'pendingLeaderReactions' | 'lingeringScents' | 'sneakerTriggered' | 'storyRuntime' | 'abilityUpgradeSnapshot' | 'squabbleByOwner' | 'districtSnapshot' | 'districtRuntime' | 'blueNextBonus' | 'squabblehouseRevealHistory'
>;

export type TimedEffect = {
  id: string; kind: 'wifey-protection' | 'church-protection' | 'nail-mitigation' | 'salon-protection' | 'buddy-earth-buff' | 'buddy-earth-debuff'; sourceInstanceId: string; owner: Owner; lane: Lane;
  targetInstanceId?: string; startsAtRound: number; expiresAtRound: number; expiration: 'round-start' | 'match-complete';
  /** Signed Hands change to undo at expiration for Buddy's temporary Earth form. */
  amount?: number;
};
export type DiscountToken = {
  startsAtRound?: number;
  id: string; owner: Owner; sourceInstanceId: string; eligibility: 'character-transfer' | 'selected-music' | 'any' | 'red-side' | 'printed-two-cost' | 'printed-four-plus' | 'another-district' | 'livewire-cross-district' | 'electric-delivery' | 'homecoming' | 'poison-character' | 'wiseman-prediction' | 'creative-local' | 'lookout-watch';
  targetLane?: Lane;
  targetInstanceId?: string;
  bonusHandsOnUse?: number;
  sourceLane: Lane | null; createdOrder: number;
  expiresAfterRound?: number;
};
export type DistrictRuntime = {
  plays: Record<Owner, [number, number, number]>;
  roundPlays: Record<Owner, [number, number, number]>;
  trailing: Record<Owner, [boolean, boolean, boolean]>;
  trappedCardIds: string[];
  detainedCardIds: string[];
};
const freshDistrictRuntime = (): DistrictRuntime => ({
  plays: { player: [0, 0, 0], cpu: [0, 0, 0] }, roundPlays: { player: [0, 0, 0], cpu: [0, 0, 0] },
  trailing: { player: [false, false, false], cpu: [false, false, false] }, trappedCardIds: [], detainedCardIds: [],
});
const DAMAGE_OWNER = Symbol("squabblemon.current-damage-owner");
/** Resolution-only accounting; bonuses removed by a transfer are never damage. */
const NON_DAMAGE_HANDS_LOSS = Symbol("squabblemon.non-damage-hands-loss");
const SUPPRESS_PRESENTATION_EVENTS = Symbol("squabblemon.search-without-presentation-events");
type LeaderKind = 'church' | 'nightmedic' | 'piratedj' | 'promoter' | 'gamer' | 'counter'
  | 'streetapostle' | 'fangirl' | 'asphaltapostle' | 'passportbro';
type LeaderReaction = { kind: LeaderKind; owner: Owner; sourceInstanceId: string; targetInstanceId: string; amount?: number; triggerLane?: Lane };
export type LingeringScent = { owner: Owner; lane: Lane; source: CardInstance; expiresAfterRound: number; triggeredRound?: number };
export type DistrictTrap = {
  kind: 'stakeout' | 'dmv' | 'wiseman' | 'dead-air' | 'initiation' | 'spinner' | 'open-tab';
  owner: Owner; lane: Lane; source: CardInstance; expiresAfterRound: number; spentRound?: number;
  /** An echoed setup keeps its base payoff, but cannot award ability training. */
  echoed?: boolean;
};
export type Match = {
  afterParty?: boolean;
  laneDamage?: LaneDamage[];
  repeatingLaneDamage?: boolean;
  /** Successful Inside Man payouts are shared by copies and survive returns/replay. */
  undercovaPayouts?: Partial<Record<Owner, { round: number; count: number }>>;
  swookieRecruitment?: Partial<Record<Owner, { attemptRound: number; count: number }>>;
  rainmakerPayouts?: Partial<Record<Owner, { round: number; count: number }>>;
  foodzCommunityServed?: Partial<Record<Owner, boolean>>;
  diceResult?: DiceResult;
  creativeMarks?: CreativeMark[];
  districtTraps?: DistrictTrap[];
  /** Delayed recruitment training remains spent even after its support leaves play. */
  initiationTrainedIds?: string[];
  /** Turn It Around damage/status and staff-removal charges, shared per district/round. */
  /** Missing charge tags on legacy records mean the original shared trigger was spent. */
  janitorReversals?: {
    owner: Owner; lane: Lane; round: number; sourceInstanceId: string; targetInstanceId: string;
    charge?: 'harm' | 'staff';
  }[];
  lastMovedAlly?: Partial<Record<Owner, { instanceId: string; round: number }>>;
  /** Successful board moves in the current round; unlike CardInstance.moved this expires each round. */
  roundMovedIds?: Record<Owner, string[]>;
  cheshireRounds?: Partial<Record<Owner, number>>;
  /** Per side, per leader ability: copies cannot multiply the once-per-round reward. */
  leaderRounds?: Partial<Record<Owner, Partial<Record<LeaderKind, number>>>>;
  electricPlays?: Partial<Record<Owner, { round: number; count: number }>>;
  /** Reactions settle after the triggering action, separately from its upgrade checks. */
  pendingLeaderReactions?: LeaderReaction[];
  lingeringScents?: LingeringScent[];
  [DAMAGE_OWNER]?: Owner;
  [NON_DAMAGE_HANDS_LOSS]?: Readonly<Record<string, number>>;
  [SUPPRESS_PRESENTATION_EVENTS]?: true;
  [CONTINUOUS_POWER_DEPARTURES]?: CardInstance[];
  /** Absent only for pre-location matches and their legacy transcripts. */
  districtSnapshot?: DistrictSnapshot;
  districtRuntime?: DistrictRuntime;
  /** Destroyed Blue Big Trippin cards reward the next friendly deployment. */
  blueNextBonus?: Partial<Record<Owner, number>>;
  /** Present only in human-vs-human matches; solo transcript semantics stay unchanged. */
  squabbleByOwner?: Record<Owner, boolean>;
  round: number; phase: Phase; playerDeck: string; cpuDeck: string; playerHand: CardInstance[]; cpuHand: CardInstance[];
  playerCardIds: string[]; cpuCardIds: string[];
  boards: [CardInstance[], CardInstance[], CardInstance[]]; playerMotion: number; cpuMotion: number;
  /** Stable order for new arrivals, independent of lane moves or board-array order. */
  nextArrivalOrder?: number;
  playerDrawIndex: number; cpuDrawIndex: number; squabbleUsed: boolean; plugDiscountLane: Record<Owner, Lane | null>;
  cheapBuffsUsed: Record<Owner, number>; effectLog: EffectLogEntry[]; nextEventSequence: number; timedEffects: TimedEffect[];
  discountTokens: DiscountToken[]; nextDiscountOrder: number; landlordTaxUsed: Record<Owner, Record<Lane, boolean>>;
  sneakerTriggered: Record<Owner, boolean>;
  /** Engine-internal Echo primitive. Tracks the last card whose On Reveal resolved this round. */
  lastRevealedCardId: string | null;
  /** Resolved entrance sources retained for Oz's once-per-match historical echo. */
  entranceHistory?: string[];
  /** Played Squabblehouse staff On Reveals, retained so Teknician can skip dead or disabled entries. */
  squabblehouseRevealHistory?: { owner: Owner; sourceInstanceId: string; cardId: string; round: number }[];
  guapRounds?: Partial<Record<Owner, number>>;
  storyEncounter?: StoryEncounterSnapshot; storyRuntime?: StoryRuntime;
  abilityUpgradeSnapshot: AbilityUpgradeSnapshot;
};
/** Search copies skip expensive presentation snapshots while preserving rules. */
export function suppressMatchPresentationEvents(match: Match): Match {
  const suppressed: Match = {
    ...match,
    [SUPPRESS_PRESENTATION_EVENTS]: true,
    effectLog: [],
  };
  delete suppressed[CONTINUOUS_POWER_DEPARTURES];
  return suppressed;
}
const lane = (n: number): Lane => n as Lane;
const emptyStatuses = (): Statuses => ({ frozen: false, silenced: false, protected: false, blocked: false, uncounterable: false, weakened: false, locked: false, boosted: false, burnStacks: 0 });
const abilityCardId = (card: CardInstance) => card.copiedAbilityCardId ?? card.cardId;
export const createCardInstance = (cardId: string, owner: Owner, deck = 'custom', index = 0): CardInstance => {
  const card = cards[cardId] ?? (owner === 'cpu' ? bossNpcCards[cardId] : undefined);
  if (!card) throw new Error(`Unknown card ${cardId}`);
  return { ...card, cardId, instanceId: `${owner}:${deck}:${index}:${cardId}`, owner, deck, lane: null, playedRound: null, basePower: card.power, powerModifier: 0, moved: false, statuses: emptyStatuses(), lastEffectNote: 'Ready in hand.' };
};
const deckById = (id: string): Deck => {
  const deck = decks.find((item) => item.id === id);
  if (!deck) throw new Error(`Unknown deck ${id}`);
  return deck;
};

export function createMatch(
  playerDeck: string,
  cpuDeck: string,
  progression?: { readonly player?: CardProgressionMap; readonly cpu?: CardProgressionMap },
  suppliedAbilityUpgradeSnapshot?: AbilityUpgradeSnapshot,
  districtSnapshot?: DistrictSnapshot,
): Match {
  const p = deckById(playerDeck), c = deckById(cpuDeck);
  return createMatchFromEngineCards(p.id, p.cards, c.id, c.cards, undefined, progression, suppliedAbilityUpgradeSnapshot, districtSnapshot);
}

export function createMatchFromEngineCards(
  playerDeck: string,
  playerCardIds: string[],
  cpuDeck: string,
  cpuCardIds: string[],
  storyEncounter?: StoryEncounterSnapshot,
  progression?: { readonly player?: CardProgressionMap; readonly cpu?: CardProgressionMap },
  suppliedAbilityUpgradeSnapshot?: AbilityUpgradeSnapshot,
  districtSnapshot?: DistrictSnapshot,
): Match {
  for (const [owner, ids] of [['Player', playerCardIds], ['CPU', cpuCardIds]] as const) {
    if (ids.length !== DECK_SIZE || new Set(ids).size !== DECK_SIZE) throw new Error(`${owner} deck must contain ten unique cards`);
  }
  for (const cardId of [...playerCardIds, ...cpuCardIds]) {
    if (!cards[cardId]) throw new Error(`Unknown card ${cardId}`);
  }
  const playerHandSize = storyEncounter?.modifiers?.handSize?.player ?? 5;
  const cpuHandSize = storyEncounter?.modifiers?.handSize?.cpu ?? 5;
  const abilityUpgradeSnapshot = suppliedAbilityUpgradeSnapshot
    ? validateAbilityUpgradeSnapshot(suppliedAbilityUpgradeSnapshot, playerCardIds, cpuCardIds)
    : createAbilityUpgradeSnapshot(playerCardIds, cpuCardIds, progression);
  let match: Match = {
    round: 1, phase: "player", playerDeck, cpuDeck,
    playerHand: playerCardIds.slice(0, playerHandSize).map((id, i) => createCardInstance(id, "player", playerDeck, i)),
    cpuHand: cpuCardIds.slice(0, cpuHandSize).map((id, i) => createCardInstance(id, "cpu", cpuDeck, i)),
    playerCardIds: [...playerCardIds], cpuCardIds: [...cpuCardIds],
    boards: [[], [], []], nextArrivalOrder: 1,
    playerMotion: Math.min(MAX_MOTION, Math.max(0, storyEncounter?.modifiers?.startingMotion?.player ?? 2)),
    cpuMotion: Math.min(MAX_MOTION, Math.max(0, storyEncounter?.modifiers?.startingMotion?.cpu ?? 2)),
    playerDrawIndex: playerHandSize, cpuDrawIndex: cpuHandSize,
    squabbleUsed: false, plugDiscountLane: { player: null, cpu: null }, cheapBuffsUsed: { player: 0, cpu: 0 },
    effectLog: [], nextEventSequence: 1, timedEffects: [], discountTokens: [], nextDiscountOrder: 1,
    landlordTaxUsed: { player: { 0: false, 1: false, 2: false }, cpu: { 0: false, 1: false, 2: false } },
    sneakerTriggered: { player: false, cpu: false },
    lastRevealedCardId: null,
    laneDamage: [],
    roundMovedIds: { player: [], cpu: [] },
    entranceHistory: [],
    guapRounds: {},
    abilityUpgradeSnapshot,
    ...(districtSnapshot ? { districtSnapshot: validateDistrictSnapshot(districtSnapshot), districtRuntime: freshDistrictRuntime() } : {}),
    ...(storyEncounter ? {
      storyEncounter,
      storyRuntime: { activePhaseIndex: -1, appliedEffectIds: [], lanePowerBonuses: [], laneLocks: [] },
    } : {}),
  };
  match = refreshDistrictRound(applyStoryEffects(match));
  return applyStoryEffects(spawnHandDemarioMushrooms(match, false));
}

export function createMatchFromCatalog(
  playerDeck: string,
  playerCatalogCardIds: string[],
  cpuDeck: string,
  progression?: { readonly player?: CardProgressionMap; readonly cpu?: CardProgressionMap },
  districtSnapshot?: DistrictSnapshot,
): Match {
  const cpu = deckById(cpuDeck);
  return createMatchFromEngineCards(
    playerDeck,
    catalogIdsToEngineIds(playerCatalogCardIds),
    cpu.id,
    cpu.cards,
    undefined,
    progression,
    undefined,
    districtSnapshot,
  );
}

export function getEffectiveCardPower(card: CardInstance): number {
  return card.hazard || card.statuses.frozen ? 0 : rawCombatPower(card);
}
export const getRawCombatPower = rawCombatPower;
export const effectiveCardPower = getEffectiveCardPower;
const clearContinuousPowerDepartures = (match: Match): Match => {
  if (!match[CONTINUOUS_POWER_DEPARTURES]?.length) return match;
  const result = { ...match };
  delete result[CONTINUOUS_POWER_DEPARTURES];
  return result;
};
const reconcileContinuousPower = (match: Match): Match => {
  const synced = syncContinuousPower(match);
  return synced[SUPPRESS_PRESENTATION_EVENTS] ? clearContinuousPowerDepartures(synced) : synced;
};
export function getLaneScore(cardsInLane: CardInstance[], laneIndex: number): number {
  return cardsInLane.reduce((total, card) => {
    if (card.hazard) return total;
    const district = laneIndex === 0 && (card.type === 'Fire' || card.type === 'Dark') ? 2
      : laneIndex === 1 && card.roles?.includes('Disruption') ? 2
      : laneIndex === 2 && card.type === 'Electric' ? 3 : 0;
    return total + getEffectiveCardPower(card) + district;
  }, 0);
}
export function getDistrictCardBonus(card: Pick<CardInstance, "type" | "roles" | "hazard">, laneIndex: Lane): number {
  if (card.hazard) return 0;
  return laneIndex === 0 && (card.type === "Fire" || card.type === "Dark") ? 2
    : laneIndex === 1 && card.roles?.includes("Disruption") ? 2
    : laneIndex === 2 && card.type === "Electric" ? 3
    : 0;
}
export function getStoryLaneBonus(match: Match, owner: Owner, laneIndex: Lane): number {
  const base = match.storyEncounter?.modifiers?.lanePowerBonuses ?? [];
  const entered = match.storyRuntime?.lanePowerBonuses ?? [];
  return [...base, ...entered]
    .filter((bonus) => bonus.lane === laneIndex && (bonus.owner === owner || bonus.owner === "both"))
    .reduce((total, bonus) => total + bonus.amount, 0);
}
export function getLaneScoreForMatch(match: Match, cardsInLane: CardInstance[], laneIndex: Lane, owner?: Owner): number {
  cardsInLane = cardsInLane.filter(card => !card.hazard);
  const resolvedOwner = owner ?? cardsInLane[0]?.owner;
  const power = match.districtSnapshot
    ? cardsInLane.reduce((total, card) => total + getEffectiveCardPower(card) + getDistrictCardBonusForMatch(match, card, laneIndex, cardsInLane), 0)
    : getLaneScore(cardsInLane, laneIndex);
  return power + (resolvedOwner ? getDistrictSharedBonus(match, resolvedOwner, laneIndex, cardsInLane) + getStoryLaneBonus(match, resolvedOwner, laneIndex) : 0);
}
export function getDistrictCardBonusForMatch(match: Match, card: CardInstance, laneIndex: Lane, allies = match.boards[laneIndex].filter(c => c.owner === card.owner)): number {
  if (card.hazard) return 0;
  allies = allies.filter(ally => !ally.hazard);
  if (!match.districtSnapshot) return getDistrictCardBonus(card, laneIndex);
  if (card.statuses.frozen) return 0;
  const effect = match.districtSnapshot.locations[laneIndex].effect;
  if (effect.kind === 'champion-only') {
    const champion = highest(allies.filter(c => !c.statuses.frozen));
    return champion?.instanceId === card.instanceId ? 0 : -getEffectiveCardPower(card);
  }
  if (effect.kind === 'cost-power') return card.cost - getEffectiveCardPower(card);
  if (effect.kind === 'expensive') return card.cost >= effect.minimumCost ? effect.amount : 0;
  if (effect.kind === 'penthouse') return match.round >= effect.changesAtRound ? effect.crew : allies.length === 1 ? effect.solo : 0;
  // Location penalties suppress scoring, never destroy a card or make it negative.
  const penalty = (amount: number) => -Math.min(getEffectiveCardPower(card), amount);
  if (effect.kind === 'dive-discount') return penalty(effect.penalty);
  if (effect.kind === 'spotlight') return allies.at(-1)?.instanceId === card.instanceId ? effect.bonus : penalty(effect.penalty);
  if (effect.kind === 'cheap-crew') return card.cost <= effect.maximumCost ? Math.min(effect.maximumBonus, Math.max(0, allies.length - 1)) : 0;
  if (effect.kind === 'outnumber') {
    const enemies = match.boards[laneIndex].filter(c => !c.hazard && c.owner !== card.owner).length;
    return allies.length > enemies ? effect.bonus : allies.length < enemies ? penalty(effect.penalty) : 0;
  }
  return 0;
}
export function getDistrictSharedBonus(match: Match, owner: Owner, laneIndex: Lane, allies = match.boards[laneIndex].filter(c => c.owner === owner)): number {
  allies = allies.filter(ally => !ally.hazard);
  const effect = match.districtSnapshot?.locations[laneIndex].effect;
  const local = effect?.kind === 'diversity' && new Set(allies.map(c => canonicalElement(c.type))).size >= effect.types ? effect.amount : 0;
  let broadcast = 0;
  for (const [i, district] of (match.districtSnapshot?.locations ?? []).entries()) {
    const rule = district.effect;
    if (i !== laneIndex && rule.kind === 'broadcast'
      && inLane(match, owner, i as Lane).length === rule.requiredAllies) broadcast += rule.amount;
  }
  return local + broadcast;
}
export function getMatchDistricts(match?: Match | null, owner: Owner = 'player'): DistrictDisplay[] {
  if (!match?.districtSnapshot) return legacyDistricts.map((d, i) => ({ ...d, id: `legacy-${i}`, accent: '#fbbf24', status: '' }));
  return match.districtSnapshot.locations.map((d, i) => {
    const effect = d.effect, runtime = match.districtRuntime!;
    let status = '';
    if (effect.kind === 'first-discount') status = runtime.plays[owner][i] ? 'Your discount used' : 'Your first-play discount ready';
    if (effect.kind === 'comeback') status = runtime.roundPlays[owner][i] ? 'First play used this round' : runtime.trailing[owner][i] ? `Your comeback: +${effect.amount} ready` : 'You did not start behind';
    if (effect.kind === 'detain-first') status = runtime.plays[owner][i] ? 'Your first arrival recorded' : 'Your first arrival will be held';
    if (effect.kind === 'penthouse') status = match.round < effect.changesAtRound ? `Solo +${effect.solo} · Gang +${effect.crew} in R${effect.changesAtRound}` : `Party is on · +${effect.crew} per card`;
    if (effect.kind === 'diversity') status = `${new Set(match.boards[i].filter(c => !c.hazard && c.owner === owner).map(c => canonicalElement(c.type))).size}/${effect.types} card types in your gang`;
    if (effect.kind === 'late-arrival') status = match.round < effect.startsAtRound ? `Spotlight starts R${effect.startsAtRound}` : runtime.roundPlays[owner][i] ? 'Your spotlight used this round' : `Your spotlight: +${effect.amount} ready`;
    if (effect.kind === 'subway') status = runtime.roundPlays[owner][i] ? 'Your ride used this round' : `Next stop: ${match.districtSnapshot!.locations[(i + 1) % 3].name}`;
    if (effect.kind === 'outnumber') {
      const allies = match.boards[i].filter(c => !c.hazard && c.owner === owner).length, enemies = match.boards[i].filter(c => !c.hazard).length - allies;
      status = `${allies} vs ${enemies} cards · ${allies > enemies ? `+${effect.bonus}` : allies < enemies ? `−${effect.penalty}` : 'No modifier'}`;
    }
    if (effect.kind === 'spotlight') status = `Spotlight: ${match.boards[i].filter(c => !c.hazard && c.owner === owner).at(-1)?.name ?? 'your next arrival'}`;
    if (effect.kind === 'dive-discount') status = 'Cheap entry · Hands returns when you leave';
    if (effect.kind === 'cheap-crew') status = `Your cheap cards: +${Math.min(effect.maximumBonus, Math.max(0, match.boards[i].filter(c => !c.hazard && c.owner === owner).length - 1))} each`;
    if (effect.kind === 'tithe') status = runtime.roundPlays[owner][i] ? 'Your tithe paid this round' : `Next play: +${effect.tax} Motion / +${effect.amount} Hands`;
    if (effect.kind === 'salon-protection') status = runtime.roundPlays[owner][i] ? 'Your appointment used this round' : 'Your first-play protection ready';
    if (effect.kind === 'crew-cleanse') status = runtime.roundPlays[owner][i] ? 'Your cleanup used this round' : 'Your gang cleanup ready';
    if (effect.kind === 'champion-only') status = 'Only one champion scores per side';
    if (effect.kind === 'round-growth') status = match.round < getMatchRoundLimit(match) ? 'Next round: every card here grows +1' : 'Final harvest complete';
    if (effect.kind === 'pawn-sacrifice') status = runtime.roundPlays[owner][i] ? 'Your trade used this round' : 'Your next play trades your weakest ally';
    if (effect.kind === 'broadcast') status = inLane(match, owner, i as Lane).length === effect.requiredAllies ? 'ON AIR · +3 to both other lanes' : 'Exactly 2 allies needed to broadcast';
    if (effect.kind === 'silence-arrival') status = 'Direct plays enter Silenced';
    if (effect.kind === 'flood') status = match.round < effect.atRound ? 'Flood arrives at round 4' : 'Flood has passed';
    if (effect.kind === 'close-lane') status = match.round < effect.atRound ? 'Gates close at round 4' : 'CLOSED · Movement only';
    if (effect.kind === 'market-draw') status = runtime.roundPlays[owner][i] ? 'Your draw used this round' : 'Your next play draws a card';
    if (effect.kind === 'cost-power') status = 'Printed Motion becomes district Hands';
    if (effect.kind === 'feed-neighbors') status = runtime.roundPlays[owner][i] ? 'Your meal served this round' : 'Your next play feeds the other lanes';
    if (effect.kind === 'rush-hour') status = runtime.roundPlays.player[i] + runtime.roundPlays.cpu[i] > 0 ? 'Traffic cleared this round' : 'Next play pushes both gangs right';
    return { ...d, status };
  });
}
function refreshDistrictRound(match: Match): Match {
  if (!match.districtRuntime) return match;
  const scores = getDistrictResults(match);
  return { ...match, districtRuntime: { ...match.districtRuntime,
    roundPlays: { player: [0, 0, 0], cpu: [0, 0, 0] },
    trailing: { player: scores.map(s => s.player < s.cpu) as [boolean, boolean, boolean], cpu: scores.map(s => s.cpu < s.player) as [boolean, boolean, boolean] },
  } };
}
export function getDistrictResults(match: Match) {
  return match.boards.map((cardsInLane, i) => {
    const player = getLaneScoreForMatch(match, cardsInLane.filter((c) => c.owner === "player"), i as Lane, "player");
    const cpu = getLaneScoreForMatch(match, cardsInLane.filter((c) => c.owner === "cpu"), i as Lane, "cpu");
    return { lane: i as Lane, player, cpu, winner: player === cpu ? "draw" as const : player > cpu ? "player" as const : "cpu" as const };
  });
}
export function getMatchRoundLimit(value?: Match | StoryEncounterSnapshot | null): number {
  if (value && "round" in value && value.afterParty) return 7;
  const snapshot = value && "round" in value ? value.storyEncounter : value;
  const configured = snapshot?.roundLimit;
  return Number.isInteger(configured) && configured! >= 1 && configured! <= DEFAULT_MATCH_ROUND_LIMIT
    ? configured!
    : DEFAULT_MATCH_ROUND_LIMIT;
}
export function getMatchWinner(match: Match): Owner | 'draw' | null {
  const results = getDistrictResults(match), player = results.filter((r) => r.winner === 'player').length, cpu = results.filter((r) => r.winner === 'cpu').length;
  if (player >= 2) return 'player';
  if (cpu >= 2) return 'cpu';
  return match.round >= getMatchRoundLimit(match) && match.phase === 'complete' ? 'draw' : null;
}
export type StoryObjectiveEvaluation = StoryStarObjective & { readonly achieved: boolean };

const legacyStoryObjectiveCriterion = (objective: StoryStarObjective): StoryObjectiveCriterion | null => {
  if (objective.criterion) return objective.criterion;
  if (objective.id === "win") return { kind: "win" };
  if (objective.id === "districts") return { kind: "districts-held", owner: "player", atLeast: 3 };
  if (objective.id === "squabble") return { kind: "squabble-used", owner: "player", used: false };
  return null;
};

const historicallyMovedCardIds = (match: Match, owner: Owner): Set<string> => {
  // Keep final-card flags for legacy snapshots, then add every authoritative
  // board-to-board lane transition so later destruction cannot erase credit.
  const moved = new Set(match.boards.flat()
    .filter(card => card.owner === owner && card.moved)
    .map(card => card.instanceId));
  for (const event of match.effectLog) {
    if (event.kind !== "move") continue;
    for (const participant of [event.source, ...event.targets]) {
      if (!participant || participant.owner !== owner) continue;
      const beforeLane = participant.before?.lane;
      const afterLane = participant.after?.lane;
      if (beforeLane !== null && beforeLane !== undefined
        && afterLane !== null && afterLane !== undefined
        && beforeLane !== afterLane) moved.add(participant.cardInstanceId);
    }
  }
  return moved;
};
/** Evaluates saved and current story objectives from the final authoritative match state. */
export function evaluateStoryStarObjectives(
  match: Match,
  objectives: readonly StoryStarObjective[] = match.storyEncounter?.starObjectives ?? [],
  clearedReplay = false,
): StoryObjectiveEvaluation[] {
  const won = match.phase === "complete" && getMatchWinner(match) === "player";
  const results = getDistrictResults(match);
  const usedSquabble = (owner: Owner) => match.squabbleByOwner?.[owner] ?? (owner === "player" ? match.squabbleUsed : false);
  return objectives.map((objective) => {
    const criterion = legacyStoryObjectiveCriterion(objective);
    let achieved = false;
    const requiresWin = objective.requiresWin ?? (!criterion || criterion.kind === 'win'
      || (criterion.kind === 'squabble-used' && !criterion.used));
    if ((won || (clearedReplay && match.phase === 'complete' && !requiresWin)) && criterion) {
      switch (criterion.kind) {
        case "win": achieved = true; break;
        case "districts-held":
          achieved = results.filter((result) => result.winner === criterion.owner).length >= criterion.atLeast;
          break;
        case "specific-districts-held":
          achieved = criterion.lanes.every((target) => results[target]?.winner === criterion.owner);
          break;
        case "squabble-used": achieved = usedSquabble(criterion.owner) === criterion.used; break;
        case "motion-remaining": achieved = (criterion.owner === "player" ? match.playerMotion : match.cpuMotion) >= criterion.atLeast; break;
        case "cards-moved":
          achieved = historicallyMovedCardIds(match, criterion.owner).size >= criterion.atLeast;
          break;
      }
    }
    return { ...objective, achieved };
  });
}

export const getStoryStars = (match: Match): number =>
  evaluateStoryStarObjectives(match).filter((objective) => objective.achieved).length;
/** Objectives are permanent accomplishments; a replay can earn only its missing star. */
export function mergeStoryObjectiveProgress(match: Match, previousIds: readonly string[] = [], previousStars = 0, alreadyCleared = false) {
  const objectives = evaluateStoryStarObjectives(match, undefined, alreadyCleared);
  const allowed = new Set(objectives.map(objective => objective.id));
  const completedObjectiveIds = [...new Set([...previousIds.filter(id => allowed.has(id)),
    ...objectives.filter(objective => objective.achieved).map(objective => objective.id)])];
  return { completedObjectiveIds, stars: Math.min(3, Math.max(previousStars, completedObjectiveIds.length)) };
}
/** Recover only accomplishments proved by an old immutable completion receipt. */
export function recoverLegacyStoryObjectiveIds(receipts: readonly { outcome: string | null; districtsWon: number | null; storyStars: number | null; objectives: readonly StoryStarObjective[] }[]): string[] {
  const earned = new Set<string>();
  for (const receipt of receipts) {
    if (receipt.outcome !== 'win') continue;
    const classified = receipt.objectives.map(objective => {
      const criterion = legacyStoryObjectiveCriterion(objective);
      const achieved = criterion?.kind === 'win' ? true
        : criterion?.kind === 'districts-held' && criterion.owner === 'player' && receipt.districtsWon !== null
          ? receipt.districtsWon >= criterion.atLeast : null;
      return { id: objective.id, achieved };
    });
    const known = classified.filter(objective => objective.achieved === true);
    const unknown = classified.filter(objective => objective.achieved === null);
    for (const objective of known) earned.add(objective.id);
    if (known.length + unknown.length === receipt.storyStars)
      for (const objective of unknown) earned.add(objective.id);
  }
  return [...earned];
}
const activeLandlord = (match: Match, owner: Owner, targetLane: Lane) =>
  inLane(match, owner === "player" ? "cpu" : "player", targetLane)
    .some((card) => abilityCardId(card) === "landlord" && activeAbility(card));
const tokenEligible = (token: DiscountToken, card: CardInstance, targetLane: Lane) =>
  (token.eligibility === "homecoming" && token.targetInstanceId === card.instanceId)
  || (token.eligibility === 'selected-music' && token.sourceLane === targetLane && MUSIC_CHARACTER_IDS.includes(card.cardId))
  || token.eligibility === "any"
  || (token.eligibility === "character-transfer" && (card.kind ?? "character") === "character" && !card.hazard)
  || (token.eligibility === 'red-side' && sideOzWaveFactions[card.cardId] === 'Red Side')
  || (token.eligibility === "printed-two-cost" && card.cost === 2)
  || (token.eligibility === "printed-four-plus" && card.cost >= 4)
  || ((token.eligibility === "another-district" || token.eligibility === "livewire-cross-district") && token.sourceLane !== targetLane)
  || (token.eligibility === 'electric-delivery' && token.targetLane === targetLane
    && card.type === 'Electric' && (card.kind ?? 'character') === 'character' && !card.hazard)
  || ((token.eligibility === 'wiseman-prediction' || token.eligibility === 'creative-local') && token.targetLane === targetLane
    && (card.kind ?? 'character') === 'character' && !card.hazard)
  || (token.eligibility === 'lookout-watch' && token.targetLane === targetLane)
  || (token.eligibility === 'poison-character'
    && card.type === 'Poison' && (card.kind ?? 'character') === 'character' && !card.hazard);
const discountFor = (match: Match, owner: Owner, card: CardInstance, targetLane: Lane) =>
  [...(match.discountTokens ?? [])].filter(token => (token.startsAtRound === undefined || token.startsAtRound <= match.round) && (token.expiresAfterRound === undefined || token.expiresAfterRound >= match.round))
    .sort((a, b) => Number(b.eligibility === 'homecoming' && b.targetInstanceId === card.instanceId)
      - Number(a.eligibility === 'homecoming' && a.targetInstanceId === card.instanceId)
      || Number(b.eligibility === 'wiseman-prediction') - Number(a.eligibility === 'wiseman-prediction')
      || Number(b.eligibility === 'electric-delivery') - Number(a.eligibility === 'electric-delivery')
      || a.createdOrder - b.createdOrder || a.id.localeCompare(b.id))
    .find((token) => token.owner === owner && tokenEligible(token, card, targetLane));
const districtDiscount = (match: Match, owner: Owner, card: CardInstance, targetLane: Lane): number => {
  const effect = match.districtSnapshot?.locations[targetLane].effect;
  return effect?.kind === 'dive-discount' || (effect?.kind === 'first-discount' && match.districtRuntime?.plays[owner][targetLane] === 0)
    ? Math.min(effect.amount, Math.max(0, card.cost - effect.minimum)) : 0;
};
const districtTax = (match: Match, owner: Owner, targetLane: Lane): number => {
  const effect = match.districtSnapshot?.locations[targetLane].effect;
  return effect?.kind === 'tithe' && match.districtRuntime?.roundPlays[owner][targetLane] === 0 ? effect.tax : 0;
};
export function getLegalCardCost(match: Match, owner: Owner, card: CardInstance, targetLane: Lane): number {
  const legacyDiscount = (match.discountTokens ?? []).length === 0
    && match.plugDiscountLane[owner] !== null && match.plugDiscountLane[owner] !== targetLane;
  const buddyLaneDiscount = inLane(match, owner, targetLane).some(buddy =>
    buddy.cardId === 'buddy' && buddy.buddyForm !== 'squabble-earth' && activeAbility(buddy));
  const token = discountFor(match, owner, card, targetLane);
  const discount = token || legacyDiscount || buddyLaneDiscount;
  const taxed = activeLandlord(match, owner, targetLane) && !(match.landlordTaxUsed?.[owner]?.[targetLane] ?? false);
  const ignoresLocationMotionPenalty = isMythicalTripleOg(card.cardId) && TRIPLE_OG_LANE[card.cardId] === targetLane;
  const aliceReturnDiscount = card.cardId === 'alice' && !!card.aliceReady;
  const minimum = aliceReturnDiscount || card.rabbitReturnDiscount || token?.eligibility === 'homecoming' || token?.eligibility === 'selected-music' || token?.eligibility === 'wiseman-prediction' || token?.eligibility === 'creative-local' ? 1 : 0;
  const reduction = discount ? (token?.eligibility === 'wiseman-prediction' ? 2 : 1)
    : districtDiscount(match, owner, card, targetLane);
  return Math.max(minimum, card.cost - reduction - (aliceReturnDiscount ? 1 : 0) - (card.rabbitReturnDiscount ? 1 : 0))
    + (taxed ? 1 : 0) + (ignoresLocationMotionPenalty ? 0 : districtTax(match, owner, targetLane))
    + (dmvTax(match, owner, targetLane) ? 1 : 0) + streetLegendsTax(match, owner, targetLane, card);
}
export function getCardCostExplanation(match: Match, owner: Owner, card: CardInstance, targetLane: Lane): string {
  const token = discountFor(match, owner, card, targetLane);
  const legacy = !token && (match.discountTokens ?? []).length === 0 && match.plugDiscountLane[owner] !== null && match.plugDiscountLane[owner] !== targetLane;
  const buddyLaneDiscount = inLane(match, owner, targetLane).some(buddy =>
    buddy.cardId === 'buddy' && buddy.buddyForm !== 'squabble-earth' && activeAbility(buddy));
  const taxed = activeLandlord(match, owner, targetLane) && !(match.landlordTaxUsed?.[owner]?.[targetLane] ?? false);
  const ignoresLocationMotionPenalty = isMythicalTripleOg(card.cardId) && TRIPLE_OG_LANE[card.cardId] === targetLane;
  const parts = [`${card.cost} base`];
  if (token || legacy) parts.push(token?.eligibility === "wiseman-prediction" ? "−2 Told You discount" : "−1 discount");
  else if (buddyLaneDiscount) parts.push("−1 BUDDY district discount");
  else if (districtDiscount(match, owner, card, targetLane)) parts.push(match.districtSnapshot?.locations[targetLane].effect.kind === 'dive-discount' ? "−1 Dive Bar discount" : "−1 Bodega opening discount");
  if (token?.eligibility === "creative-local") parts.push("Local pass minimum 1 Motion");
  if (token?.eligibility === "homecoming") parts.push("Homecoming minimum 1 Motion");
  if (token?.eligibility === "wiseman-prediction") parts.push("Told You minimum 1 Motion");
  if (card.cardId === 'alice' && card.aliceReady) parts.push("−1 Drink Me / Eat Me return discount (minimum 1 Motion)");
  if (card.rabbitReturnDiscount) parts.push("−1 Pocket Watch return discount (minimum 1 Motion)");
  if (dmvTax(match, owner, targetLane)) parts.push("+1 Take a Number");
  if (streetLegendsTax(match, owner, targetLane, card)) parts.push('+1 PAY WHAT YOU OWE Audit');
  if (taxed) parts.push("+1 Rent Due tax");
  if (districtTax(match, owner, targetLane) && !ignoresLocationMotionPenalty) parts.push("+1 Corrupt Church tithe");
  else if (districtTax(match, owner, targetLane) && ignoresLocationMotionPenalty) parts.push("Corrupt Church tithe ignored for home-side Triple OG");
  return parts.join(" · ");
}
const dmvTax = (m: Match, owner: Owner, lane: Lane) => (m.districtTraps ?? []).some(t => t.kind === "dmv" && t.owner !== owner && t.lane === lane && t.expiresAfterRound >= m.round);
export type CharacterDistrictMark = { owner: Owner; lane: Lane; text: string; artworkId?: string; id?: string; sourceId?: string; targetIds?: string[]; expiresRound?: number; progress?: { current: number; total: number } };
export function getCharacterDistrictMarks(match: Match): CharacterDistrictMark[] {
  const janitorMarks = ([0, 1, 2] as Lane[]).flatMap(targetLane =>
    (['player', 'cpu'] as Owner[]).flatMap(owner => {
      const janitor = inLane(match, owner, targetLane)
        .filter(card => abilityCardId(card) === 'janitor' && activeAbility(card))
        .sort((a, b) => a.instanceId.localeCompare(b.instanceId))[0];
      if (!janitor) return [];
      const reversals = (match.janitorReversals ?? []).filter(item =>
        item.owner === owner && item.lane === targetLane && item.round === match.round);
      const spent = (charge: 'harm' | 'staff') =>
        reversals.some(item => item.charge === undefined || item.charge === charge);
      return [{
        owner,
        lane: targetLane,
        text: `Turn It Around · harm ${spent('harm') ? 'spent' : 'ready'} · staff ${spent('staff') ? 'spent' : 'ready'}`,
      }];
    }));
  return [
    ...janitorMarks,
    ...creativeDistrictMarks(match).filter(mark => !mark.text.includes('mi-') && !mark.text.includes('sl-')),
    ...streetLegendsDistrictMarks(match),
    ...musicDistrictMarks(match),
    ...match.discountTokens.filter(t => t.eligibility === 'character-transfer' && t.sourceLane !== undefined).map(t => ({owner:t.owner,lane:t.sourceLane!,text:`Transfer Ticket · next character anywhere: −1 Motion / +${t.bonusHandsOnUse ?? 0} Hands · until used`})),
    ...match.discountTokens.filter(t => t.eligibility === 'creative-local' && t.targetLane !== undefined && (t.expiresAfterRound??99) >= match.round).map(t => ({owner:t.owner,lane:t.targetLane!,text:`Local pass · next character here −1 Motion (minimum 1) · R${t.startsAtRound}–${t.expiresAfterRound}`})),
    ...(match.districtTraps ?? []).filter(t => t.expiresAfterRound >= match.round
      && (t.kind !== 'dead-air' || match.boards[t.lane].some(c => c.instanceId === t.source.instanceId && activeAbility(c)))).map(t => ({ owner: t.owner, lane: t.lane,
      text: t.kind === 'wiseman' ? 'Told You · next enemy character: here = Weaken; elsewhere = predictor gets −2 Motion here · through R' + t.expiresAfterRound
        : (t.kind === 'stakeout' ? 'Stakeout · next enemy entrance canceled'
          : t.kind === 'dead-air' ? 'Dead Air · first enemy played or moved here: Silence'
          : t.kind === 'initiation' ? 'Marked Territory · your next character here gets put on: +1 Hand'
          : t.kind === 'spinner' ? 'Spinning · next enemy played here: 1 Burn'
           : t.kind === 'open-tab' ? `Open Tab · ${t.spentRound === match.round ? 'spent' : 'ready'} this round · through R${t.expiresAfterRound}`
           : 'Take a Number · next enemy: +1 Motion') + (t.kind === 'initiation' || t.kind === 'open-tab' ? '' : ' · through R' + t.expiresAfterRound) })),
    ...(match.lingeringScents ?? []).filter(s => s.expiresAfterRound >= match.round).map(s => ({
      owner: s.owner, lane: s.lane, text: 'Scent · ' + (s.triggeredRound === match.round ? 'spent this round' : 'next enemy: 2 Burn') + ' · through R' + s.expiresAfterRound,
    })),
    ...match.discountTokens.filter(t => t.eligibility === 'wiseman-prediction' && t.targetLane !== undefined
      && (t.expiresAfterRound === undefined || t.expiresAfterRound >= match.round)).map(t => ({
      owner: t.owner, lane: t.targetLane!, text: 'Told You · next character here: −2 Motion (minimum 1) · through R' + t.expiresAfterRound,
    })),
    ...match.discountTokens.filter(t => t.eligibility === 'electric-delivery' && t.targetLane !== undefined).map(t => ({
      owner: t.owner, lane: t.targetLane!, text: 'Package · next Electric: −1 Motion / +2 Hands',
    })),
  ];
}
export const getDiscountedCardCost = getLegalCardCost;
export function canAffordSelection(match: Match, owner: Owner, instanceId: string, targetLane: Lane): boolean {
  const card = (owner === "player" ? match.playerHand : match.cpuHand).find((c) => c.instanceId === instanceId);
  return !!card
    && (!isMythicalTripleOg(card.cardId) || TRIPLE_OG_LANE[card.cardId] === targetLane)
    && (isMythicalTripleOg(card.cardId) || !getStoryLockedLanes(match, owner).includes(targetLane))
    && getLegalCardCost(match, owner, card, targetLane) + (card.cardId === 'the-dice-game' ? 1 : 0) <= (owner === "player" ? match.playerMotion : match.cpuMotion)
    && (card.cardId !== 'the-dice-game' || (owner === 'player' ? match.cpuMotion : match.playerMotion) >= 1);
}

export type LegalPlayIntent = { instanceId: string; cardId: string; lane: Lane; cost: number; squabble: boolean; investment: number };
/** Shared policy candidates; authority still validates the chosen single command. */
export function listLegalPlayIntents(match: Match, owner: Owner, allowSquabble = true): LegalPlayIntent[] {
  if (match.phase !== (owner === 'player' ? 'player' : 'cpu-reveal')) return [];
  const hand = owner === 'player' ? match.playerHand : match.cpuHand;
  const motion = owner === 'player' ? match.playerMotion : match.cpuMotion;
  const opposingMotion = owner === 'player' ? match.cpuMotion : match.playerMotion;
  const squabbleAvailable = allowSquabble && (match.squabbleByOwner ? !match.squabbleByOwner[owner] : owner === 'player' && !match.squabbleUsed);
  const result: LegalPlayIntent[] = [];
  for (const card of hand) {
    if (squabblehouseMovementLocked(match, card)) continue;
    // Dice's zero choice is its canonical one-Motion wager; do not duplicate it as choice1.
    const investments = card.cardId === 'the-dice-game' ? [0, 2, 3]
      : card.cardId === 'the-concert' ? [0, 1]
      : card.cardId === 'homelessguy' && activeAbility(card) ? [0, 1, 2, 3, 4] : [0];
    const forms = squabbleAvailable && card.kind !== 'support' && card.kind !== 'blockbuster' ? [false, true] : [false];
    for (const target of [0, 1, 2] as Lane[]) {
      if (!canAffordSelection(match, owner, card.instanceId, target)) continue;
      const baseCost = getLegalCardCost(match, owner, card, target);
      for (const investment of investments) {
        const extraCost = blockbusterExtraCost(card.cardId, investment);
        if (baseCost + extraCost > motion || (card.cardId === 'the-dice-game' && extraCost > opposingMotion)) continue;
        for (const squabble of forms) result.push({ instanceId: card.instanceId, cardId: card.cardId,
          lane: target, cost: baseCost + extraCost, squabble, investment });
      }
    }
  }
  return result;
}

/** Cards whose Hands can never be reduced. Extend through the Triple OG set, not new hardcodes. */
const cannotLoseHands = (card: Pick<CardInstance, 'cardId'>) => (CANNOT_LOSE_HANDS_CARD_IDS as readonly string[]).includes(card.cardId);
const cannotLoseHandsLabel = (card: Pick<CardInstance, 'cardId' | 'name'>) => card.cardId === 'blueside1' ? 'OG Blue' : card.name;
const activeAbility = (card: CardInstance) => !card.hazard && !card.statuses.silenced && !card.statuses.frozen && !card.statuses.weakened;
const modify = (m: Match, id: string, change: (c: CardInstance) => CardInstance, copiedGain = false, nonDamage = false): Match => {
  const before = m.boards.flat().find(c => c.instanceId === id);
  if (!before) return m;
  let after = change(before);
  if (cannotLoseHands(before) && after.powerModifier < before.powerModifier) {
    after = { ...after, powerModifier: before.powerModifier,
      lastEffectNote: after.lastEffectNote + ` ${cannotLoseHandsLabel(before)} cannot lose Hands.` };
  }
  if(!nonDamage && after.powerModifier<before.powerModifier) {
    const prevented=creativePreventDamage(m,before,before.powerModifier-after.powerModifier,m[DAMAGE_OWNER]);
    const absorbed=before.powerModifier-after.powerModifier-prevented.amount;
    m=prevented.match;
    after={...after,powerModifier:before.powerModifier-prevented.amount,...(absorbed?{lastEffectNote:after.lastEffectNote+' Emergency Kit prevented '+absorbed+' Hands of damage.'}:{})};
  }
  if (after.powerModifier > before.powerModifier) {
    const checked = streetLegendsPreventGain(m, before, after.powerModifier - before.powerModifier);
    m = checked.match;
    after = { ...after, powerModifier: before.powerModifier + checked.amount };
  }
  const delta = after.powerModifier - before.powerModifier;
  let result = reconcileContinuousPower({ ...m, boards: m.boards.map(items => items.map(c => c.instanceId === id ? after : c)) as Match['boards'] });
  const damagedState = findCard(result, id) ?? after;
  const actualDamage = Math.min(
    Math.max(0, rawCombatPower(before) - rawCombatPower(damagedState)),
    Math.max(0, before.powerModifier - after.powerModifier),
  );
  if (!nonDamage && abilityCardId(before) === 'homelesslegend' && actualDamage > 0) {
    result = { ...result, boards: result.boards.map(items => items.map(c => c.instanceId === id
      ? { ...c, recoverableDamage: (before.recoverableDamage ?? 0) + actualDamage } : c)) as Match['boards'] };
  }
  if (!nonDamage && delta < 0 && before.lane !== null && !before.hazard && !m.repeatingLaneDamage) {
    result = { ...result, laneDamage: [...(m.laneDamage ?? []).filter(d => d.round === m.round), {
      round: m.round, lane: before.lane, instanceId: id, amount: actualDamage,
    }].filter(d => d.amount > 0) };
  }
  if (delta <= 0 || before.lane === null || before.hazard) return result;
  for (const fan of m.boards.flat().filter(c => c.owner === before.owner && abilityCardId(c) === 'fangirl'
    && c.idolId === id && c.fanRound !== m.round && activeAbility(c))) {
    result = { ...result, boards: result.boards.map(items => items.map(c => c.instanceId === fan.instanceId ? { ...c, fanRound: m.round } : c)) as Match['boards'],
      pendingLeaderReactions: [...(result.pendingLeaderReactions ?? []), { kind: 'fangirl', owner: fan.owner, sourceInstanceId: fan.instanceId, targetInstanceId: fan.instanceId }] };
  }
  if (!copiedGain && before.type === 'Plant' && before.kind !== 'support'
    && result.leaderRounds?.[before.owner]?.streetapostle !== m.round) {
    const leader = m.boards.flat().find(c => c.owner === before.owner && c.instanceId !== id
      && abilityCardId(c) === 'streetapostle' && activeAbility(c));
    if (leader) result = { ...result,
      leaderRounds: { ...result.leaderRounds, [before.owner]: { ...result.leaderRounds?.[before.owner], streetapostle: m.round } },
      pendingLeaderReactions: [...(result.pendingLeaderReactions ?? []), { kind: 'streetapostle', owner: before.owner,
        sourceInstanceId: leader.instanceId, targetInstanceId: id, amount: Math.min(2, delta), triggerLane: before.lane }] };
  }
  return selectedGain(m, streetLegendsGain(m, musicGain(m, result, before, waveTools()), before, waveTools(), copiedGain), before, waveTools(), copiedGain);
};

const findCard = (m: Match, id: string): CardInstance | undefined =>
  [...m.playerHand, ...m.cpuHand, ...m.boards.flat()].find((c) => c.instanceId === id);
const nextArrivalOrder = (m: Match): number => Math.max(
  m.nextArrivalOrder ?? 1,
  ...m.boards.flat().map(card => (card.arrivalOrder ?? 0) + 1),
);
const inLane = (m: Match, owner: Owner, target: Lane) => m.boards[target].filter((c) => !c.hazard && c.owner === owner);
const highest = (items: CardInstance[]) => items.filter(card => !card.hazard).sort((a, b) => getEffectiveCardPower(b) - getEffectiveCardPower(a) || a.instanceId.localeCompare(b.instanceId))[0];
const lowest = (items: CardInstance[]) => items.filter(card => !card.hazard).sort((a, b) => getEffectiveCardPower(a) - getEffectiveCardPower(b) || a.instanceId.localeCompare(b.instanceId))[0];
const squabblehouseMovementLocked = (m: Match, card: CardInstance) =>
  (card.squabblehouseCannotMoveThroughRound ?? 0) >= m.round;
const isSquabblehouseStaffCharacter = (card: CardInstance) =>
  (card.kind ?? 'character') === 'character' && !card.hazard && squabblehouseStaffCardIds.has(card.cardId);
function deadAirArrival(m: Match, id: string, lane: Lane): Match {
  const entrant = findCard(m, id);
  if (!entrant || entrant.hazard || (entrant.kind ?? 'character') !== 'character') return m;
  const trap = (m.districtTraps ?? []).find(t => {
    if (t.kind !== 'dead-air' || t.owner === entrant.owner || t.lane !== lane || t.expiresAfterRound < m.round) return false;
    const goth = findCard(m, t.source.instanceId);
    return goth?.lane === lane && activeAbility(goth);
  });
  if (!trap) return m;
  const before = m;
  m = { ...m, districtTraps: m.districtTraps!.filter(t => t !== trap) };
  const goth = findCard(m, trap.source.instanceId)!;
  m = hostileEffect(m, goth, entrant, (state, actual) =>
    queueDisruptionReactions(state, modify(state, actual.instanceId, c => ({
      ...c,
      statuses: { ...c.statuses, silenced: true },
      lastEffectNote: 'Dead Air: first enemy to enter this district was Silenced.',
    })), goth, actual.instanceId), false, false, true);
  const silenced = findCard(m, id)?.statuses.silenced;
  return addEvent(before, m, { type: 'ability', sourceId: trap.source.instanceId, owner: trap.owner,
    lane, targetIds: [id], note: silenced
      ? 'Dead Air Silenced the first enemy entering this district before its ability.'
      : 'Dead Air triggered, but the arriving enemy resisted or intercepted its Silence.' });
}
function movementCapacityAvailable(
  m: Match, card: CardInstance, destination: Lane, vacatingInstanceIds: readonly string[] = [],
): boolean {
  const vacating = new Set(vacatingInstanceIds);
  return inLane(m, card.owner, destination).filter(candidate => !vacating.has(candidate.instanceId)).length < 4;
}
const move = (
  m: Match, card: CardInstance, destination: Lane, note: string,
  deferArrival = false, captureBeforeArrival = false, skipOpenTab = false, allowFullDestination = false,
): Match => {
  if (card.hazard) return m;
  if (!musicCanMove(m, card.instanceId) || !streetLegendsCanMove(m, card.instanceId)) return modify(m, card.instanceId, c => ({ ...c, lastEffectNote: 'Contract or Curfew blocked movement.' }));
  const sourceLane = card.lane ?? m.boards.findIndex((items) => items.some((candidate) => candidate.instanceId === card.instanceId)) as Lane;
  if (sourceLane === destination) return m;
  if (m.districtRuntime?.detainedCardIds.includes(card.instanceId)) {
    return modify(m, card.instanceId, c => ({ ...c, lastEffectNote: 'COUNTY JAIL blocked movement.' }));
  }
  if (getStoryRuleLockedLanes(m, card.owner).includes(destination)) {
    return modify(m, card.instanceId, c => ({ ...c, lastEffectNote: 'Lane lock blocked movement.' }));
  }
  if (squabblehouseMovementLocked(m, card)) {
    return modify(m, card.instanceId, c => ({ ...c, lastEffectNote: 'Pay Your Tab: cannot move through the end of next round.' }));
  }
  if (card.statuses.locked && !creativeCanCross(m,card.instanceId)) {
    return modify(m, card.instanceId, c => ({ ...c, lastEffectNote: 'LOCKED: cannot be moved.' }));
  }
  if (!allowFullDestination && !movementCapacityAvailable(m, card, destination)) {
    return modify(m, card.instanceId, c => ({ ...c, lastEffectNote: 'DISTRICT FULL: cannot be moved there.' }));
  }
  if (!skipOpenTab) {
    const departure = openTabDeparture(m, card);
    m = departure.match;
    if (departure.stopped) return m;
  }
  card = findCard(m, card.instanceId) ?? card;
  const beforeMove = m;
  const effect = m.districtSnapshot?.locations[destination].effect;
  const trapBonus = effect?.kind === 'move-bonus' && !m.districtRuntime!.trappedCardIds.includes(card.instanceId) ? effect.amount : 0;
  const updated = { ...card, lane: destination, moved: true, powerModifier: card.powerModifier + trapBonus, lastEffectNote: note + (trapBonus ? ` THE TRAP: +${trapBonus} Hands.` : '') };
  if (trapBonus) m = { ...m, districtRuntime: { ...m.districtRuntime!, trappedCardIds: [...m.districtRuntime!.trappedCardIds, card.instanceId] } };
  let moved = { ...m, boards: m.boards.map((items, i) => i === sourceLane ? items.filter((c) => c.instanceId !== card.instanceId) : i === destination ? [...items, { ...updated, powerModifier: card.powerModifier }] : items) as Match['boards'] };
  if (trapBonus) moved = modify(moved, card.instanceId, c => ({ ...c, powerModifier: c.powerModifier + trapBonus }));
  if (abilityCardId(card) === 'gothkid') moved = { ...moved,
    districtTraps: (moved.districtTraps ?? []).filter(t => t.kind !== 'dead-air' || t.source.instanceId !== card.instanceId) };
  const recordMovedInstance = (state: Match): Match => ({
    ...state,
    lastMovedAlly: { ...state.lastMovedAlly, [card.owner]: { instanceId: card.instanceId, round: state.round } },
    roundMovedIds: {
      player: [...new Set([...(state.roundMovedIds?.player ?? []), ...(card.owner === 'player' ? [card.instanceId] : [])])],
      cpu: [...new Set([...(state.roundMovedIds?.cpu ?? []), ...(card.owner === 'cpu' ? [card.instanceId] : [])])],
    },
  });
  if (captureBeforeArrival) moved = recordMovedInstance(moved);
  // Some movers need a distinct movement frame before arrival reactions resolve.
  let moveFrameCaptured = false;
  if (captureBeforeArrival) {
    moved = addEvent(beforeMove, moved, { type: 'ability', kind: 'move', sourceId: card.instanceId,
      owner: card.owner, lane: destination, targetIds: [card.instanceId],
      note: `${card.name} moved from district ${sourceLane + 1} to district ${destination + 1}.` });
    moveFrameCaptured = true;
  }
  // Preserve the move as its own replay frame before the arrival consumes the trap.
  if (!moveFrameCaptured && (card.kind ?? 'character') === 'character' && (moved.districtTraps ?? []).some(t =>
    t.kind === 'dead-air' && t.owner !== card.owner && t.lane === destination && t.expiresAfterRound >= moved.round
    && moved.boards[destination].some(c => c.instanceId === t.source.instanceId && activeAbility(c)))) {
    moved = addEvent(beforeMove, moved, { type: 'ability', kind: 'move', sourceId: card.instanceId, owner: card.owner,
      lane: destination, targetIds: [card.instanceId], note: card.name + ' moved into district ' + (destination + 1) + '.' });
  }
  if (['cane-corso-red', 'blue-nose-pit'].includes(card.cardId)
    && moved.effectLog.length === beforeMove.effectLog.length) {
    moved = addEvent(beforeMove, moved, { type: 'ability', kind: 'move', sourceId: card.instanceId,
      owner: card.owner, lane: destination, targetIds: [card.instanceId],
      note: `${card.name} walked one adjacent lane toward its matching OG.` });
  }
  moved = deadAirArrival(moved, card.instanceId, destination);
  moved = squabblehouseSecurityArrival(moved, card.instanceId);
  moved = squabblehouseManagerArrival(moved, card.instanceId);
  moved = queueLeaderReaction(moved, 'promoter', card.instanceId, m);
  const enemy = card.owner === 'player' ? 'cpu' : 'player';
  if (getLaneScoreForMatch(m, inLane(m, card.owner, sourceLane), sourceLane, card.owner)
    < getLaneScoreForMatch(m, inLane(m, enemy, sourceLane), sourceLane, enemy)) {
    moved = queueLeaderReaction(moved, 'passportbro', card.instanceId, m);
  }
  if (!captureBeforeArrival) moved = recordMovedInstance(moved);
  if (deferArrival) return moved;
  moved = fairytaleDeparture(moved, card);
  moved = fairytaleArrival(moved, card.instanceId, true);
  moved = homecomingArrival(creativeMoved(m, applyScentEntry(moved, card.instanceId), card.instanceId, creativeTools()), card.instanceId, homecomingTools());
  moved = streetLegendsMoved(m, moved, card.instanceId, waveTools());
  return selectedMoved(m, musicMoved(m, moved, card.instanceId, waveTools()), card.instanceId, waveTools());
};
const lowestFriendlyLane = (m: Match, owner: Owner, except: Lane): Lane => ([0, 1, 2] as Lane[]).filter((x) => x !== except).sort((a, b) => getLaneScoreForMatch(m, inLane(m, owner, a), a, owner) - getLaneScoreForMatch(m, inLane(m, owner, b), b, owner) || a - b)[0];

/** Ongoing effect primitives: Burn / Weaken / Lock / Boost. */
/**
 * Elemental hierarchy — the type-vs-type bonus table that makes matchups matter.
 * Fire burns Plant, Water extinguishes Fire, Plant drinks Water, Electric conducts
 * through Water, Air carries Electric, Earth grounds Electric, Light vs Dark.
 * When an attacker of type X targets a defender of type Y and X beats Y, Burn and
 * direct reductions get +1 stack. Stacking multiple bonuses caps at +1 per matchup.
 */
const ELEMENTAL_MATCHUP_BONUS: Record<string, Record<string, number>> = {
  Fire: { Plant: 1 },
  Plant: { Water: 1 },
  Water: { Fire: 1 },
  Electric: { Water: 1 },
  Air: { Electric: 1 },
  Earth: { Electric: 1 },
  Light: { Dark: 1 },
  Dark: { Light: 1 },
};
const elementalMatchupBonus = (attackerType: string, defenderType: string): number =>
  ELEMENTAL_MATCHUP_BONUS[canonicalElement(attackerType)]?.[canonicalElement(defenderType)] ?? 0;

const applyBurn = (m: Match, source: CardInstance, target: CardInstance, stacks: number, note: string): Match =>
  hostileEffect(m, source, target, (state, actual) => {
    const bonus = elementalMatchupBonus(source.type, actual.type);
    return modify(state, actual.instanceId, c => ({ ...c,
      burnSource: { instanceId: source.instanceId, owner: source.owner },
      statuses: { ...c.statuses, burnStacks: (c.statuses.burnStacks ?? 0) + stacks + bonus },
      lastEffectNote: note + (bonus ? ' (+' + bonus + ' elemental bonus)' : ''),
    }));
  }, false, false, true);
const applyWeaken = (m: Match, source: CardInstance, target: CardInstance, note: string): Match =>
  targetEnemy(m, source, target, c => ({ ...c, statuses: { ...c.statuses, weakened: true }, lastEffectNote: note }));
const applyLock = (m: Match, source: CardInstance, target: CardInstance, note: string): Match =>
  targetEnemy(m, source, target, c => ({ ...c, statuses: { ...c.statuses, locked: true }, lastEffectNote: note }));
const applyBoost = (m: Match, card: CardInstance, note: string): Match =>
  modify(m, card.instanceId, c => ({ ...c, statuses: { ...c.statuses, boosted: true }, lastEffectNote: note }));
/** Single source of truth for cleanse: remove debuffs without stripping friendly buffs. */
const cleanseStatuses = (statuses: Statuses): Statuses => ({
  ...statuses, frozen: false, silenced: false, weakened: false, locked: false, burnStacks: 0,
});
const needsCleanse = (card: CardInstance): boolean => card.statuses.frozen || card.statuses.silenced
  || card.statuses.weakened || card.statuses.locked || card.statuses.burnStacks > 0;

const queueLeaderReaction = (
  match: Match, kind: LeaderKind, targetId: string, beforeTrigger: Match = match,
): Match => {
  const target = match.boards.flat().find(card => card.instanceId === targetId);
  const type = kind === 'promoter' ? 'Air' : kind === 'piratedj' ? 'Electric'
    : kind === 'gamer' || kind === 'counter' ? 'Dark'
    : kind === 'passportbro' ? 'Water'
    : kind === 'streetapostle' ? 'Plant'
    : kind === 'asphaltapostle' ? 'Earth' : 'Light';
  if (!target || target.hazard || target.kind === 'support' || (target.type !== type && !(kind === 'promoter' && ['bottle', 'piratedj', 'dancecaptain'].includes(target.cardId)))
    || match.leaderRounds?.[target.owner]?.[kind] === match.round) return match;
  // Check the leader at the moment of the block/cleanse. A disabled Medic cannot
  // reward her own recovery, and a later reveal cannot retroactively earn credit.
  const leader = beforeTrigger.boards.flat().find(card => !card.hazard && card.owner === target.owner
    && abilityCardId(card) === kind && (kind !== 'passportbro' || card.instanceId !== targetId) && activeAbility(card));
  if (!leader) return match;
  return {
    ...match,
    leaderRounds: { ...match.leaderRounds,
      [target.owner]: { ...match.leaderRounds?.[target.owner], [kind]: match.round } },
    pendingLeaderReactions: [...(match.pendingLeaderReactions ?? []),
      { kind, owner: target.owner, sourceInstanceId: leader.instanceId, targetInstanceId: targetId }],
  };
};

const queueDisruptionReactions = (before: Match, after: Match, source: CardInstance, targetId: string): Match => {
  const old = findCard(before, targetId), target = findCard(after, targetId);
  if (!old || !target || target.owner === source.owner || target.hazard
    || !((!old.statuses.silenced && target.statuses.silenced) || (!old.statuses.weakened && target.statuses.weakened))) return after;
  const allies = after.boards.flat().filter(c => !c.hazard && c.kind !== 'support' && c.owner === source.owner && c.type === 'Dark');
  let result = after;
  const gamerTarget = lowest(allies);
  if (gamerTarget) result = queueLeaderReaction(result, 'gamer', gamerTarget.instanceId, before);


  return result;
};

const recordElectricPlay = (match: Match, card: CardInstance): Match => {
  if (card.type !== 'Electric' || (card.kind ?? 'character') !== 'character' || card.hazard) return match;
  const previous = match.electricPlays?.[card.owner];
  const count = (previous?.round === match.round ? previous.count : 0) + 1;
  const counted = { ...match, electricPlays: { ...match.electricPlays, [card.owner]: { round: match.round, count } } };
  if (count !== 2) return counted;
  let result = queueLeaderReaction(counted, 'piratedj', card.instanceId);
  const mailman = result.boards.flat().find(c => c.owner === card.owner && abilityCardId(c) === 'mailman' && activeAbility(c));
  if (mailman && !result.discountTokens.some(t => t.owner === card.owner && t.eligibility === 'electric-delivery')) {
    const destinations = ([0, 1, 2] as Lane[]).filter(l => l !== card.lane && !getStoryLockedLanes(result, card.owner).includes(l));
    destinations.sort((a, b) => getLaneScoreForMatch(result, inLane(result, card.owner, a), a, card.owner)
      - getLaneScoreForMatch(result, inLane(result, card.owner, b), b, card.owner) || a - b);
    if (destinations.length) {
      const before = result, order = result.nextDiscountOrder;
      result = { ...result, nextDiscountOrder: order + 1, discountTokens: [...result.discountTokens, {
        id: 'package:' + card.owner + ':' + order, owner: card.owner, sourceInstanceId: mailman.instanceId,
        eligibility: 'electric-delivery', sourceLane: card.lane, targetLane: destinations[0], createdOrder: order,
      }] };
      result = trainWaveAbility(result, mailman.instanceId);
      result = addEvent(before, result, { type: 'ability', sourceId: mailman.instanceId, owner: card.owner,
        lane: destinations[0], note: 'Express Delivery: Package waiting in district ' + (destinations[0] + 1) + ' (−1 Motion, +2 Hands for the next Electric character).' });
    }
  }
  return result;
};

const cleanseAlly = (match: Match, targetId: string, apply: (card: CardInstance) => CardInstance): Match => {
  const before = findCard(match, targetId);
  const after = musicCleansed(streetLegendsCleansed(creativeCleansed(modify(match, targetId, apply), targetId), targetId), targetId, waveTools());
  const cleansed = findCard(after, targetId);
  return before && cleansed && needsCleanse(before) && !needsCleanse(cleansed)
    ? queueLeaderReaction(after, 'nightmedic', targetId, match) : after;
};

const settleLeaderReactions = (match: Match): Match => {
  if (!match.pendingLeaderReactions?.length) return match;
  let result = match;
  while (result.pendingLeaderReactions?.length) {
    const reaction = result.pendingLeaderReactions[0];
    const before = result;
    result = { ...result, pendingLeaderReactions: result.pendingLeaderReactions!.slice(1) };
    const target = result.boards.flat().find(c => c.instanceId === reaction.targetInstanceId);
    if (reaction.kind === 'streetapostle') {
      const recipients = ([0, 1, 2] as Lane[]).filter(l => l !== reaction.triggerLane)
        .map(l => lowest(inLane(result, reaction.owner, l).filter(c => c.type === 'Plant' && c.kind !== 'support')))
        .filter((c): c is CardInstance => !!c);
      for (const ally of recipients) result = modify(result, ally.instanceId, c => ({
        ...c, powerModifier: c.powerModifier + (reaction.amount ?? 0), lastEffectNote: 'Spread the Word: +' + reaction.amount + ' Hands.',
      }), true);
      if (recipients.length) {
        result = trainWaveAbility(result, reaction.sourceInstanceId);
        result = addEvent(before, result, { type: 'ability', sourceId: reaction.sourceInstanceId, owner: reaction.owner,
          targetIds: recipients.map(c => c.instanceId), note: 'Spread the Word copied +' + reaction.amount + ' Hands to each other Plant district.' });
      }
      continue;
    }
    if (!target) continue;
    const note = reaction.kind === 'church'
      ? 'Covered: a protection block gave ' + target.name + ' +2 Hands (once per round).'
      : reaction.kind === 'nightmedic'
      ? 'All Clear: cleansing gave ' + target.name + ' +2 Hands (once per round).'
      : reaction.kind === 'promoter'
      ? 'Guest List: moving gave ' + target.name + ' +2 Hands (once per round).'
      : reaction.kind === 'gamer'
      ? 'City Tour: successful disruption gave ' + target.name + ' +2 Hands (once per round).'
      : reaction.kind === 'piratedj'
      ? 'Citywide Signal: your second Electric play gained +1 Hand.'
      : reaction.kind === 'passportbro'
      ? 'Geographic Arbitrage: leaving a losing district cleansed this Water ally and gave +3 Hands.'
      : reaction.kind === 'fangirl'
      ? 'Day One: your idol gained Hands; +1 Hand (once per round).'
      : 'Mirror: successful disruption protected ' + target.name + ' (once per round).';
    if (reaction.kind === 'counter') {
      if (target.statuses.protected) continue;
      result = modify(result, target.instanceId, card => ({
        ...card, statuses: { ...card.statuses, protected: true }, lastEffectNote: note,
      }));
      result = { ...result, timedEffects: [...result.timedEffects, {
        id: 'dark-cover:' + reaction.sourceInstanceId + ':' + result.round,
        kind: 'church-protection', sourceInstanceId: reaction.sourceInstanceId,
        targetInstanceId: target.instanceId, owner: reaction.owner, lane: target.lane!,
        startsAtRound: result.round, expiresAtRound: 7, expiration: 'match-complete',
      }] };
    } else if (reaction.kind === 'passportbro') {
      result = cleanseAlly(result, target.instanceId, card => ({
        ...card, statuses: cleanseStatuses(card.statuses), powerModifier: card.powerModifier + 3, lastEffectNote: note,
      }));
    } else {
      result = modify(result, target.instanceId, card => ({
        ...card, powerModifier: card.powerModifier + (reaction.kind === 'piratedj' || reaction.kind === 'fangirl' ? 1 : 2), lastEffectNote: note,
      }));
    }
    result = trainWaveAbility(result, reaction.sourceInstanceId);
    result = addEvent(before, result, { type: 'ability', sourceId: reaction.sourceInstanceId,
      owner: reaction.owner, targetIds: [target.instanceId], note });
  }
  return result;
};

/**
 * Round-end effects that fire as a round transitions to the next.
 * - Burn deals its stacked damage, then decays to 0.
 * - Boost grants +1 Hands to each affected card while the buff remains active.
 */
const applyOngoingRoundEndEffects = (m: Match): Match => {
  let result = m;
  // Snapshot the tick. Newly passed Burn never deals damage in this same round.
  const burningAtStart = new Set(m.boards.flat().filter(c => c.statuses.burnStacks > 0).map(c => c.instanceId));
  const smokeSources = (['player', 'cpu'] as Owner[]).map(owner =>
    m.boards.flat().find(c => c.owner === owner && abilityCardId(c) === 'godofhookah' && activeAbility(c))).filter((c): c is CardInstance => !!c);
  const burnedLanes: Partial<Record<Owner, Set<Lane>>> = {};
  for (const card of m.boards.flat().filter(c => c.statuses.burnStacks > 0)) {
    const beforeBurn = result;
    const currentBurning = result.boards.flat().find(c => c.instanceId === card.instanceId);
    if (!currentBurning) continue;
    const damage = currentBurning.statuses.uncounterable ? 0 : currentBurning.statuses.burnStacks;
    const janitorReversal = damage > 0 && currentBurning.burnSource
      ? reverseWithJanitor(result, currentBurning, currentBurning.burnSource.owner, 'harm', c => ({
        ...c, statuses: { ...c.statuses, burnStacks: 0 }, burnSource: undefined,
        lastEffectNote: 'Turn It Around: enemy Burn negated; +2 Hands.',
      })) : null;
    if (janitorReversal) {
      result = janitorReversal;
      continue;
    }
    result = withDamageOwner(result,currentBurning.burnSource?.owner,state=>modify(state, card.instanceId, c => ({ ...c,
      powerModifier: c.powerModifier - damage, statuses: { ...c.statuses, burnStacks: 0 },
      lastEffectNote: 'BURN: −' + damage + ' Hands at round end.',
    })));
    if (damage > 0 && directDamageAmount(beforeBurn, result, currentBurning) > 0) {
      const enemy = card.owner === 'player' ? 'cpu' : 'player';
      (burnedLanes[enemy] ??= new Set()).add(card.lane!);
    }
    // Ordinary Burn keeps the engine's existing zero-Hands rules. Built Different
    // must still catch a lethal Burn reduction and use its one survival.
    if (damage > 0 && abilityCardId(card) === 'homelesslegend') result = removeDestroyedCard(result, card.instanceId);
    result = recordDamage(beforeBurn, result, card.burnSource ?? { instanceId: '', owner: card.owner === 'player' ? 'cpu' : 'player' }, currentBurning, !!card.burnSource, true);
  }
  for (const source of smokeSources) {
    const enemy = source.owner === 'player' ? 'cpu' : 'player';
    for (const origin of burnedLanes[source.owner] ?? []) {
      const destination = ((origin + 1) % 3) as Lane;
      const target = lowest(inLane(result, enemy, destination).filter(c => !burningAtStart.has(c.instanceId) && c.statuses.burnStacks === 0));
      if (!target) {
        const adjacent = inLane(result, enemy, destination);
        const live = findCard(result, source.instanceId);
        if (adjacent.length && adjacent.every(c => burningAtStart.has(c.instanceId) || c.statuses.burnStacks > 0)
          && live && activeAbility(live) && live.waveRounds?.godofhookah !== result.round) {
          const before = result;
          result = waveRound(result, live.instanceId, 'godofhookah');
          result = modify(result, live.instanceId, c => ({ ...c, powerModifier: c.powerModifier + 1 }));
          result = trainWaveAbility(result, live.instanceId);
          result = addEvent(before, result, { type: 'ability', sourceId: live.instanceId, owner: live.owner, targetIds: [live.instanceId], note: 'Pass the Hose: adjacent enemies already burning; +1 Hand, once this round.' });
        }
        continue;
      }
      const before = result;
      result = applyBurn(result, source, target, 1, 'Pass the Hose: 1 Burn; ticks next round.');
      if ((findCard(result, target.instanceId)?.statuses.burnStacks ?? 0) > 0) result = trainWaveAbility(result, source.instanceId);
      result = addEvent(before, result, { type: 'ability', sourceId: source.instanceId, owner: source.owner,
        targetIds: [target.instanceId], lane: destination, note: 'Pass the Hose sent 1 Burn to the next district. It waits until next round.' });
    }
  }
  for (const card of result.boards.flat()) {
    if (card.statuses.boosted) {
      result = modify(result, card.instanceId, c => ({ ...c, powerModifier: c.powerModifier + 1, lastEffectNote: 'BOOST: +1 Hands at round end.' }));
    }
  }
  // Alchy: round 4+ conditional round-end gain (+1, +2 if losing the district).
  if (result.round >= 4) {
    for (const card of result.boards.flat().filter(c => c.cardId === 'alchy' && !c.statuses.silenced && !c.statuses.frozen && !c.statuses.weakened && c.lane !== null)) {
      const cardLane = card.lane as Lane;
      const enemy = card.owner === 'player' ? 'cpu' : 'player';
      const losing = getLaneScoreForMatch(result, inLane(result, card.owner, cardLane), cardLane, card.owner) < getLaneScoreForMatch(result, inLane(result, enemy, cardLane), cardLane, enemy);
      const trainedBonus = snapshotUpgradesForCard(result.abilityUpgradeSnapshot, card.owner, card.cardId).length;
      const gain = (losing ? 2 : 1) + trainedBonus;
      result = modify(result, card.instanceId, c => ({
        ...c,
        powerModifier: c.powerModifier + gain,
        lastEffectNote: `Last Round: +${gain} Hands${losing ? ' (losing)' : ''}${trainedBonus ? `, including +${trainedBonus} trained` : ''}.`,
      }));
    }
  }
  for (const card of result.boards.flat().filter(c => abilityCardId(c) === 'homelesslegend' && activeAbility(c))) {
    const restored = Math.min(2, card.recoverableDamage ?? 0);
    if (!restored) continue;
    result = modify(result, card.instanceId, c => ({ ...c, powerModifier: c.powerModifier + restored,
      recoverableDamage: Math.max(0, (c.recoverableDamage ?? 0) - restored), lastEffectNote: 'Built Different: recovered ' + restored + ' lost Hands.' }));
    result = trainWaveAbility(result, card.instanceId);
  }
  return reconcileContinuousPower(result);
};

/**
 * Hand-resident ongoing effects that fire at round end. GUAP set the template:
 * while an elemental-bond card is in its owner's hand, every other friendly
 * character of the same type gains +1 Hands. All ten types, including Normal,
 * have a carrier declared in ELEMENTAL_HAND_BONUS_CARDS.
 */
const applyOngoingRoundEndHandEffects = (m: Match): Match => {
  let result = m;
  for (const hand of [result.playerHand, result.cpuHand] as const) {
    for (const card of hand) {
      if (REPLACED_BONDS.has(card.cardId)) continue;
      const bond = card.elementalBond && canonicalElement(card.elementalBond);
      if (!bond) continue;
      const eligibleAllies = result.boards.flat().filter(c => !c.hazard && c.owner === card.owner && c.kind !== 'support' && canonicalElement(c.type) === bond && c.instanceId !== card.instanceId);
      // Sushi Chef serves one Water ally per district; wide boards earn more plates.
      const allies = abilityCardId(card) === 'monsoonanchor'
        ? ([0, 1, 2] as Lane[]).map(lane => lowest(eligibleAllies.filter(c => c.lane === lane))).filter((c): c is CardInstance => !!c)
        : eligibleAllies;
      for (const ally of allies) {
        result = modify(result, ally.instanceId, c => ({
          ...c,
          powerModifier: c.powerModifier + 1,
          lastEffectNote: `${card.name}: ${bond} bond +1 Hands.`,
        }));
      }
      // Pure hand bonds spend their trained tiers on at most three deterministic
      // extra +1 boosts per round. Dual reveal/bond cards keep their reveal upgrades.
      if (card.effect.startsWith('Ongoing:') && allies.length) {
        const trainedTargets = [...allies].sort((a, b) => getEffectiveCardPower(a) - getEffectiveCardPower(b) || a.instanceId.localeCompare(b.instanceId));
        const upgrades = snapshotUpgradesForCard(result.abilityUpgradeSnapshot, card.owner, card.cardId);
        for (let index = 0; index < upgrades.length; index++) {
          const target = trainedTargets[index % trainedTargets.length];
          result = modify(result, target.instanceId, c => ({
            ...c,
            powerModifier: c.powerModifier + 1,
            lastEffectNote: `${card.name}: trained ${bond} bond +1 Hands.`,
          }));
        }
      }
    }
  }
  return result;
};

/**
 * Token templates used by Ashlee (Guyana the gorilla) and Captain Jigga
 * (Steward). These cards never enter a deck or hand — they're fabricated
 * at ability-resolution time and dropped directly onto a board lane.
 */
export const SUMMON_TEMPLATES = {
  'demario-mushroom': DEMARIO_MUSHROOM,
  grin: { id: 'cheshire', name: 'Grin', type: 'Air', cost: 0, power: 4, ability: 'The Smile Stays', effect: 'A 4-Hand Grin left by a returning ally.', kind: 'token' as const, abilityUpgrades: [] },
  cardguard: { id: 'queen-of-hearts', name: 'Card Guard', type: 'Dark', cost: 0, power: 2, ability: 'Royal Guard', effect: 'A 2-Hand guard summoned after an execution.', kind: 'token' as const, abilityUpgrades: [] },
  'smile-bomb': {
    id: 'smile-bomb', name: 'Smile Bomb', type: 'Fire', cost: 0, power: 0,
    ability: 'Short Fuse',
    effect: 'At the start of the next round, explode for -2 Hands to one random enemy in this district. The KYLE that planted it gains +1 Hands on a hit, plus +1 more on a knockout. Adds no lane Hands.',
    kind: 'token' as const, hazard: true as const, abilityUpgrades: [],
  },
  guyana: {
    id: 'guyana',
    name: 'Guyana',
    type: 'Earth',
    cost: 0,
    power: 4,
    ability: 'Gorilla in the Room',
    effect: 'Uncounterable: ignores enemy Hands reductions.',
    kind: 'token' as const,
    abilityUpgrades: [],
  },
  steward: {
    id: 'steward',
    name: 'Steward',
    type: 'Air',
    cost: 0,
    power: 2,
    ability: 'Cabin Service',
    effect: 'On arrival: target a different highest-Hands enemy for -2 Hands and give Captain Jigga\'s lowest-Hands other friendly Air character here +1 Hand.',
    kind: 'token' as const,
    abilityUpgrades: [],
  },
} as const;

const summonCard = (
  m: Match,
  owner: Owner,
  lane: Lane,
  template: Card,
  tokenId: string,
  source: CardInstance,
  uncounterable = false,
  artworkId = template.id,
): Match => {
  const instanceId = `summon:${owner}:${source.instanceId}:${m.round}:${tokenId}:${m.nextEventSequence}:${m.boards.flat().length}`;
  const arrivalOrder = nextArrivalOrder(m);
  const instance: CardInstance = {
    ...template,
    cardId: tokenId,
    instanceId,
    id: artworkId,
    owner,
    deck: `summon:${source.cardId}`,
    lane,
    playedRound: m.round,
    arrivalOrder,
    basePower: template.power,
    powerModifier: 0,
    moved: false,
    statuses: { ...emptyStatuses(), uncounterable },
    lastEffectNote: `Summoned by ${source.name}.`,
  };
  let result: Match = {
    ...m,
    nextArrivalOrder: arrivalOrder + 1,
    boards: m.boards.map((items, i) => i === lane ? [...items, instance] : items) as Match['boards'],
  };
  result = reconcileContinuousPower(result);
  if (!instance.hazard && (instance.kind ?? 'character') !== 'support') {
    const activeBuddies = result.boards.flat().filter(buddy => buddy.instanceId !== instanceId
      && buddy.cardId === 'buddy' && buddy.buddyForm === 'squabble-earth'
      && (buddy.buddyEarthExpiresAtRound ?? 0) > result.round
      && !buddy.statuses.silenced && !buddy.statuses.frozen && !buddy.statuses.weakened);
    for (const buddy of activeBuddies) {
      const arrival = findCard(result, instanceId);
      if (arrival) result = applyBuddyEarthToTarget(result, buddy, arrival);
    }
  }
  const plateArrival = findCard(result, instanceId);
  if (plateArrival) result = selectedArrived(result, plateArrival, waveTools());
  return result;
};
const addDiscountToken = (m: Match, owner: Owner, source: CardInstance, eligibility: DiscountToken["eligibility"]): Match => {
  const order = m.nextDiscountOrder ?? 1;
  return { ...m, nextDiscountOrder: order + 1, discountTokens: [...(m.discountTokens ?? []), {
    id: `discount:${owner}:${order}`, owner, sourceInstanceId: source.instanceId, eligibility, sourceLane: source.lane, createdOrder: order,
  }] };
};
/** Attribute reductions before lethal handling; nested hits restore the outer source. */
function withDamageOwner(m:Match,owner:Owner|undefined,apply:(m:Match)=>Match):Match {
  const result=apply({...m,[DAMAGE_OWNER]:owner});
  if(m[DAMAGE_OWNER]!==undefined)return {...result,[DAMAGE_OWNER]:m[DAMAGE_OWNER]};
  const {[DAMAGE_OWNER]:_context,...clean}=result;
  return clean;
}
/** One hostile package: interception and Protection run once, before its effects. */
const hostileEffect = (m: Match, source: CardInstance, target: CardInstance,
  apply: (match: Match, card: CardInstance) => Match, bypassWifeyGuard = false, intercepted = false,
  honorImmunity = false, breakTargetProtection = false, captureDamageBeforeWatchers = false): Match => {
  const current = m.boards.flat().find(c => c.instanceId === target.instanceId);
  if (!current) return m;
  target = current;
  if (honorImmunity && target.statuses.uncounterable) return modify(m, target.instanceId, c => ({
    ...c, lastEffectNote: 'Uncounterable: hostile ability had no effect.',
  }));
  if (!intercepted) {
    const intercept = creativeIntercept(m, target, creativeTools());
    if (intercept.interceptor) {
      const hit = hostileEffect(intercept.match, source, intercept.interceptor, apply, bypassWifeyGuard, true,
        honorImmunity, false, captureDamageBeforeWatchers);
      return creativeFinishIntercept(hit, intercept.interceptor, creativeTools());
    }
  }
  if (!intercepted) {
    const bond = streetLegendsIntercept(m, target);
    if (bond.interceptor) {
      const hit = hostileEffect(bond.match, source, bond.interceptor, apply, bypassWifeyGuard, true, honorImmunity, false, captureDamageBeforeWatchers);
      return streetLegendsFinishIntercept(bond.match, hit, bond.interceptor, waveTools());
    }
  }
  const fan = !intercepted && m.boards.flat().find(c => c.owner === target.owner && abilityCardId(c) === 'grownfanboy'
    && c.idolId === target.instanceId && c.instanceId !== target.instanceId && c.fanRound !== m.round && activeAbility(c));
  if (fan) {
    const before = m;
    let result = modify(m, fan.instanceId, c => ({ ...c, fanRound: m.round, lastEffectNote: 'He Doesn’t Know You: intercepted the attack on ' + target.name + '.' }));
    result = hostileEffect(result, source, fan, apply, bypassWifeyGuard, true, honorImmunity,
      false, captureDamageBeforeWatchers);
    const hit = findCard(result, fan.instanceId);
    const tookHit = directDamageAmount(m, result, fan) > 0 || (!!hit && (
      hit.lane !== fan.lane
      || ['frozen', 'silenced', 'weakened', 'locked'].some(k => !fan.statuses[k as keyof Statuses] && hit.statuses[k as keyof Statuses])
      || hit.statuses.burnStacks > fan.statuses.burnStacks));
    if (hit && tookHit && inLane(before, fan.owner, fan.lane!).some(c => abilityCardId(c) === 'fangirl')) {
      result = modify(result, fan.instanceId, c => ({ ...c, powerModifier: c.powerModifier + 2, lastEffectNote: 'Fan Club: took the hit with Fangirl here; +2 Hands.' }));
    }
    result = trainWaveAbility(result, fan.instanceId);
    return addEvent(before, result, { type: 'ability', sourceId: fan.instanceId, owner: fan.owner,
      targetIds: [fan.instanceId, target.instanceId], note: 'He Doesn’t Know You: intercepted the hostile ability aimed at ' + target.name + '.' });
  }
  const shield = breakTargetProtection ? undefined : m.timedEffects.find(e => (e.kind === 'church-protection' || e.kind === 'salon-protection') && e.targetInstanceId === target.instanceId);
  if (shield) {
    const remaining = m.timedEffects.filter(e => e.id !== shield.id);
    const cleared = modify(m, target.instanceId, c => ({ ...c, statuses: { ...c.statuses,
      protected: remaining.some(e => (e.targetInstanceId === target.instanceId && (e.kind === 'church-protection' || e.kind === 'salon-protection'))
        || (e.kind === 'wifey-protection' && e.sourceInstanceId === target.instanceId)) },
      lastEffectNote: shield.kind === 'salon-protection' ? 'NAIL SALON blocked a targeted hostile ability.' : 'Covered blocked a targeted hostile ability.' }));
    return creativeShieldBroken(queueLeaderReaction({ ...cleared, timedEffects: remaining }, 'church', target.instanceId, m), source, target, creativeTools(), shield.sourceInstanceId);
  }
  const targetLane = target.lane ?? m.boards.findIndex(items => items.some(c => c.instanceId === target.instanceId)) as Lane;
  const guard = inLane(m, target.owner, targetLane).find(c => abilityCardId(c) === 'wifey' && c.statuses.protected && !c.statuses.silenced && !c.statuses.blocked);
  if (guard && !bypassWifeyGuard) return creativeShieldBroken(queueLeaderReaction(modify(m, guard.instanceId, c => ({
    ...c, statuses: { ...c.statuses, blocked: true }, lastEffectNote: 'Side Eye blocked a targeted effect.',
  })), 'church', target.instanceId, m), source, target, creativeTools());
  if (!intercepted && !target.statuses.uncounterable && ['triple-og-red', 'triple-og-blue'].includes(target.cardId)) {
    const interceptedMatch = squabblehouseIntercept(m, source, target, apply, bypassWifeyGuard,
      honorImmunity, captureDamageBeforeWatchers);
    if (interceptedMatch !== m) return interceptedMatch;
  }
  const attempted = withDamageOwner(m, source.owner, state => apply(state, target));
  const attemptedTarget = findCard(attempted, target.instanceId);
  const harmfulStatus = attemptedTarget && (
    (!target.statuses.frozen && attemptedTarget.statuses.frozen)
    || (!target.statuses.silenced && attemptedTarget.statuses.silenced)
    || (!target.statuses.weakened && attemptedTarget.statuses.weakened)
    || (!target.statuses.locked && attemptedTarget.statuses.locked)
    || (attemptedTarget.squabblehouseCannotMoveThroughRound ?? 0) > (target.squabblehouseCannotMoveThroughRound ?? 0)
    || attemptedTarget.statuses.burnStacks > target.statuses.burnStacks
    || (streetLegendsCanMove(m, target.instanceId) && !streetLegendsCanMove(attempted, target.instanceId))
    || (musicCanMove(m, target.instanceId) && !musicCanMove(attempted, target.instanceId))
  );
  const kitSpent=m.creativeMarks?.some(x=>x.kind==='kit'&&x.targets.includes(target.instanceId)&&!attempted.creativeMarks?.some(y=>y.id===x.id));
  const execution = source.cardId === 'queenofhearts' && !attemptedTarget;
  const hostileMove = !!attemptedTarget && attemptedTarget.lane !== target.lane;
  const lostHands = directDamageAmount(m, attempted, target) > 0;
  const staffRemoval = (!!hostileMove && isSquabblehouseStaffCharacter(target))
    || (execution && isSquabblehouseStaffCharacter(target));
  const harmful = lostHands || bonusHandsRemovedBetween(m, attempted, target.instanceId) > 0 || staffRemoval
    || (attemptedTarget && attemptedTarget.owner !== target.owner)
    || harmfulStatus || kitSpent;
  if (harmful) {
    const reversed = reverseWithJanitor(m, target, source.owner, staffRemoval ? 'staff' : 'harm');
    if (reversed) return reversed;
  }
  const appealed = creativeAppeal(m, attempted, target, source, creativeTools()) ?? attempted;
  let after = creativeStatusApplied(m,appealed,source,target.instanceId);
  if (captureDamageBeforeWatchers) {
    const amount = directDamageAmount(m, after, target);
    if (amount > 0) after = addEvent(m, after, { type: 'ability', sourceId: source.instanceId,
      owner: source.owner, lane: target.lane ?? undefined, targetIds: [target.instanceId],
      note: `Home Advantage: committed ${amount} direct Hand damage to ${target.name} before damage reactions.` });
  }
  return recordDamage(m, after, source, target);
};
/** Focused reversal shared by targeted hostile packages and enemy-sourced Burn ticks. */
function reverseWithJanitor(
  m: Match, target: CardInstance, sourceOwner: Owner, charge: 'harm' | 'staff',
  afterReward: (card: CardInstance) => CardInstance = card => card,
): Match | null {
  if (sourceOwner === target.owner || target.lane === null) return null;
  const targetLane = target.lane;
  const janitor = inLane(m, target.owner, targetLane)
    .filter(card => abilityCardId(card) === 'janitor' && activeAbility(card))
    .sort((a, b) => a.instanceId.localeCompare(b.instanceId))[0];
  if (!janitor || (m.janitorReversals ?? [])
    .some(item => item.owner === target.owner && item.lane === targetLane && item.round === m.round
      && (item.charge === undefined || item.charge === charge))) return null;
  const beforeReverse = m;
  let reversed: Match = {
    ...m,
    janitorReversals: [...(m.janitorReversals ?? []), {
      owner: target.owner, lane: targetLane, round: m.round,
      sourceInstanceId: janitor.instanceId, targetInstanceId: target.instanceId, charge,
    }],
  };
  reversed = modify(reversed, target.instanceId, card => afterReward({
    ...card, powerModifier: card.powerModifier + 2,
    lastEffectNote: 'Turn It Around: hostile effect negated; +2 Hands.',
  }));
  reversed = trainWaveAbility(reversed, janitor.instanceId);
  return addEvent(beforeReverse, reversed, { type: 'ability', sourceId: janitor.instanceId, owner: janitor.owner,
    lane: targetLane, targetIds: [target.instanceId],
    note: `Turn It Around negated the first hostile ${charge} effect in district ${targetLane + 1} this round; ${target.name} gained +2 Hands.` });
}
function openTabDeparture(m: Match, target: CardInstance): { match: Match; stopped: boolean } {
  if (target.lane === null || (target.kind ?? 'character') !== 'character') return { match: m, stopped: false };
  const receipt = (m.districtTraps ?? []).find(t => t.kind === 'open-tab' && t.owner !== target.owner
    && t.lane === target.lane && t.expiresAfterRound >= m.round && t.spentRound !== m.round);
  if (!receipt) return { match: m, stopped: false };
  let stopped = false;
  const before = m;
  let result = hostileEffect(m, receipt.source, target, (state, actual) => {
    const live = (state.districtTraps ?? []).find(t => t === receipt);
    if (!live) return state;
    if (actual.instanceId === target.instanceId) stopped = true;
    let spent: Match = { ...state, districtTraps: state.districtTraps!.map(t => t === live ? { ...t, spentRound: state.round } : t) };
    return stopped ? modify(spent, actual.instanceId, c => ({ ...c, lastEffectNote: 'Open Tab blocked departure.' })) : spent;
  }, false, false, true);
  if (stopped) result = addEvent(before, result, { type: 'ability', sourceId: receipt.source.instanceId, owner: receipt.owner,
    lane: receipt.lane, targetIds: [target.instanceId], note: `Open Tab blocked ${target.name}.`, kind: 'blocked' });
  return { match: result, stopped };
}
const targetEnemy = (m: Match, source: CardInstance, target: CardInstance, apply: (c: CardInstance) => CardInstance, bypassWifeyGuard = false): Match =>
  hostileEffect(m, source, target, (before, actual) =>
    queueDisruptionReactions(before, modify(before, actual.instanceId, apply), source, actual.instanceId), bypassWifeyGuard);

const squabblehouseDogForOg = (match: Match, og: CardInstance): CardInstance | undefined => {
  const dogId = og.cardId === 'triple-og-red' ? 'cane-corso-red'
    : og.cardId === 'triple-og-blue' ? 'blue-nose-pit' : undefined;
  if (!dogId) return undefined;
  return match.boards.flat().filter(card => card.owner === og.owner && card.cardId === dogId
    && activeAbility(card) && card.squabblehouseGuardRound !== match.round
    && card.lane !== null && (card.lane === og.lane || (!card.statuses.locked
      && !match.districtRuntime?.detainedCardIds.includes(card.instanceId)
      && !getStoryLockedLanes(match, card.owner).includes(og.lane!))))
    .sort((a, b) => (a.arrivalOrder ?? Number.MAX_SAFE_INTEGER) - (b.arrivalOrder ?? Number.MAX_SAFE_INTEGER)
      || a.instanceId.localeCompare(b.instanceId))[0];
};

/** Redirect a whole canonical hostile package onto the live dog instance. */
const squabblehouseIntercept = (
  match: Match, source: CardInstance, og: CardInstance,
  apply: (match: Match, card: CardInstance) => Match,
  bypassWifeyGuard: boolean, honorImmunity: boolean, captureDamageBeforeWatchers = false,
): Match => {
  const dog = squabblehouseDogForOg(match, og);
  if (!dog) return match;
  const destination = og.lane;
  if (dog.lane !== destination && (dog.statuses.locked
    || match.districtRuntime?.detainedCardIds.includes(dog.instanceId)
    || destination === null || getStoryLockedLanes(match, dog.owner).includes(destination))) return match;
  let marked = modify(match, dog.instanceId, card => ({ ...card, squabblehouseGuardRound: match.round,
    lastEffectNote: `Guarding ${og.name}: intercepted one hostile package this round.` }));
  let currentDog = findCard(marked, dog.instanceId);
  if (!currentDog) return match;
  if (currentDog.lane !== destination && destination !== null) {
    const beforeMove = marked;
    const moved = move(marked, currentDog, destination, `Emergency Guard: leapt to protect ${og.name}.`);
    currentDog = findCard(moved, dog.instanceId);
    if (currentDog?.lane === destination) {
      marked = moved.effectLog.length === beforeMove.effectLog.length
        ? addEvent(beforeMove, moved, { type: 'ability', kind: 'move', sourceId: dog.instanceId,
          owner: dog.owner, lane: destination, targetIds: [dog.instanceId, og.instanceId],
          note: `${dog.name} emergency-jumped to ${og.name}'s district.` })
        : moved;
    } else marked = moved;
  }
  currentDog = findCard(marked, dog.instanceId);
  const liveOg = findCard(marked, og.instanceId);
  if (!currentDog || !activeAbility(currentDog) || !liveOg || currentDog.lane !== liveOg.lane) return marked;
  const packageBefore = marked;
  const result = hostileEffect(marked, source, currentDog, apply, bypassWifeyGuard, true, honorImmunity,
    false, captureDamageBeforeWatchers);
  if (result.effectLog.length === packageBefore.effectLog.length) {
    return addEvent(packageBefore, result, { type: 'ability', sourceId: source.instanceId, owner: source.owner,
      lane: currentDog.lane ?? 0, targetIds: [dog.instanceId, og.instanceId],
      note: `${dog.name} intercepted the complete hostile package; ${og.name} was protected.` });
  }
  // A nested Janitor/creative reaction owns the transition. Include both the
  // actual recipient and protected OG as participants without overlapping frames.
  const last = result.effectLog.at(-1);
  if (!last) return result;
  const extra = [dog.instanceId, og.instanceId]
    .filter(id => !last.targets.some(target => target.cardInstanceId === id))
    .map(id => participant(packageBefore, result, id))
    .filter((entry): entry is EventParticipant => !!entry);
  return { ...result, effectLog: result.effectLog.map(event => event.sequence === last.sequence
    ? { ...event, targets: [...event.targets, ...extra] } : event) };
};

const KUMITE_COMBAT_IDS = new Set([
  'bushedo-brown', 'franklin-duke', 'chonk-lee', 'dragonflyjones', 'ptang',
  'undercova', 'shonuff', 'leroy', 'yasuke',
]);

const trainWaveAbility = (m: Match, id: string): Match => {
  const card = m.boards.flat().find(c => c.instanceId === id)
    ?? [...m.playerHand, ...m.cpuHand].find(c => c.instanceId === id && c.cardId === 'cheshire');
  // Initiation has recipient upgrades and uses its own delayed-payoff ledger.
  if (!card || !(KUMITE_COMBAT_IDS.has(card.cardId) || Object.hasOwn(selectedCards, card.cardId) || HOMECOMING_KIT_IDS.has(card.cardId) || ['triple-og-blue', 'triple-og-red', 'block-spinner', 'look-out'].includes(card.cardId) || Object.hasOwn(characterWaveCards, card.cardId) || Object.hasOwn(fairytaleCards, card.cardId) || Object.hasOwn(neighborhoodWaveCards, card.cardId) || Object.hasOwn(cellblockWaveCards, card.cardId) || Object.hasOwn(afterHoursWaveCards, card.cardId) || Object.hasOwn(sideOzWaveCards, card.cardId) || Object.hasOwn(storyCharacterWaveCards, card.cardId) || Object.hasOwn(squabblehouseWaveCards, card.cardId) || Object.hasOwn(streetLegendsCards, card.cardId) || Object.hasOwn(musicIndustryWaveCards, card.cardId)) || card.waveTrainingUsed) return m;
  const update = (state: Match, change: (c: CardInstance) => CardInstance, copiedGain = false): Match => {
    if (card.lane !== null) return modify(state, id, change, copiedGain);
    const hand = card.owner === 'player' ? 'playerHand' : 'cpuHand';
    return { ...state, [hand]: state[hand].map(c => c.instanceId === id ? change(c) : c) };
  };
  let result = update(m, c => ({ ...c, waveTrainingUsed: true }));
  for (const upgrade of snapshotUpgradesForCard(m.abilityUpgradeSnapshot, card.owner, card.cardId)) {
    const before = result;
    result = update(result, c => ({ ...c, powerModifier: c.powerModifier + upgrade.effect.amount,
      lastEffectNote: upgrade.name + ': +1 Hand (once per match).' }), true);
    result = addEvent(before, result, { type: 'ability', sourceId: id, owner: card.owner, targetIds: [id],
      note: upgrade.name + ': +1 Hand (once per match).', abilityMetadata: {
        upgradeId: upgrade.id, upgradeName: upgrade.name, sourceCardId: card.cardId,
        sourceInstanceId: id, targetInstanceIds: [id], result: 'applied',
      } });
  }
  return result;
};

/** Count a committed hit on the actual recipient, after interception and reversal. */
function committedDamageBetween(before: Match, after: Match, instanceId: string): number {
  const damage = (state: Match) => (state.laneDamage ?? [])
    .filter(entry => entry.round === before.round && entry.instanceId === instanceId)
    .reduce((sum, entry) => sum + entry.amount, 0);
  return Math.max(0, damage(after) - damage(before));
}
function kumiteStrike(m: Match, source: CardInstance, target: CardInstance, amount: number, text: string) {
  let recipientId: string | undefined;
  const after = hostileEffect(m, source, target, (state, actual) => {
    recipientId = actual.instanceId;
    return reduceHands(state, actual, amount, text);
  }, false, false, true);
  return { match: after, landed: !!recipientId && committedDamageBetween(m, after, recipientId) > 0, recipientId };
}

function kumiteBonusTarget(candidates: CardInstance[]): CardInstance | undefined {
  return [...candidates].filter(card => removableBonusHands(card) > 0)
    .sort((a, b) => removableBonusHands(b) - removableBonusHands(a)
      || getEffectiveCardPower(b) - getEffectiveCardPower(a)
      || a.instanceId.localeCompare(b.instanceId))[0];
}

/** A defended control transfer is not a summon, a move, damage or collection theft. */
function resolveSwookieRecruitment(m: Match, enteringId?: string): Match {
  for (const owner of ['player', 'cpu'] as const) {
    const spent = m.swookieRecruitment?.[owner];
    if (spent?.attemptRound === m.round || (spent?.count ?? 0) >= 2) continue;
    const source = m.boards.flat().filter(c => abilityCardId(c) === 'pimp-swookie'
      && c.owner === owner && activeAbility(c)).sort((a, b) =>
      (a.arrivalOrder ?? 0) - (b.arrivalOrder ?? 0) || a.instanceId.localeCompare(b.instanceId))[0];
    if (!source) continue;
    const target = m.boards.flat().filter(c => c.cardId === 'snow' && c.owner !== owner
      && !c.hazard && !c.swookieRecruited && c.lane !== null
      && inLane(m, owner, c.lane).length < 4)
      .sort((a, b) => Number(b.instanceId === enteringId) - Number(a.instanceId === enteringId)
        || getEffectiveCardPower(b) - getEffectiveCardPower(a) || a.instanceId.localeCompare(b.instanceId))[0];
    if (!target) continue;
    const before = m;
    m = { ...m, swookieRecruitment: { ...m.swookieRecruitment,
      [owner]: { attemptRound: m.round, count: spent?.count ?? 0 },
    } };
    m = hostileEffect(m, source, target, (state, actual) => actual.instanceId !== target.instanceId
      ? state : modify(state, actual.instanceId, c => ({ ...c, owner,
        swookieRecruited: true, lastEffectNote: 'Say the Whole Name: recruited by Pimp Swookie for this fade.',
      })), false, false, true);
    const recruited = findCard(m, target.instanceId);
    const succeeded = recruited?.owner === owner && recruited.swookieRecruited;
    if (succeeded) {
      m = { ...m,
        // Past gains and afflictions stay on the card; former teammates' future
        // friendly contracts cannot keep operating across its new allegiance.
        creativeMarks: (m.creativeMarks ?? []).flatMap(mark => {
          if (mark.owner !== target.owner || !mark.targets.includes(target.instanceId)
            || mark.kind.includes('ledger')) return [mark];
          const targets = mark.targets.filter(id => id !== target.instanceId);
          if (['company', 'project'].includes(mark.kind) && targets.length < 2) return [];
          return targets.length ? [{ ...mark, targets }] : [];
        }),
        swookieRecruitment: { ...m.swookieRecruitment,
        [owner]: { attemptRound: m.round, count: (spent?.count ?? 0) + 1 },
      } };
      m = trainWaveAbility(m, source.instanceId);
    }
    m = addEvent(before, m, { type: 'ability', sourceId: source.instanceId, owner,
      lane: target.lane!, targetIds: [target.instanceId], kind: succeeded ? 'ability' : 'blocked',
      note: succeeded ? 'Say the Whole Name: Snow Bunny changed sides for this fade. Collection ownership is unchanged.'
        : 'Say the Whole Name: recruitment was defended; this side has spent its attempt this round.',
    });
    if (succeeded && activeAbility(recruited)) {
      const victim = highest(inLane(m, owner === 'player' ? 'cpu' : 'player', recruited.lane!));
      if (victim) {
        const beforeFreeze = m;
        m = targetEnemy(m, recruited, victim, c => ({ ...c, statuses: { ...c.statuses, frozen: true },
          lastEffectNote: 'Cold Shoulder: frozen by the recruited Snow Bunny.',
        }));
        m = addEvent(beforeFreeze, m, { type: 'ability', sourceId: recruited.instanceId, owner,
          lane: recruited.lane!, targetIds: [victim.instanceId], kind: 'water',
          note: 'Cold Shoulder: recruited Snow Bunny targeted her former side with Freeze; defenses apply.',
        });
      }
    }
  }
  return settleLeaderReactions(m);
}

function resolveRainmakerIncome(m: Match): Match {
  if (m.round < 2) return m;
  for (const owner of ['player', 'cpu'] as const) {
    const key = owner === 'player' ? 'playerMotion' : 'cpuMotion';
    const hand = owner === 'player' ? 'playerHand' : 'cpuHand';
    const spent = m.rainmakerPayouts?.[owner];
    if (spent?.round === m.round || (spent?.count ?? 0) >= 3 || m[key] >= MAX_MOTION) continue;
    const source = m[hand].find(c => c.cardId === 'rainmaker' && activeAbility(c));
    if (!source) continue;
    const before = m;
    m = { ...m, [key]: m[key] + 1,
      rainmakerPayouts: { ...m.rainmakerPayouts, [owner]: { round: m.round, count: (spent?.count ?? 0) + 1 } },
      [hand]: m[hand].map(c => c.instanceId === source.instanceId ? { ...c,
        rainmakerCrashes: (c.rainmakerCrashes ?? 0) + 1, basePower: Math.max(1, c.basePower - 1),
        lastEffectNote: 'Fourth Can, No Plan: +1 Motion; lost 1 base Hand, minimum 1.',
      } : c),
    };
    m = addEvent(before, m, { type: 'ability', sourceId: source.instanceId, owner,
      targetIds: [source.instanceId], note: 'Fourth Can, No Plan: generated 1 Motion from hand and paid 1 base Hand, minimum 1. This is income, not a refund or damage.',
    });
  }
  return m;
}

const removeDestroyedCard = (m: Match, id: string): Match => {
  const card = findCard(m, id);
  if (!card || rawCombatPower(card) > 0) return m;
  if (abilityCardId(card) === 'homelesslegend' && !card.legendSaved && activeAbility(card)) {
    // Overkill never becomes recoverable growth; the saved Hand was not lost.
    const saved = modify(m, id, c => ({ ...c, legendSaved: true, powerModifier: 1 - c.basePower - (c.continuousPower ?? 0),
      recoverableDamage: Math.max(0, (c.recoverableDamage ?? 0) - 1), lastEffectNote: 'Built Different: survived at 1 Hand.' }), true);
    return trainWaveAbility(saved, id);
  }
  return reconcileContinuousPower({ ...m, boards: m.boards.map(items => items.filter(item => item.instanceId !== id)) as Match['boards'],
    timedEffects: m.timedEffects.filter(effect => effect.targetInstanceId !== id),
    ...(card.cardId === 'blueside5' && activeAbility(card)
      ? { blueNextBonus: { ...m.blueNextBonus, [card.owner]: (m.blueNextBonus?.[card.owner] ?? 0) + 1 } }
      : {}) });
};

/** Damage is evaluated on the actual recipient after interception and shields. */
const reduceHands = (m: Match, target: CardInstance, amount: number, note: string, burnStacks?: number): Match => {
  if (cannotLoseHands(target)) return modify(m, target.instanceId, c => ({
    ...c, lastEffectNote: note + ` (no effect: ${cannotLoseHandsLabel(target)} cannot lose Hands).`,
  }));
  if (target.statuses.uncounterable) return modify(m, target.instanceId, c => ({ ...c, lastEffectNote: note + ' (no effect: uncounterable).' }));
  const mitigation = m.timedEffects.find(e => e.kind === 'nail-mitigation' && e.targetInstanceId === target.instanceId);
  const damage = Math.max(0, amount - (mitigation ? 1 : 0));
  let result = modify(m, target.instanceId, c => ({ ...c, powerModifier: c.powerModifier - damage,
    ...(burnStacks === undefined ? {} : { statuses: { ...c.statuses, burnStacks } }), lastEffectNote: note }));
  if (mitigation) result = { ...result, timedEffects: result.timedEffects.filter(e => e.id !== mitigation.id) };
  if (damage > 0) result = removeDestroyedCard(result, target.instanceId);
  return result;
};
const targetEnemyPowerReduction = (
  m: Match, source: CardInstance, target: CardInstance, amount: number, note: string,
  captureDamageBeforeWatchers = false,
): Match => hostileEffect(m, source, target, (state, actual) => reduceHands(state, actual, Math.abs(amount), note),
  false, false, true, false, captureDamageBeforeWatchers);
const targetEnemyBurnAndPowerReduction = (
  m: Match, source: CardInstance, target: CardInstance, stacks: number, amount: number, note: string,
): Match => hostileEffect(m, source, target, (state, actual) => {
  const result = reduceHands(state, actual, Math.abs(amount), note, actual.statuses.burnStacks + stacks + elementalMatchupBonus(source.type, actual.type));
  return modify(result, actual.instanceId, c => ({ ...c, burnSource: { instanceId: source.instanceId, owner: source.owner } }));
}, false, false, true);

const SQUABBLEHOUSE_TECH_STAFF = new Set([
  'squabblehouse-security', 'griddle-master', 'inmate-reformed', 'squabble-house-manager',
  'squabblehouse-bus-boy', 'squabblehouse-cashier', 'waffle-warlord',
]);
const SQUABBLEHOUSE_STAFF = new Set([
  ...squabblehouseStaffCardIds, 'squabblehouse-teknician',
]);
const isSquabblehouseStaff = (card: CardInstance): boolean =>
  SQUABBLEHOUSE_STAFF.has(card.cardId);

const resolveSquabblehouseDogReveal = (match: Match, dog: CardInstance, echoed = false): Match => {
  const ogId = dog.cardId === 'cane-corso-red' ? 'triple-og-red'
    : dog.cardId === 'blue-nose-pit' ? 'triple-og-blue' : undefined;
  if (!ogId || !activeAbility(dog) || dog.squabblehouseEffectRound === match.round) return match;
  const og = match.boards.flat().filter(card => card.owner === dog.owner && card.cardId === ogId)
    .sort((a, b) => (a.arrivalOrder ?? Number.MAX_SAFE_INTEGER) - (b.arrivalOrder ?? Number.MAX_SAFE_INTEGER)
      || a.instanceId.localeCompare(b.instanceId))[0];
  if (!og || og.lane === null || dog.lane !== og.lane) return match;
  const ogLane = og.lane;
  const before = match;
  let result = modify(match, dog.instanceId, card => ({ ...card, squabblehouseEffectRound: match.round }));
  const liveDog = findCard(result, dog.instanceId)!;
  let targetIds = [og.instanceId];
  let backup: CardInstance | undefined;
  if (dog.cardId === 'blue-nose-pit') {
    result = modify(result, og.instanceId, card => ({ ...card, powerModifier: card.powerModifier + 1,
      lastEffectNote: `${dog.name}: +1 Hand; matching Blue OG support.` }));
    backup = lowest(result.boards.flat().filter(card => !card.hazard && card.owner === dog.owner
      && card.lane !== ogLane && (card.gangTag ?? GANG_BY_CARD_ID[card.cardId]) === 'blue'));
    if (backup) {
      targetIds.push(backup.instanceId);
      result = modify(result, backup.instanceId, card => ({ ...card, powerModifier: card.powerModifier + 2,
        lastEffectNote: `${dog.name}: remote Blue Set backup, +2 Hands.` }));
    }
  } else {
    const victim = highest(inLane(result, og.owner === 'player' ? 'cpu' : 'player', ogLane)
      .filter(card => !cannotLoseHands(card)));
    if (victim) {
      targetIds.push(victim.instanceId);
      result = targetEnemyPowerReduction(result, liveDog, victim, 1,
        `${dog.name}: matching Red OG attack, -1 Hand.`);
    }
  }
  result = addEvent(before, result, { type: 'ability', sourceId: dog.instanceId, owner: dog.owner,
    lane: ogLane, targetIds, note: dog.cardId === 'blue-nose-pit'
      ? `${dog.name} backed up triple-og-blue for +1 Hand.` + (backup ? ` ${backup.name} gained +2 Hands in another district.` : '')
      : `${dog.name} attacked the strongest enemy in triple-og-red's district for -1 Hand.` });
  // A dog played before its OG can earn training on the later, real backup.
  const succeeded = dog.cardId === 'blue-nose-pit' || before.boards.flat().some(card =>
    card.owner !== dog.owner && directDamageAmount(before, result, card) > 0);
  return succeeded && !echoed ? trainWaveAbility(result, dog.instanceId) : result;
};

/** One bounded approach step, shared by play and round-start support. */
const approachSquabblehouseOg = (match: Match, id: string): Match => {
  const dog = findCard(match, id);
  if (!dog || !activeAbility(dog) || dog.lane === null || dog.statuses.locked
    || match.districtRuntime?.detainedCardIds.includes(dog.instanceId)) return match;
  const ogId = dog.cardId === 'cane-corso-red' ? 'triple-og-red' : 'triple-og-blue';
  const og = match.boards.flat().filter(card => card.owner === dog.owner && card.cardId === ogId)
    .sort((a, b) => (a.arrivalOrder ?? Number.MAX_SAFE_INTEGER) - (b.arrivalOrder ?? Number.MAX_SAFE_INTEGER)
      || a.instanceId.localeCompare(b.instanceId))[0];
  if (!og || og.lane === null || dog.lane === og.lane) return match;
  const destination = (dog.lane + (og.lane > dog.lane ? 1 : -1)) as Lane;
  if (getStoryLockedLanes(match, dog.owner).includes(destination)) return match;
  return move(match, dog, destination, `Toward ${og.name}: walked one adjacent lane.`);
};

const resolveSquabblehouseRoundStart = (match: Match): Match => {
  let result = match;
  const dogs = result.boards.flat().filter(card => ['cane-corso-red', 'blue-nose-pit'].includes(card.cardId))
    .sort((a, b) => (a.arrivalOrder ?? Number.MAX_SAFE_INTEGER) - (b.arrivalOrder ?? Number.MAX_SAFE_INTEGER)
      || a.instanceId.localeCompare(b.instanceId));
  for (const original of dogs) {
    let dog = findCard(result, original.instanceId);
    if (!dog || !activeAbility(dog) || dog.lane === null || dog.statuses.locked
      || result.districtRuntime?.detainedCardIds.includes(dog.instanceId)) continue;
    result = approachSquabblehouseOg(result, dog.instanceId);
    dog = findCard(result, dog.instanceId);
    if (dog && activeAbility(dog)) result = resolveSquabblehouseDogReveal(result, dog);
  }
  return result;
};

const squabblehouseSecurityArrival = (match: Match, entrantId: string): Match => {
  const entrant = findCard(match, entrantId);
  if (!entrant || entrant.lane === null || (entrant.kind ?? 'character') !== 'character') return match;
  const security = inLane(match, entrant.owner === 'player' ? 'cpu' : 'player', entrant.lane)
    .filter(card => abilityCardId(card) === 'squabblehouse-security' && activeAbility(card)
      && card.squabblehouseSecurityRound !== match.round)
    .sort((a, b) => (a.arrivalOrder ?? Number.MAX_SAFE_INTEGER) - (b.arrivalOrder ?? Number.MAX_SAFE_INTEGER)
      || a.instanceId.localeCompare(b.instanceId))[0];
  if (!security) return match;
  const before = match;
  let result = modify(match, security.instanceId, card => ({ ...card,
    squabblehouseSecurityRound: match.round,
    lastEffectNote: 'Keep the Peace: first enemy arrival this round checked.' }));
  const target = findCard(result, entrantId);
  const originalTarget = findCard(match, entrantId);
  if (target) result = targetEnemyPowerReduction(result, security, target, 1,
    'Keep the Peace: first enemy arrival lost 1 Hand.');
  const reductionLanded = !!originalTarget && directDamageAmount(match, result, originalTarget) > 0;
  if (reductionLanded) {
    const currentSecurity = findCard(result, security.instanceId);
    if (currentSecurity) result = modify(result, security.instanceId, card => ({ ...card,
      powerModifier: card.powerModifier + 1,
      lastEffectNote: 'Keep the Peace: first enemy arrival, +1 Hand.' }));
  }
  return addEvent(before, result, { type: 'ability', sourceId: security.instanceId, owner: security.owner,
    lane: entrant.lane, targetIds: [security.instanceId, entrantId],
    note: reductionLanded
      ? 'Keep the Peace: the first enemy played or moved into this district lost 1 Hand; Security gained +1 Hand.'
      : 'Keep the Peace: the first enemy arrival was checked, but its Hands loss was blocked; Security gained no Hands.' });
};

const squabblehouseManagerArrival = (match: Match, entrantId: string): Match => {
  const entrant = findCard(match, entrantId);
  if (!entrant || entrant.lane === null || entrant.hazard || (entrant.kind ?? 'character') !== 'character') return match;
  const manager = inLane(match, entrant.owner === 'player' ? 'cpu' : 'player', entrant.lane)
    .filter(card => card.cardId === 'squabble-house-manager' && activeAbility(card)
      && card.squabblehouseManagerRound !== match.round)
    .sort((a, b) => (a.arrivalOrder ?? Number.MAX_SAFE_INTEGER) - (b.arrivalOrder ?? Number.MAX_SAFE_INTEGER)
      || a.instanceId.localeCompare(b.instanceId))[0];
  if (!manager) return match;

  const beforeMark = match;
  const marked = modify(match, manager.instanceId, card => ({ ...card,
    squabblehouseManagerRound: match.round,
    lastEffectNote: 'Home Advantage: first enemy arrival this round checked.',
  }));
  let result = addEvent(beforeMark, marked, { type: 'ability', sourceId: manager.instanceId, owner: manager.owner,
    lane: entrant.lane, targetIds: [entrantId], note: 'Home Advantage: Manager committed its first-enemy check for this district this round.' });
  const beforeAttempt = result;
  const target = findCard(result, entrantId);
  if (target) result = targetEnemyPowerReduction(result, findCard(result, manager.instanceId)!, target, 1,
    'Home Advantage: first enemy arrival lost 1 Hand.', true);
  const reactionCapturedAttempt = result.effectLog.length > beforeAttempt.effectLog.length;
  const damagedRecipients = beforeAttempt.boards.flat().filter(old => old.owner === entrant.owner)
    .filter(old => {
      const damageSince = (state: Match) => (state.laneDamage ?? [])
        .filter(entry => entry.round === state.round && entry.instanceId === old.instanceId)
        .reduce((total, entry) => total + entry.amount, 0);
      return damageSince(result) > damageSince(beforeAttempt);
    }).map(card => card.instanceId);
  const landed = damagedRecipients.length > 0;
  if (!reactionCapturedAttempt) {
    result = addEvent(beforeAttempt, result, { type: 'ability', sourceId: manager.instanceId, owner: manager.owner, lane: entrant.lane,
      targetIds: landed ? damagedRecipients : [entrantId], note: landed
        ? 'Home Advantage: the committed arrival hit landed.'
        : 'Home Advantage: Protection, immunity, or an arrival defense stopped the hit.' });
  }
  if (landed) result = trainWaveAbility(result, manager.instanceId);
  return result;
};

const resolveSquabblehouseBusBoyPatrols = (match: Match): Match => {
  let result = match;
  const patrols = result.boards.flat().filter(card => card.cardId === 'squabblehouse-bus-boy')
    .sort((a, b) => (a.arrivalOrder ?? Number.MAX_SAFE_INTEGER) - (b.arrivalOrder ?? Number.MAX_SAFE_INTEGER)
      || a.instanceId.localeCompare(b.instanceId));
  for (const scheduled of patrols) {
    const busBoy = findCard(result, scheduled.instanceId);
    if (!busBoy || busBoy.lane === null || !activeAbility(busBoy)
      || busBoy.squabblehouseBusBoyPatrolRound === result.round
      || result.districtRuntime?.detainedCardIds.includes(busBoy.instanceId)) continue;
    let direction = busBoy.squabblehouseBusBoyDirection ?? (busBoy.lane === 2 ? -1 : 1);
    let destination = busBoy.lane + direction;
    if (destination < 0 || destination > 2) {
      direction = direction === 1 ? -1 : 1;
      destination = busBoy.lane + direction;
    }
    const from = busBoy.lane;
    const beforeMark = result;
    result = modify(result, busBoy.instanceId, card => ({ ...card,
      squabblehouseBusBoyPatrolRound: result.round,
      squabblehouseBusBoyDirection: direction,
      lastEffectNote: `Clear the Table patrol: attempted district ${destination + 1}.`,
    }));
    result = addEvent(beforeMark, result, { type: 'ability', sourceId: busBoy.instanceId, owner: busBoy.owner,
      lane: from, targetIds: [busBoy.instanceId], note: `Clear the Table patrol marked its one ${result.round} move.` });
    const currentBusBoy = findCard(result, busBoy.instanceId);
    if (!currentBusBoy) continue;
    const beforeMove = result;
    result = move(result, currentBusBoy, destination as Lane, 'Clear the Table patrol moved one adjacent district.', false, true);
    const postMove = findCard(result, busBoy.instanceId);
    if (postMove?.lane === from && result.effectLog.length === beforeMove.effectLog.length) {
      result = addEvent(beforeMove, result, { type: 'ability', kind: 'move', sourceId: busBoy.instanceId,
        owner: busBoy.owner, lane: from, targetIds: [busBoy.instanceId],
        note: `Clear the Table patrol could not enter district ${destination + 1}: ${postMove.lastEffectNote}` });
    }
    result = settleLeaderReactions(result);
    const arrived = findCard(result, busBoy.instanceId);
    if (!arrived || arrived.lane !== destination || !activeAbility(arrived)) continue;

    let triggered = false;
    for (const ally of inLane(result, arrived.owner, destination as Lane).filter(card =>
      card.instanceId !== arrived.instanceId && (card.kind ?? 'character') === 'character' && card.statuses.weakened)) {
      const beforeCleanse = result;
      result = cleanseAlly(result, ally.instanceId, card => ({ ...card,
        statuses: { ...card.statuses, weakened: false },
        lastEffectNote: 'Clear the Table patrol: Weakened cleared.',
      }));
      if (findCard(result, ally.instanceId)?.statuses.weakened === false) {
        triggered = true;
        result = addEvent(beforeCleanse, result, { type: 'ability', sourceId: arrived.instanceId, owner: arrived.owner,
          lane: destination as Lane, targetIds: [ally.instanceId], note: `Clear the Table patrol cleansed Weakened from ${ally.name}.` });
      }
    }
    result = settleLeaderReactions(result);
    const recipient = lowest(inLane(result, arrived.owner, destination as Lane).filter(card =>
      card.instanceId !== arrived.instanceId && (card.kind ?? 'character') === 'character'));
    if (recipient) {
      const beforeReward = result;
      result = modify(result, recipient.instanceId, card => ({ ...card, powerModifier: card.powerModifier + 1,
        lastEffectNote: 'Clear the Table patrol: weakest other character, +1 Hand.',
      }));
      triggered = true;
      result = addEvent(beforeReward, result, { type: 'ability', sourceId: arrived.instanceId, owner: arrived.owner,
        lane: destination as Lane, targetIds: [recipient.instanceId], note: `Clear the Table patrol gave ${recipient.name} +1 Hand.` });
    }
    if (triggered) result = trainWaveAbility(result, arrived.instanceId);
  }
  return result;
};

const resolveSquabblehouseStaffEcho = (
  match: Match, teknician: CardInstance, staff: CardInstance, trigger: 'reveal' | 'arrival' = 'arrival',
): Match => {
  if (!activeAbility(teknician) || !activeAbility(staff) || staff.owner !== teknician.owner
    || !SQUABBLEHOUSE_TECH_STAFF.has(staff.cardId) || staff.instanceId === teknician.instanceId) return match;
  const mark = trigger === 'reveal' ? 'squabblehouseTeknicianRevealRound' : 'squabblehouseTeknicianRound';
  if (teknician[mark] === match.round) return match;
  let marked = modify(match, teknician.instanceId, card => ({ ...card,
    [mark]: match.round,
    lastEffectNote: `Run It Back: repeated ${staff.name}'s On Reveal once this round.` }));
  const beforeEcho = marked;
  const result = resolveAbility(marked, findCard(marked, staff.instanceId)!, { echoed: true });
  if (result.effectLog.length > beforeEcho.effectLog.length) return result;
  return addEvent(beforeEcho, result, { type: 'ability', sourceId: teknician.instanceId, owner: teknician.owner,
    lane: teknician.lane ?? 0, targetIds: [staff.instanceId],
    note: `Run It Back repeated ${staff.name}'s On Reveal once.` });
};

const squabblehouseStaffWasPlayed = (match: Match, staffId: string): Match => {
  const staff = findCard(match, staffId);
  if (!staff || !SQUABBLEHOUSE_TECH_STAFF.has(staff.cardId)) return match;
  let result: Match = { ...match, squabblehouseRevealHistory: [
    ...(match.squabblehouseRevealHistory ?? []).filter(entry => entry.sourceInstanceId !== staff.instanceId),
    { owner: staff.owner, sourceInstanceId: staff.instanceId, cardId: staff.cardId, round: match.round },
  ].slice(-24) };
  if (!activeAbility(staff)) return result;
  const live = findCard(result, staffId)!;
  const teknician = result.boards.flat().filter(card => card.owner === live.owner
    && card.cardId === 'squabblehouse-teknician' && card.lane === live.lane && activeAbility(card)
    && card.squabblehouseTeknicianRound !== result.round)
    .sort((a, b) => (a.arrivalOrder ?? Number.MAX_SAFE_INTEGER) - (b.arrivalOrder ?? Number.MAX_SAFE_INTEGER)
      || a.instanceId.localeCompare(b.instanceId))[0];
  if (teknician && teknician.instanceId !== live.instanceId) result = resolveSquabblehouseStaffEcho(result, teknician, live);
  return result;
};

const forceEnemyMove = (m: Match, source: CardInstance, target: CardInstance, destination: Lane): Match =>
  hostileEffect(m, source, target, (state, actual) => forceMoveUnshielded(state, actual, destination), false, false, true);
const forceMoveUnshielded = (state: Match, actual: CardInstance, destination: Lane): Match => {
    const anchored = creativeAnchor(state, actual, creativeTools());
    if (anchored) return anchored;
    if (actual.statuses.uncounterable || (actual.statuses.locked && !creativeCanCross(state,actual.instanceId)) || state.districtRuntime?.detainedCardIds.includes(actual.instanceId)
      || squabblehouseMovementLocked(state, actual) || !musicCanMove(state, actual.instanceId) || !streetLegendsCanMove(state, actual.instanceId) || actual.lane === destination
      || getStoryLockedLanes(state, actual.owner).includes(destination)) {
      return modify(state, actual.instanceId, c => ({ ...c, lastEffectNote: 'Wrong Block: movement blocked.' }));
    }
    const apostle = actual.type === 'Earth' && state.leaderRounds?.[actual.owner]?.asphaltapostle !== state.round
      && state.boards.flat().find(c => c.owner === actual.owner && abilityCardId(c) === 'asphaltapostle' && activeAbility(c));
    if (apostle) {
      let blocked: Match = { ...state, leaderRounds: { ...state.leaderRounds,
        [actual.owner]: { ...state.leaderRounds?.[actual.owner], asphaltapostle: state.round } } };
      blocked = modify(blocked, actual.instanceId, c => ({ ...c, powerModifier: c.powerModifier + 2,
        lastEffectNote: 'Concrete Congregation blocked a forced move: +2 Hands.' }));
      return trainWaveAbility(blocked, apostle.instanceId);
    }
    return move(state, actual, destination, 'Wrong Block: forced into another district.');
};

/** INITIATION: the marked district puts your next character on with the set already standing there. */
const laneGangColor = (m: Match, owner: Owner, lane: Lane, exceptId: string): GangColor | undefined => {
  const tally: Record<GangColor, number> = { blue: 0, red: 0 };
  for (const card of inLane(m, owner, lane)) {
    if (card.instanceId === exceptId) continue;
    const color = card.gangTag ?? GANG_BY_CARD_ID[card.cardId];
    if (color) tally[color]++;
  }
  if (tally.blue === tally.red) return undefined;
  return tally.blue > tally.red ? 'blue' : 'red';
};
function applyInitiationMark(m: Match, id: string, owner: Owner, lane: Lane): Match {
  const entrant = findCard(m, id);
  if (!entrant || entrant.hazard || (entrant.kind ?? 'character') !== 'character') return m;
  const mark = (m.districtTraps ?? []).find(t => t.kind === 'initiation' && t.owner === owner && t.lane === lane);
  if (!mark) return m;
  const before = m;
  const color = laneGangColor(m, owner, lane, id);
  m = { ...m, districtTraps: m.districtTraps!.filter(t => t !== mark) };
  m = modify(m, id, c => ({ ...c, ...(color ? { gangTag: color } : {}), powerModifier: c.powerModifier + 2,
    lastEffectNote: color ? `Marked Territory: put on by the ${GANG_LABEL[color]}; +2 Hands.` : 'Marked Territory: claimed the block; +2 Hands.' }));
  m = addEvent(before, m, { type: 'ability', sourceId: mark.source.instanceId, owner, lane, targetIds: [id],
    note: color ? `${entrant.name} was initiated into the ${GANG_LABEL[color]}: +2 Hands.` : `${entrant.name} claimed the marked district: +2 Hands.` });
  if (mark.echoed || m.initiationTrainedIds?.includes(mark.source.instanceId)) return m;
  m = { ...m, initiationTrainedIds: [...(m.initiationTrainedIds ?? []), mark.source.instanceId] };
  for (const upgrade of snapshotUpgradesForCard(m.abilityUpgradeSnapshot, owner, mark.source.cardId)) {
    if (upgrade.effect.kind !== 'target-power' || upgrade.effect.target !== 'friendly') continue;
    const beforeUpgrade = m;
    m = modify(m, id, c => ({ ...c, powerModifier: c.powerModifier + upgrade.effect.amount,
      lastEffectNote: `${upgrade.name}: +${upgrade.effect.amount} Hand (recruitment, once per match).` }));
    m = addEvent(beforeUpgrade, m, { type: 'ability', sourceId: mark.source.instanceId, owner, lane, targetIds: [id],
      note: `${upgrade.name}: ${entrant.name} gained +${upgrade.effect.amount} Hand on recruitment.`,
      abilityMetadata: { upgradeId: upgrade.id, upgradeName: upgrade.name,
        sourceCardId: mark.source.cardId, sourceInstanceId: mark.source.instanceId,
        targetInstanceIds: [id], result: 'applied' } });
  }
  return m;
}
const burnLanded = (before: Match, after: Match, sourceId: string): boolean =>
  after.boards.flat().some(card => card.burnSource?.instanceId === sourceId
    && card.statuses.burnStacks > (findCard(before, card.instanceId)?.statuses.burnStacks ?? 0));

/** BLOCK SPINNER: the spinning block burns the next enemy played into the district. */
function applySpinnerTrap(m: Match, id: string, lane: Lane): Match {
  const entrant = findCard(m, id);
  if (!entrant || entrant.hazard || (entrant.kind ?? 'character') !== 'character') return m;
  const trap = (m.districtTraps ?? []).find(t => {
    if (t.kind !== 'spinner' || t.owner === entrant.owner || t.lane !== lane || t.expiresAfterRound < m.round) return false;
    const spinner = findCard(m, t.source.instanceId);
    return spinner?.lane === lane && activeAbility(spinner);
  });
  if (!trap) return m;
  const before = m;
  m = { ...m, districtTraps: m.districtTraps!.filter(t => t !== trap) };
  m = applyBurn(m, findCard(m, trap.source.instanceId)!, entrant, 1, 'Spin the Block: caught coming in; 1 Burn.');
  m = addEvent(before, m, { type: 'ability', sourceId: trap.source.instanceId, owner: trap.owner, lane,
    targetIds: [id], note: `${entrant.name} walked into the spinning block and took 1 Burn.` });
  return !trap.echoed && burnLanded(before, m, trap.source.instanceId) ? trainWaveAbility(m, trap.source.instanceId) : m;
}
/** LOOK OUT: calls out the opponent's next district and discounts your next card there. */
function applyLookoutWatch(m: Match, owner: Owner, lane: Lane): Match {
  const watchers = m.boards.flat().filter(c => c.owner !== owner && c.lookoutReady && (c.lookoutCalls ?? 0) < 3
    && c.lookoutCallRound !== m.round && activeAbility(c));
  for (const watcher of watchers) {
    const before = m;
    const order = m.nextDiscountOrder ?? 1;
    m = modify(m, watcher.instanceId, c => ({ ...c, lookoutReady: false, lookoutCalls: (c.lookoutCalls ?? 0) + 1, lookoutCallRound: m.round,
      lastEffectNote: `On Point: called out district ${lane + 1}.` }));
    m = { ...m, nextDiscountOrder: order + 1, discountTokens: [...(m.discountTokens ?? []), {
      id: `discount:${watcher.owner}:${order}`, owner: watcher.owner, sourceInstanceId: watcher.instanceId,
      eligibility: 'lookout-watch' as const, targetLane: lane, sourceLane: watcher.lane, createdOrder: order,
    }] };
    const ally = lowest(m.boards.flat().filter(c => !c.hazard && c.owner === watcher.owner
      && c.instanceId !== watcher.instanceId && (c.gangTag ?? GANG_BY_CARD_ID[c.cardId]) === 'blue'));
    if (ally) m = modify(m, ally.instanceId, c => ({ ...c, powerModifier: c.powerModifier + 2,
      lastEffectNote: 'On Point: Blue Set backup, +2 Hands.' }));
    m = addEvent(before, m, { type: 'ability', sourceId: watcher.instanceId, owner: watcher.owner, lane,
      targetIds: [watcher.instanceId, ...(ally ? [ally.instanceId] : [])],
      note: `${watcher.name} called out district ${lane + 1}: your next card there costs 1 less Motion.`
        + (ally ? ` ${ally.name} gained +2 Hands for Blue Set backup.` : '') });
    m = trainWaveAbility(m, watcher.instanceId);
  }
  return m;
}
const applyScentEntry = (m: Match, id: string): Match => {
  let result = m;
  const card = findCard(m, id);
  if (!card || card.hazard || card.lane === null) return result;
  for (const scent of m.lingeringScents ?? []) {
    if (scent.lane !== card.lane || scent.owner === card.owner || scent.expiresAfterRound < m.round || scent.triggeredRound === m.round) continue;
    const before = result;
    result = { ...result, lingeringScents: result.lingeringScents?.map(s => s === scent ? { ...s, triggeredRound: m.round } : s) };
    result = applyBurn(result, scent.source, card, 2, 'Lingering Scent: entered a scented district; 2 Burn.');
    result = addEvent(before, result, { type: 'ability', sourceId: scent.source.instanceId, owner: scent.owner,
      lane: scent.lane, targetIds: [id], note: 'Lingering Scent: first enemy entering this round was targeted with 2 Burn.' });
  }
  return result;
};

/** Shared wave hooks. Counters are marked before reactions so retaliation cannot loop. */
function grantProtection(m: Match, source: CardInstance, id: string): Match {
  const target = m.boards.flat().find(c => c.instanceId === id);
  if (!target || target.statuses.protected) return m;
  const result = modify(m, id, c => ({ ...c, statuses: { ...c.statuses, protected: true }, lastEffectNote: source.ability + ': Protection.' }));
  return { ...result, timedEffects: [...result.timedEffects, {
    id: 'wave-cover:' + source.instanceId + ':' + id + ':' + m.nextEventSequence,
    kind: 'church-protection', sourceInstanceId: source.instanceId, targetInstanceId: id,
    owner: target.owner, lane: target.lane!, startsAtRound: m.round, expiresAtRound: 99, expiration: 'match-complete',
  }] };
}
function waveRound(m: Match, id: string, key: keyof NonNullable<CardInstance['waveRounds']>): Match {
  return modify(m, id, c => ({ ...c, waveRounds: { ...c.waveRounds, [key]: m.round } }));
}
function fairytaleArrival(m: Match, id: string, movedHere = false): Match {
  const entrant = m.boards.flat().find(c => c.instanceId === id);
  if (!entrant || entrant.hazard || entrant.lane === null) return m;
  for (const tin of inLane(m, entrant.owner, entrant.lane).filter(c => c.instanceId !== id && abilityCardId(c) === 'tinman' && activeAbility(c) && c.waveRounds?.tinman !== m.round)) {
    const before = m;
    const hands = movedHere || ['dorothy', 'scarecrow', 'tinman', 'lion'].includes(abilityCardId(entrant)) ? 2 : 1;
    m = waveRound(m, tin.instanceId, 'tinman');
    if (hands === 2) m = grantProtection(m, tin, id);
    m = modify(m, id, c => ({ ...c, powerModifier: c.powerModifier + hands }));
    m = trainWaveAbility(m, tin.instanceId);
    m = addEvent(before, m, { type: 'ability', sourceId: tin.instanceId, owner: tin.owner, targetIds: [id], note: `Heart Starter: first ally entering this round gains +${hands} ${hands === 1 ? 'Hand' : 'Hands'}${hands === 2 ? ' and Protection' : ''}.` });
  }
  return m;
}
function fairytaleDeparture(m: Match, departed: CardInstance): Match {
  if (departed.lane === null) return m;
  for (const lion of inLane(m, departed.owner, departed.lane).filter(c => c.instanceId !== departed.instanceId && abilityCardId(c) === 'lion' && activeAbility(c) && c.waveRounds?.lion !== m.round)) {
    const before = m;
    m = waveRound(m, lion.instanceId, 'lion');
    m = modify(m, lion.instanceId, c => ({ ...c, powerModifier: c.powerModifier + 2, lastEffectNote: 'Found My Courage: an ally left; +2 Hands.' }));
    m = trainWaveAbility(m, lion.instanceId);
    m = addEvent(before, m, { type: 'ability', sourceId: lion.instanceId, owner: lion.owner, targetIds: [lion.instanceId], note: 'Found My Courage: +2 Hands, once this round.' });
  }
  return m;
}
/** Transfers and confiscation cannot become healing credit, including for Built Different. */
function modifyWithoutDamage(m: Match, target: CardInstance, apply: (c: CardInstance) => CardInstance): Match {
  const before = m.boards.flat().find(c => c.instanceId === target.instanceId);
  const after = modify(m, target.instanceId, apply, false, true);
  const current = after.boards.flat().find(c => c.instanceId === target.instanceId);
  const removed = before && current ? Math.max(0, before.powerModifier - current.powerModifier) : 0;
  return removed ? { ...after, [NON_DAMAGE_HANDS_LOSS]: {
    ...after[NON_DAMAGE_HANDS_LOSS],
    [target.instanceId]: (after[NON_DAMAGE_HANDS_LOSS]?.[target.instanceId] ?? 0) + removed,
  } } : after;
}
/** Permanent positive modifiers are buffs; copied base Hands and live auras are not. */
export const removableBonusHands = (card: Pick<CardInstance, 'powerModifier'>): number =>
  Math.max(0, card.powerModifier);

/** Inside a defended package only: callers must not re-run Protection/interception. */
export function trimBonusHandsUnshielded(m: Match, target: CardInstance, cap: number, note: string): { match: Match; removed: number } {
  const current = m.boards.flat().find(c => c.instanceId === target.instanceId);
  if (!current) return { match: m, removed: 0 };
  const amount = Math.min(Math.max(0, cap), removableBonusHands(current));
  if (!amount) return { match: m, removed: 0 };
  const after = modifyWithoutDamage(m, current, c => ({ ...c,
    powerModifier: c.powerModifier - amount, lastEffectNote: note,
  }));
  return { match: after, removed: bonusHandsRemovedBetween(m, after, current.instanceId) };
}
/** A transient delta, so rollback, shields and Hands-loss immunity cannot mint steals. */
export const bonusHandsRemovedBetween = (before: Match, after: Match, instanceId: string): number =>
  Math.max(0, (after[NON_DAMAGE_HANDS_LOSS]?.[instanceId] ?? 0) - (before[NON_DAMAGE_HANDS_LOSS]?.[instanceId] ?? 0));

export function trimEnemyBonusHands(m: Match, source: CardInstance, target: CardInstance, cap: number, note = source.ability + ': bonus Hands removed.'): { match: Match; removed: number; recipientId?: string } {
  let recipientId: string | undefined;
  const after = hostileEffect(m, source, target, (state, actual) => {
    recipientId = actual.instanceId;
    return trimBonusHandsUnshielded(state, actual, cap, note).match;
  }, false, false, true);
  return { match: after,
    removed: recipientId ? bonusHandsRemovedBetween(m, after, recipientId) : 0,
    ...(recipientId ? { recipientId } : {}),
  };
}
function refundMotion(m: Match, owner: Owner, amount: number): Match {
  const key = owner === 'player' ? 'playerMotion' : 'cpuMotion';
  const hand = owner === 'player' ? 'playerHand' : 'cpuHand';
  const refunded = Math.max(0, Math.min(MAX_MOTION - m[key], amount));
  const refundedMatch = { ...m, [key]: m[key] + refunded, [hand]: m[hand].map(c => abilityCardId(c) === 'powerhouse' && activeAbility(c)
    ? { ...c, bankedMotion: Math.min(3, (c.bankedMotion ?? 0) + refunded), lastEffectNote: 'Overtime: ' + Math.min(3, (c.bankedMotion ?? 0) + refunded) + '/3 refunded Motion banked.' } : c) };
  return creativeRefund(m, refundedMatch, owner, creativeTools());
}
const directDamageAmount = (before: Match, after: Match, victim: CardInstance): number => {
  const current = after.boards.flat().find(c => c.instanceId === victim.instanceId);
  const laneDamageTotal = (match: Match) => (match.laneDamage ?? [])
    .filter(entry => entry.round === match.round && entry.instanceId === victim.instanceId)
    .reduce((total, entry) => total + entry.amount, 0);
  const removedLoss = Math.max(0, laneDamageTotal(after) - laneDamageTotal(before));
  const transferred = bonusHandsRemovedBetween(before, after, victim.instanceId);
  return current
    ? Math.min(
      Math.max(0, rawCombatPower(victim) - rawCombatPower(current) - transferred),
      Math.max(0, victim.powerModifier - current.powerModifier - transferred),
    )
    : removedLoss;
};
function recordDamage(before: Match, after: Match, source: Pick<CardInstance, 'instanceId' | 'owner'>, victim: CardInstance, ability = true, burn = false): Match {
  const current = after.boards.flat().find(c => c.instanceId === victim.instanceId);
  const amount = directDamageAmount(before, after, victim);
  if (!amount) return after;
  let m = after;
  if (current && abilityCardId(victim) !== 'homelesslegend') m = modify(m, current.instanceId, c => ({ ...c, recoverableDamage: (c.recoverableDamage ?? 0) + amount }));
  if (source.owner === victim.owner || victim.lane === null) return m;
  const watchers = before.boards.flat().filter(c => !c.hazard && c.lane === victim.lane);
  for (const snapshot of watchers) {
    const watcher = m.boards.flat().find(c => c.instanceId === snapshot.instanceId);
    if (!watcher || !activeAbility(watcher)) continue;
    const id = abilityCardId(watcher), start = m;
    const friendly = watcher.owner === victim.owner && watcher.instanceId !== victim.instanceId;
    const targets: string[] = [];
    if (id === 'bonnetgirl' && friendly && !watcher.waveOnce?.bonnetgirl) {
      m = modify(m, watcher.instanceId, c => ({ ...c, waveOnce: { ...c.waveOnce, bonnetgirl: true }, powerModifier: c.powerModifier + 2, lastEffectNote: 'Now I’m Up: +2 Hands.' }));
      targets.push(watcher.instanceId);
    } else if (id === 'ronald' && friendly && watcher.waveRounds?.ronald !== m.round) {
      m = waveRound(m, watcher.instanceId, 'ronald');
      if (inLane(m, watcher.owner, victim.lane).length < 4) {
        const backup = lowest(m.boards.flat().filter(c => c.owner === watcher.owner
          && (c.kind ?? 'character') === 'character' && canMoveTo(m, c, victim.lane!)));
        if (backup) {
          m = grantProtection(m, watcher, backup.instanceId);
          m = move(m, findCard(m, backup.instanceId)!, victim.lane, 'WE OUTSIDE: backup arrived.');
          targets.push(backup.instanceId);
        }
      }
    } else if (id === 'trapvamp' && ability && watcher.owner === source.owner && watcher.waveRounds?.trapvamp !== m.round) {
      m = waveRound(m, watcher.instanceId, 'trapvamp');
      m = modify(m, watcher.instanceId, c => ({ ...c, powerModifier: c.powerModifier + Math.min(2, amount), lastEffectNote: 'Paid in Blood: +' + Math.min(2, amount) + ' Hands.' }));
      targets.push(watcher.instanceId);
    } else if (id === 'squabblecook' && ability && friendly && watcher.waveRounds?.squabblecook !== m.round) {
      m = waveRound(m, watcher.instanceId, 'squabblecook');
      const attacker = m.boards.flat().find(c => c.instanceId === source.instanceId);
      if (attacker) { m = targetEnemyPowerReduction(m, watcher, attacker, 2, 'Hands on the Clock: 2 damage back to the source.'); targets.push(attacker.instanceId); }
    }
    if (targets.length) {
      m = trainWaveAbility(m, watcher.instanceId);
      m = addEvent(start, m, { type: 'ability', sourceId: watcher.instanceId, owner: watcher.owner, targetIds: targets, note: watcher.ability + ' reacted to ' + amount + ' damage.' });
    }
  }
  const creativeVictim = current
    ? { ...victim, continuousPower: current.continuousPower ?? 0 }
    : { ...victim, basePower: amount, powerModifier: 0, continuousPower: 0 };
  m = creativeDamage(before, m, source, creativeVictim, { ...creativeTools(), power: rawCombatPower }, burn);
  return selectedDamage(before, musicDamage(before, m, source, victim, waveTools(), burn), victim, waveTools(), burn);
}
function returnToHand(m: Match, source: CardInstance, target: CardInstance, discount = false): Match {
  if (target.lane === null || (target.kind ?? 'character') !== 'character' || !m.boards.flat().some(c => c.instanceId === target.instanceId)) return m;
  if (squabblehouseMovementLocked(m, target) || !musicCanMove(m, target.instanceId) || !streetLegendsCanMove(m, target.instanceId)) return m;
  const departure = openTabDeparture(m, target);
  m = departure.match;
  if (departure.stopped) return m;
  if (source.owner !== target.owner && isSquabblehouseStaffCharacter(target)) {
    const reversed = reverseWithJanitor(m, findCard(m, target.instanceId) ?? target, source.owner, 'staff');
    if (reversed) return reversed;
  }
  const before = m, printed = cards[target.cardId] ?? bossNpcCards[target.cardId] ?? target, hand = target.owner === 'player' ? 'playerHand' : 'cpuHand';
  const { continuousPower: _continuousPower, ...returnedTarget } = target;
  const rabbitInHand = m[hand].find(c => c.instanceId !== target.instanceId && abilityCardId(c) === 'mrrabbit' && activeAbility(c));
  const returned: CardInstance = { ...returnedTarget, ...printed, ...(target.maryElephant ? { cost: 4, power: 4 } : {}), basePower: target.maryElephant ? 4
    : target.cardId === 'rainmaker' ? Math.max(1, printed.power - (target.rainmakerCrashes ?? 0)) : printed.power,
    powerModifier: Math.max(0, target.powerModifier) + (source.cardId === 'madhatter' ? 1 : 0), lane: null, playedRound: null,
    squabblehouseBusBoyPatrolRound: undefined, squabblehouseBusBoyDirection: undefined,
    statuses: emptyStatuses(), copiedAbilityCardId: undefined, recoverableDamage: 0, burnSource: undefined, moved: false,
    rabbitReturnDiscount: !!rabbitInHand,
    lastEffectNote: source.cardId === 'madhatter'
      ? 'Change Places!: returned with +1 Hand and a one-use −1 Motion credit.'
      : 'Returned to hand by ' + source.name + '.' };
  m = reconcileContinuousPower({ ...m, [hand]: [...m[hand], returned], boards: m.boards.map(items => items.filter(c => c.instanceId !== target.instanceId)) as Match['boards'],
    timedEffects: m.timedEffects.filter(e => e.targetInstanceId !== target.instanceId && !(e.sourceInstanceId === target.instanceId && e.kind === 'wifey-protection')),
    discountTokens: m.discountTokens.filter(t => t.targetInstanceId !== target.instanceId) });
  if (discount) {
    m = addDiscountToken(m, target.owner, source, 'homecoming');
    m = { ...m, discountTokens: m.discountTokens.map(t => t.createdOrder === m.nextDiscountOrder - 1
      ? { ...t, targetInstanceId: target.instanceId, ...(source.cardId === 'dorothy' ? { bonusHandsOnUse: 1 } : {}) } : t) };
  }
  m = fairytaleDeparture(m, target);
  const cat = [...before.boards.flat(), ...before[hand]]
    .find(c => c.owner === target.owner && abilityCardId(c) === 'cheshire' && activeAbility(c));
  if (cat && m.cheshireRounds?.[target.owner] !== m.round) {
    m = { ...m, cheshireRounds: { ...m.cheshireRounds, [target.owner]: m.round } };
    if (!inLane(m, target.owner, target.lane).some(c => c.cardId === 'grin')) {
      m = summonCard(m, target.owner, target.lane, SUMMON_TEMPLATES.grin, 'grin', cat, false, 'cheshire');
      m = trainWaveAbility(m, cat.instanceId);
    }
  }
  m = addEvent(before, m, { type: 'ability', kind: 'move', sourceId: source.instanceId, owner: source.owner, targetIds: [target.instanceId], note: target.name + ' returned to hand.' + (source.cardId === 'madhatter' ? ' It has +1 Hand.' : '') + (discount ? ' Its next deployment costs 1 less Motion, minimum 1' + (source.cardId === 'dorothy' ? ', and gains +1 Hand.' : '.') : '') });
  if (rabbitInHand) m = addEvent(m, m, { type: 'ability', sourceId: rabbitInHand.instanceId, owner: target.owner,
    targetIds: [target.instanceId], note: 'Pocket Watch: ' + target.name + ' costs 1 less Motion on its next deployment (minimum 1).' });
  for (const rabbit of before.boards.flat().filter(c => c.owner === target.owner && c.instanceId !== target.instanceId
    && abilityCardId(c) === 'mrrabbit' && activeAbility(c))) {
    const current = findCard(m, rabbit.instanceId);
    if (!current || !activeAbility(current)) continue;
    const start = m;
    m = modify(m, rabbit.instanceId, c => ({ ...c, powerModifier: c.powerModifier + 1,
      lastEffectNote: 'Pocket Watch: an ally returned to hand; +1 Hand.' }));
    m = trainWaveAbility(m, rabbit.instanceId);
    m = addEvent(start, m, { type: 'ability', sourceId: rabbit.instanceId, owner: rabbit.owner,
      targetIds: [rabbit.instanceId], note: 'Pocket Watch: an ally returned to hand; +1 Hand.' });
  }
  return m;
}
function returnAliceAtRoundEnd(m: Match): Match {
  if (m.round >= getMatchRoundLimit(m)) return m;
  for (const alice of m.boards.flat().filter(c => abilityCardId(c) === 'alice' && activeAbility(c) && !c.waveOnce?.alice)) {
    if (squabblehouseMovementLocked(m, alice)) continue;
    const prepared = { ...alice, waveOnce: { ...alice.waveOnce, alice: true }, aliceReady: true };
    const returned = returnToHand(m, alice, prepared);
    m = returned;
  }
  return m;
}
function canMoveTo(m: Match, card: CardInstance, destination: Lane): boolean {
  return card.lane !== null && card.lane !== destination && !card.hazard && (!card.statuses.locked || creativeCanCross(m,card.instanceId))
    && !m.districtRuntime?.detainedCardIds.includes(card.instanceId) && !getStoryRuleLockedLanes(m, card.owner).includes(destination)
    && !squabblehouseMovementLocked(m, card) && musicCanMove(m, card.instanceId) && streetLegendsCanMove(m, card.instanceId);
}
function moveRouteLegal(m: Match, card: CardInstance, destination: Lane): boolean {
  return card.lane !== null && card.lane !== destination && !card.hazard
    && !m.districtRuntime?.detainedCardIds.includes(card.instanceId)
    && !getStoryRuleLockedLanes(m, card.owner).includes(destination)
    && !squabblehouseMovementLocked(m, card) && musicCanMove(m, card.instanceId) && streetLegendsCanMove(m, card.instanceId)
    && (!card.statuses.locked || creativeCanCross(m, card.instanceId));
}
function undercovaReaction(m: Match, beforePlay: Match, id: string, origin: Lane, owner: Owner): Match {
  for (const previous of beforePlay.boards[origin].filter(c => c.owner !== owner && abilityCardId(c) === 'undercova')) {
    const spy = m.boards.flat().find(c => c.instanceId === previous.instanceId);
    const target = m.boards.flat().find(c => c.instanceId === id);
    if (!spy || !target || target.owner === spy.owner || spy.lane !== origin || !activeAbility(spy)) continue;
    const spent = m.undercovaPayouts?.[spy.owner];
    if (spent?.round === m.round || (spent?.count ?? 0) >= 2) continue;
    const before = m;
    let recipient: CardInstance | undefined;
    m = hostileEffect(m, spy, target, (state, actual) => {
      recipient = actual;
      const stripped = trimBonusHandsUnshielded(state, actual, 2, 'Inside Man: confiscated up to 2 bonus Hands.');
      const current = findCard(stripped.match, actual.instanceId);
      return current ? reduceHands(stripped.match, current, 2, 'Inside Man: stole 2 Hands.') : stripped.match;
    }, false, false, true);
    const stolen = recipient ? Math.min(4, Math.min(2, bonusHandsRemovedBetween(before, m, recipient.instanceId))
      + Math.min(2, committedDamageBetween(before, m, recipient.instanceId))) : 0;
    if (!stolen) {
      m = addEvent(before, m, { type: 'ability', sourceId: spy.instanceId, owner: spy.owner,
        targetIds: [id], note: 'Inside Man: defenses prevented the theft; no payout or escape.' });
      continue;
    }
    m = { ...m, undercovaPayouts: { ...m.undercovaPayouts,
      [spy.owner]: { round: m.round, count: (spent?.count ?? 0) + 1 },
    } };
    m = modify(m, spy.instanceId, c => ({ ...c, powerModifier: c.powerModifier + stolen,
      lastEffectNote: `Inside Man: gained ${stolen} actually stolen Hands.` }));
    const survivor = m.boards.flat().find(c => c.instanceId === spy.instanceId);
    if (survivor) {
      const destination = ([0, 1, 2] as Lane[]).filter(l => canMoveTo(m, survivor, l))
        .sort((a, b) => getLaneScoreForMatch(m, inLane(m, spy.owner, a), a, spy.owner) - getLaneScoreForMatch(m, inLane(m, spy.owner, b), b, spy.owner) || a - b)[0];
      if (destination !== undefined) m = move(m, survivor, destination, 'Inside Man: escaped after the enemy entrance.');
      m = trainWaveAbility(m, spy.instanceId);
    }
    m = addEvent(before, m, { type: 'ability', kind: 'move', sourceId: spy.instanceId, owner: spy.owner,
      targetIds: [id, ...(recipient && recipient.instanceId !== id ? [recipient.instanceId] : []), spy.instanceId],
      note: `Inside Man: stole ${stolen} Hands after the entrance, then tried to escape; ${2 - (spent?.count ?? 0) - 1} side payout remaining.` });
  }
  return m;
}
function hasEntrance(c: CardInstance): boolean {
  return c.aliceReady || c.effect.includes('On Reveal:') || (!c.effect.startsWith('Ongoing:') && !['bossbabe', 'stockz', 'streamer', 'wifey', 'nail'].includes(c.cardId));
}
function clearBlueScarfRoute(m: Match, source: CardInstance): {
  match: Match; targetIds: string[]; moved: number; note: string;
} {
  const enemy = source.owner === 'player' ? 'cpu' : 'player';
  // Pick from the original three districts so an ally cannot move twice on the same turn.
  const riders = ([0, 1, 2] as Lane[]).flatMap(origin => {
    const ally = lowest(inLane(m, source.owner, origin)
      .filter(card => !card.hazard && card.instanceId !== source.instanceId));
    return ally ? [{ id: ally.instanceId, origin }] : [];
  });
  const steal = seededIndex(JSON.stringify(['blue-scarf-route', source.instanceId, m.round, m.nextEventSequence]), 2) === 1;
  const targets: string[] = [];
  let moved = 0;
  for (const { id, origin } of riders) {
    const rider = findCard(m, id);
    const currentSource = findCard(m, source.instanceId);
    if (!rider || rider.lane !== origin || !currentSource || !activeAbility(currentSource)) continue;
    // Districts are a row, not a ring: the outer districts can only enter the center.
    const adjacent: Lane[] = origin === 0 || origin === 2 ? [1] : [2, 0];
    const destination = adjacent
      .find(next => inLane(m, source.owner, next).length < 4
        && !getStoryLockedLanes(m, source.owner).includes(next) && canMoveTo(m, rider, next));
    if (destination === undefined) continue;
    m = move(m, rider, destination, 'Clear the Route: crossed one district.');
    const arrival = findCard(m, id);
    if (arrival?.lane !== destination) continue;
    moved++;
    targets.push(id);
    if (!steal) {
      m = modify(m, id, card => ({ ...card, powerModifier: card.powerModifier + 1,
        lastEffectNote: 'Clear the Route: +1 Hand.' }));
      continue;
    }
    const victim = highest(inLane(m, enemy, destination));
    if (!victim) continue;
    const beforeHit = m;
    m = targetEnemyPowerReduction(m, currentSource, victim, 1, 'Clear the Route: stole 1 Hand.');
    if (directDamageAmount(beforeHit, m, victim) > 0) {
      targets.push(victim.instanceId);
      m = modify(m, id, card => ({ ...card, powerModifier: card.powerModifier + 1,
        lastEffectNote: 'Clear the Route: stole +1 Hand.' }));
    }
  }
  return { match: m, targetIds: targets, moved,
    note: moved ? `Clear the Route moved ${moved} ally card${moved === 1 ? '' : 's'}; ${steal ? 'stole Hands from unprotected enemies where possible' : 'gave each +1 Hand'}.`
      : 'Clear the Route found no legal ally route.' };
}
function resolveRedNightSteal(m: Match, source: CardInstance): {
  match: Match; targetIds: string[]; succeeded: boolean; note: string;
} {
  const current = findCard(m, source.instanceId);
  if (!current || current.lane === null || !activeAbility(current)
    || current.redNightStartRound === undefined
    || m.round >= current.redNightStartRound + 3
    || current.redNightLastRound === m.round) {
    return { match: m, targetIds: [], succeeded: false, note: 'Eyes on the Crossing has no steal available this turn.' };
  }
  m = modify(m, current.instanceId, card => ({ ...card, redNightLastRound: m.round }));
  const enemy: Owner = current.owner === 'player' ? 'cpu' : 'player';
  const enemyHere = inLane(m, enemy, current.lane);
  const target = enemyHere.length
    ? highest(enemyHere.filter(card => card.cardId !== 'blueside1' && !card.statuses.uncounterable
      && rawCombatPower(card) > 0))
    : highest(inLane(m, current.owner, current.lane)
    .filter(card => card.instanceId !== current.instanceId && card.kind !== 'support'
      && card.cardId !== 'blueside1' && !card.statuses.uncounterable
      && rawCombatPower(card) > 1));
  if (!target) return { match: m, targetIds: [], succeeded: false,
    note: enemyHere.length
      ? 'Eyes on the Crossing found no enemy it could steal from; allies are safe while enemies remain.'
      : 'Eyes on the Crossing found no ally with a Hand to spare.' };
  const enemyTarget = target.owner !== current.owner;
  const beforeHit = m;
  m = enemyTarget
    ? targetEnemyPowerReduction(m, current, target, 1, 'Eyes on the Crossing: stole 1 Hand.')
    : reduceHands(m, target, 1, 'Eyes on the Crossing: gave 1 Hand to OG Red Night.');
  const succeeded = directDamageAmount(beforeHit, m, target) > 0;
  if (succeeded) m = modify(m, current.instanceId, card => ({ ...card, powerModifier: card.powerModifier + 1,
    lastEffectNote: `Eyes on the Crossing: stole 1 Hand from ${enemyTarget ? 'an enemy' : 'an ally'}.` }));
  return { match: m, targetIds: [target.instanceId, ...(succeeded ? [current.instanceId] : [])],
    succeeded, note: succeeded
      ? `Eyes on the Crossing stole 1 Hand from ${target.name} and gave it to OG Red Night.`
      : `Eyes on the Crossing could not take a Hand from ${target.name}.` };
}
function resolveSideOzAbility(m: Match, source: CardInstance, echoed: boolean): Match {
  const before = m, lane = source.lane!, enemy = source.owner === 'player' ? 'cpu' : 'player';
  const targets: string[] = [];
  let succeeded = false;
  let resolution = '';
  const own = () => m.boards.flat().filter(card => !card.hazard && card.owner === source.owner);
  const enemiesHere = () => inLane(m, enemy, lane);
  const buff = (target: CardInstance, amount: number, note: string) => {
    targets.push(target.instanceId);
    m = modify(m, target.instanceId, card => ({ ...card, powerModifier: card.powerModifier + amount, lastEffectNote: note }));
    succeeded = true;
  };
  const protect = (target: CardInstance | undefined) => {
    if (!target || target.statuses.protected) return false;
    targets.push(target.instanceId);
    m = grantProtection(m, source, target.instanceId);
    return !!findCard(m, target.instanceId)?.statuses.protected;
  };
  const openOtherLanes = (owner: Owner, from: Lane) => ([0, 1, 2] as Lane[])
    .filter(candidate => candidate !== from && inLane(m, owner, candidate).length < 4
      && !getStoryLockedLanes(m, owner).includes(candidate))
    .sort((a, b) => getLaneScoreForMatch(m, inLane(m, owner, a), a, owner)
      - getLaneScoreForMatch(m, inLane(m, owner, b), b, owner) || a - b);
  const applyStatus = (target: CardInstance | undefined, status: 'weakened' | 'silenced' | 'locked') => {
    if (!target || target.statuses[status]) return false;
    targets.push(target.instanceId);
    m = hostileEffect(m, source, target, (state, actual) => queueDisruptionReactions(
      state, modify(state, actual.instanceId, card => ({
        ...card, statuses: { ...card.statuses, [status]: true },
        lastEffectNote: `${source.ability}: ${status === 'weakened' ? 'Weakened' : status === 'silenced' ? 'Silenced' : 'Locked'}.`,
      })), source, actual.instanceId,
    ), false, false, true);
    return !!findCard(m, target.instanceId)?.statuses[status];
  };
  const damage = (target: CardInstance | undefined, amount: number) => {
    if (!target) return false;
    targets.push(target.instanceId);
    const beforeDamage = m;
    m = targetEnemyPowerReduction(m, source, target, amount, `${source.ability}: -${amount} Hands.`);
    return directDamageAmount(beforeDamage, m, target) > 0;
  };
  const alliesHere = () => inLane(m, source.owner, lane).filter(card => card.instanceId !== source.instanceId && !card.hazard);

  if (source.cardId === 'redside1') {
    const destination = openOtherLanes(source.owner, lane)[0];
    if (destination !== undefined) {
      m = move(m, source, destination, 'Take the Shortcut: moved to your weakest open district.');
      if (findCard(m, source.instanceId)?.lane === destination) {
        buff(findCard(m, source.instanceId)!, 1, 'Take the Shortcut: successful move, +1 Hand.');
        m = addDiscountToken(m, source.owner, source, 'red-side');
      }
    }
    resolution = succeeded ? 'Take the Shortcut moved Red Plaid Petey, granted +1 Hand, and discounted the next Red Side card.' : 'Take the Shortcut found no legal route.';
  } else if (source.cardId === 'redside2') {
    if (findCard(m, source.instanceId)?.redNightStartRound === undefined) {
      m = modify(m, source.instanceId, card => ({ ...card, redNightStartRound: m.round }));
    }
    const steal = resolveRedNightSteal(m, source);
    m = steal.match; targets.push(...steal.targetIds);
    succeeded = steal.succeeded; resolution = steal.note;
  } else if (source.cardId === 'redside3') {
    succeeded = damage(highest(enemiesHere()), 1);
    const otherOpen = openOtherLanes(source.owner, lane);
    const roll = seededIndex(JSON.stringify(['red-robber', source.instanceId, m.round, m.nextEventSequence]), 2);
    if (otherOpen.length && roll === 0) {
      const destination = otherOpen[seededIndex(JSON.stringify(['red-robber-district', source.instanceId, m.round, m.nextEventSequence]), otherOpen.length)];
      m = summonCard(m, source.owner, destination, sideOzWaveCards.redside3, 'redside3', source, false, 'red-side-3');
      const copy = m.boards[destination].at(-1)!;
      targets.push(copy.instanceId);
      const foe = highest(inLane(m, enemy, destination));
      if (foe) {
        const beforeDamage = m;
        m = targetEnemyPowerReduction(m, copy, foe, 1, 'Check In: summoned Red Robber dealt 1 damage.');
        if (directDamageAmount(beforeDamage, m, foe) > 0) targets.push(foe.instanceId);
      }
      succeeded = true;
      resolution = 'Check In hit here and summoned one Red Robber in another district.';
    } else resolution = succeeded ? 'Check In dealt 1 damage; no extra Red Robber arrived.' : 'Check In found no unprotected target or open summon.';
  } else if (source.cardId === 'redside4') {
    succeeded = applyStatus(highest(enemiesHere()), 'weakened');
    resolution = succeeded ? 'Bad Omen applied Weaken.' : 'Bad Omen had no target or its status was blocked or already present.';
  } else if (source.cardId === 'redside5') {
    const allies = own().filter(card => card.instanceId !== source.instanceId && card.kind !== 'support');
    const isRed = (card: CardInstance) => (card.gangTag ?? GANG_BY_CARD_ID[card.cardId]) === 'red' || sideOzWaveFactions[card.cardId] === 'Red Side';
    const target = lowest(allies.filter(isRed)) ?? lowest(allies);
    const amount = target && isRed(target) ? 3 : 2;
    if (target) buff(target, amount, `Raise the Colors: +${amount} Hands.`);
    else {
      buff(findCard(m, source.instanceId)!, 1, 'Raise the Colors: no other ally, +1 Hand.');
      applyStatus(highest(enemiesHere()), 'weakened');
    }
    resolution = target ? `${target.name} gained +${amount} Hands.` : 'With no other character ally, Ruby Shades gained +1 Hand and tried to Weaken an enemy here.';
  } else if (source.cardId === 'blueside1') {
    const target = highest(m.boards.flat().filter(card => !card.hazard && card.owner === enemy && card.lane !== lane));
    const hit = damage(target, 3);
    const blueCount = own().filter(card => sideOzWaveFactions[card.cardId] === 'Blue Side').length;
    const remoteBlueDistricts = new Set(own().filter(card => card.lane !== null && card.lane !== lane
      && (card.gangTag ?? GANG_BY_CARD_ID[card.cardId]) === 'blue').map(card => card.lane)).size;
    const gain = blueCount + remoteBlueDistricts;
    buff(findCard(m, source.instanceId)!, gain, `Crossfire: +${blueCount} from Blue Side allies and +${remoteBlueDistricts} from other Blue Set districts.`);
    resolution = `Crossfire ${hit ? 'dealt 3 damage' : 'found no unprotected target'} and gained +${gain} Hands.`;
  } else if (source.cardId === 'blueside2') {
    buff(findCard(m, source.instanceId)!, 1, 'Stand Behind Me: +1 Hand; next ally gains Protection.');
    m = modify(m, source.instanceId, card => ({ ...card, blueCoverReady: true }));
    resolution = 'lil Blue gained +1 Hand and prepared Protection for the next deployed ally.';
  } else if (source.cardId === 'blueside3') {
    const routed = clearBlueScarfRoute(m, source);
    m = routed.match; targets.push(...routed.targetIds);
    succeeded = routed.moved > 0;
    resolution = routed.note;
  } else if (source.cardId === 'blueside4') {
    const affected = lowest(alliesHere().filter(card => card.statuses.frozen || card.statuses.silenced));
    if (affected) {
      targets.push(affected.instanceId);
      const old = affected.statuses;
      m = cleanseAlly(m, affected.instanceId, card => ({
        ...card, statuses: { ...card.statuses, frozen: false, silenced: false },
        powerModifier: card.powerModifier + 2, lastEffectNote: 'Steady Nerves: cleansed Freeze and Silence, +2 Hands.',
      }));
      const current = findCard(m, affected.instanceId);
      succeeded = !!current && (old.frozen !== current.statuses.frozen || old.silenced !== current.statuses.silenced
        || current.powerModifier > affected.powerModifier);
      resolution = 'Steady Nerves cleansed Freeze and Silence and gave +2 Hands.';
    } else {
      const target = lowest([...alliesHere(), source].filter(card => !card.statuses.protected));
      const covered = protect(target);
      buff(findCard(m, source.instanceId)!, 1, 'Steady Nerves: +1 Hand with no ally to cleanse.');
      resolution = covered ? `${target!.name} gained Protection; Blue loco gained +1 Hand.` : 'Blue loco gained +1 Hand; no ally needed Protection.';
    }
  } else if (source.cardId === 'blueside5') {
    succeeded = applyStatus(highest(enemiesHere()), 'weakened');
    if (succeeded) buff(findCard(m, source.instanceId)!, 1, 'Measured Strike: Weaken landed, +1 Hand.');
    resolution = succeeded ? 'Measured Strike applied Weaken and granted +1 Hand.' : 'Measured Strike had no target or its status was blocked or already present.';
  } else if (source.cardId === 'wickedwitch') {
    let drained = 0;
    for (const foe of enemiesHere().filter(card => card.powerModifier > 0)) {
      const previous = foe.powerModifier;
      if (damage(foe, Math.min(2, previous))) drained++;
    }
    if (drained) buff(findCard(m, source.instanceId)!, drained, `Voice of the West: +${drained} Hands stolen.`);
    let summoned = false;
    if (inLane(m, source.owner, lane).length < 4) {
      m = summonCard(m, source.owner, lane, sideOzWaveCards.flyingmonkeys, 'flyingmonkeys', source, false, 'flying-monkeys');
      targets.push(m.boards[lane].at(-1)!.instanceId);
      summoned = true; succeeded = true;
    }
    resolution = `Voice of the West drained ${drained} boosted enem${drained === 1 ? 'y' : 'ies'}${summoned ? ' and summoned Flying Monkeys.' : '; no room for Flying Monkeys.'}`;
  } else if (source.cardId === 'flyingmonkeys') {
    const target = lowest(enemiesHere());
    const destination = target ? openOtherLanes(target.owner, lane)[0] : undefined;
    if (target && destination !== undefined) {
      targets.push(target.instanceId);
      const oldLane = target.lane;
      m = forceEnemyMove(m, source, target, destination);
      succeeded = findCard(m, target.instanceId)?.lane !== oldLane;
      if (succeeded) m = applyBurn(m, source, findCard(m, target.instanceId)!, 1, 'Snatch and Scatter: 1 Burn.');
    }
    resolution = succeeded ? 'Snatch and Scatter moved the enemy to its weakest open district and applied Burn.' : 'Snatch and Scatter found no target or legal destination, or movement was blocked.';
  }

  if (succeeded && !echoed) m = trainWaveAbility(m, source.instanceId);
  return addEvent(before, m, { type: 'ability', sourceId: source.instanceId, owner: source.owner,
    lane, targetIds: [...new Set(targets)], note: resolution });
}

function resolveFairytaleAbility(m: Match, source: CardInstance, echoed: boolean): Match {
  const before = m, l = source.lane!, enemy = source.owner === 'player' ? 'cpu' : 'player';
  const id = source.cardId, targets: string[] = [];
  let succeeded = false;
  const buff = (target: CardInstance, amount: number) => { targets.push(target.instanceId); m = modify(m, target.instanceId, c => ({ ...c, powerModifier: c.powerModifier + amount })); succeeded = true; };
  if (id === 'dorothy') {
    const target = lowest(m.boards.flat().filter(c => c.owner === source.owner && c.instanceId !== source.instanceId && (c.kind ?? 'character') === 'character' && c.cost <= 2));
    if (target) {
      const returned = returnToHand(m, source, target, true);
      const hand = target.owner === 'player' ? returned.playerHand : returned.cpuHand;
      m = returned;
      if (hand.some(card => card.instanceId === target.instanceId)) {
        targets.push(target.instanceId);
        succeeded = true;
      }
    }
  } else if (id === 'scarecrow') {
    const ally = lowest(m.boards.flat().filter(c => c.owner === source.owner && c.lane !== l && !c.hazard && c.lane !== null
      && moveRouteLegal(m, source, c.lane) && moveRouteLegal(m, c, l)
      && movementCapacityAvailable(m, source, c.lane, [c.instanceId])
      && movementCapacityAvailable(m, c, l, [source.instanceId])));
    if (ally) {
      const firstDeparture = openTabDeparture(m, source);
      const secondDeparture = firstDeparture.stopped ? firstDeparture : openTabDeparture(firstDeparture.match, ally);
      if (secondDeparture.stopped) m = secondDeparture.match;
      else m = move(secondDeparture.match, source, ally.lane!, 'Wrong Turn, Right Place: swapped districts.', false, false, true, true);
      const traveled = findCard(m, source.instanceId);
      const partner = findCard(m, ally.instanceId);
      if (traveled?.lane === ally.lane && partner) {
        m = move(m, partner, l, 'Wrong Turn, Right Place: swapped districts.', false, false, true);
        const movedSource = findCard(m, source.instanceId);
        const movedPartner = findCard(m, ally.instanceId);
        if (movedSource && movedPartner?.lane === l) {
          buff(movedSource, 1); buff(movedPartner, 1);
        }
      }
    } else {
      const empty = ([0, 1, 2] as Lane[]).find(destination => m.boards[destination].length === 0 && canMoveTo(m, source, destination));
      if (empty !== undefined) {
        m = move(m, source, empty, 'Wrong Turn, Right Place: moved to an empty district.');
        const arrived = findCard(m, source.instanceId);
        if (arrived?.lane === empty && activeAbility(arrived)) buff(arrived, 1);
      }
    }
  } else if (id === 'lion' && inLane(m, source.owner, l).length === 1) {
    m = grantProtection(m, source, source.instanceId); succeeded = !source.statuses.protected;
  } else if (id === 'oz' && !echoed && !source.waveOnce?.oz) {
    const historicalIds = (m.entranceHistory?.length ? m.entranceHistory : (m.lastMovedAlly?.[source.owner] ? [m.lastMovedAlly[source.owner]!.instanceId] : []));
    const eligible = historicalIds.slice().reverse()
      .map(id => m.boards.flat().find(c => c.instanceId === id))
      .filter((c): c is CardInstance => !!c && c.owner === source.owner && c.instanceId !== source.instanceId
        && (c.kind ?? 'character') === 'character' && activeAbility(c) && hasEntrance(c)
        && !['oz', 'tayaty', 'scammer'].includes(abilityCardId(c)) && canEchoCreativeEntrance(abilityCardId(c)));
    const ally = eligible.find(c => ['dorothy', 'scarecrow', 'tinman', 'lion'].includes(abilityCardId(c))) ?? eligible[0];
    if (ally) {
      m = modify(m, source.instanceId, c => ({ ...c, waveOnce: { ...c.waveOnce, oz: true } }));
      m = resolveAbility(m, ally, { echoed: true }); targets.push(ally.instanceId); succeeded = true;
      const movedThisRound = m.roundMovedIds
        ? m.roundMovedIds[source.owner]?.includes(ally.instanceId) ?? false
        : m.lastMovedAlly?.[source.owner]?.instanceId === ally.instanceId
          && m.lastMovedAlly[source.owner]!.round === m.round;
      const echoBonus = movedThisRound ? 3 : ['dorothy', 'scarecrow', 'tinman', 'lion'].includes(abilityCardId(ally)) ? 2 : 0;
      if (echoBonus && findCard(m, ally.instanceId)) m = modify(m, ally.instanceId, c => ({ ...c, powerModifier: c.powerModifier + echoBonus, lastEffectNote: `The Grand Reveal: echoed ally gained +${echoBonus} Hands.` }));
    }
  } else if (id === 'alice' && source.aliceReady && !echoed) {
    m = modify(m, source.instanceId, c => ({ ...c, aliceReady: false })); buff(source, 3);
  } else if (id === 'queenofhearts') {
    const target = lowest(inLane(m, enemy, l));
    if (target && getEffectiveCardPower(target) <= 6) {
      targets.push(target.instanceId);
      let executedInstanceId: string | undefined;
      m = hostileEffect(m, source, target, (state, actual) => {
        if (getEffectiveCardPower(actual) > 6) return state;
        executedInstanceId = actual.instanceId;
        let result = removeDestroyedCard(modify(state, actual.instanceId, c => ({
          ...c, powerModifier: -c.basePower - (c.continuousPower ?? 0), lastEffectNote: 'Off With Their Heads: executed.',
        })), actual.instanceId);
        if (!findCard(result, actual.instanceId)) { result = summonCard(result, source.owner, l, SUMMON_TEMPLATES.cardguard, 'cardguard', source, false, 'queen-of-hearts'); succeeded = true; }
        return result;
      }, false, false, true);
      succeeded = !!executedInstanceId && !findCard(m, executedInstanceId);
    }
  } else if (id === 'sherlock' || id === 'dmvworker') {
    const destinations = id === 'dmvworker' ? [l]
      : ([0, 1, 2] as Lane[]).filter(x => x !== l && !getStoryLockedLanes(m, enemy).includes(x));
    if (destinations.length) {
      const kind = id === 'sherlock' ? 'stakeout' : 'dmv';
      m = { ...m, districtTraps: [...(m.districtTraps ?? []).filter(t => !(t.kind === kind
        && t.owner === source.owner && (id === 'sherlock' || destinations.includes(t.lane)))),
        ...destinations.map((destination): DistrictTrap => ({ kind, owner: source.owner, lane: destination, source,
          expiresAfterRound: m.round + 1 }))] }; succeeded = true;
    }
  } else if (id === 'watson') {
    const target = lowest(inLane(m, source.owner, l).filter(c => (c.recoverableDamage ?? 0) > 0));
    if (target) {
      const amount = Math.min(3, target.recoverableDamage!);
      m = modify(m, target.instanceId, c => ({ ...c, recoverableDamage: Math.max(0, (c.recoverableDamage ?? 0) - amount) }));
      buff(target, amount); m = grantProtection(m, source, target.instanceId);
    } else {
      const fallback = lowest(inLane(m, source.owner, l).filter(c => c.instanceId !== source.instanceId));
      if (fallback) { targets.push(fallback.instanceId); m = grantProtection(m, source, fallback.instanceId); succeeded = true; }
    }
    for (const sherlock of m.boards.flat().filter(c => c.owner === source.owner && abilityCardId(c) === 'sherlock' && activeAbility(c))) {
      if (sherlock.instanceId !== source.instanceId) {
        targets.push(sherlock.instanceId);
        m = grantProtection(m, source, sherlock.instanceId);
        buff(sherlock, 2);
      }
    }
  } else if (id === 'thefeds') {
    const candidates = inLane(m, enemy, l);
    const target = candidates.some(c => removableBonusHands(c) > 0)
      ? [...candidates].sort((a,b) => removableBonusHands(b) - removableBonusHands(a) || getEffectiveCardPower(b) - getEffectiveCardPower(a) || a.instanceId.localeCompare(b.instanceId))[0]
      : highest(candidates);
    if (target) {
      targets.push(target.instanceId);
      const before = m;
      let recipient: CardInstance | undefined;
      m = hostileEffect(m, source, target, (state, actual) => {
        recipient = actual;
        const bonus = removableBonusHands(actual);
        const trimmed = trimBonusHandsUnshielded(state, actual, 8, 'Asset Seizure: confiscated up to 8 bonus Hands.');
        return modify(trimmed.match, actual.instanceId, c => ({ ...c,
          statuses: { ...c.statuses, locked: true, ...(!bonus ? { weakened: true } : {}) },
          lastEffectNote: `Asset Seizure: removed ${trimmed.removed} bonus Hands; Locked${!bonus ? ' and Weakened' : ''}.`,
        }));
      }, false, false, true);
      if (recipient) {
        const current = findCard(m, recipient.instanceId);
        succeeded = bonusHandsRemovedBetween(before, m, recipient.instanceId) > 0
          || !!current && ((!recipient.statuses.locked && current.statuses.locked)
            || (!recipient.statuses.weakened && current.statuses.weakened));
        if (recipient.instanceId !== target.instanceId) targets.push(recipient.instanceId);
      }
    }
  } else if (id === 'ptang') {
    const target = highest(inLane(m, enemy, l));
    if (target) {
      targets.push(target.instanceId);
      m = hostileEffect(m, source, target, (state, actual) => {
        let result = reduceHands(state, actual, 3, 'Belt Check: 3 damage.');
        const survivor = result.boards.flat().find(c => c.instanceId === actual.instanceId);
        const damageLanded = directDamageAmount(state, result, actual) > 0;
        if (survivor) {
          const destination = [((survivor.lane! + 1) % 3) as Lane, ((survivor.lane! + 2) % 3) as Lane]
            .find(x => !getStoryLockedLanes(result, survivor.owner).includes(x)
              && inLane(result, survivor.owner, x).length < 4);
          if (destination !== undefined) result = forceMoveUnshielded(result, survivor, destination);
        }
        const after = findCard(result, actual.instanceId);
        const moved = !!after && after.lane !== actual.lane;
        succeeded = damageLanded || moved;
        if (damageLanded && after && !moved) {
          const tang = findCard(result, source.instanceId);
          if (tang) {
            targets.push(tang.instanceId);
            result = modify(result, tang.instanceId, c => ({ ...c, powerModifier: c.powerModifier + 2,
              lastEffectNote: 'Belt Check: surviving target held its ground, +2 Hands.' }));
            succeeded = true;
          }
        }
        return result;
      }, false, false, true);
    }
  } else if (id === 'corruptpastor') {
    for (const ally of inLane(m, source.owner, l).filter(c => c.instanceId !== source.instanceId && rawCombatPower(c) > 1)) {
      const beforePayment = m;
      m = modifyWithoutDamage(m, ally, c => ({ ...c, powerModifier: c.powerModifier - 1 }));
      if (bonusHandsRemovedBetween(beforePayment, m, ally.instanceId) > 0) {
        buff(findCard(m, source.instanceId)!, 2); targets.push(ally.instanceId);
      }
    }
  } else if (id === 'powerhouse' && (source.bankedMotion ?? 0) > 0) {
    for (const target of inLane(m, enemy, l)) {
      targets.push(target.instanceId);
      const beforeDamage = m;
      m = targetEnemyPowerReduction(m, source, target, source.bankedMotion!, 'Overtime: ' + source.bankedMotion + ' banked damage.');
      succeeded ||= directDamageAmount(beforeDamage, m, target) > 0;
    }
  } else if (id === 'squabbleserver') {
    const target = lowest(inLane(m, source.owner, l).filter(c => c.statuses.frozen || c.statuses.burnStacks > 0));
    if (target) {
      targets.push(target.instanceId);
      m = cleanseAlly(m, target.instanceId, c => ({ ...c, statuses: { ...c.statuses, frozen: false, burnStacks: 0 }, burnSource: undefined, lastEffectNote: 'Fresh Pot: Burn and Freeze cleared.' })); succeeded = true;
    }
  }
  if (succeeded && !echoed) m = trainWaveAbility(m, source.instanceId);
  return addEvent(before, m, { type: 'ability', sourceId: source.instanceId, owner: source.owner, targetIds: targets,
    note: source.ability + (succeeded ? ' resolved.' : ': waiting for its condition or blocked.') });
}

/** All deck draws share a cursor so a tutored reserve can never be dealt twice. */
function drawDeckCard(m: Match, owner: Owner, reserveIndex?: number): { match: Match; card?: CardInstance } {
  const hand = owner === 'player' ? 'playerHand' : 'cpuHand';
  const indexKey = owner === 'player' ? 'playerDrawIndex' : 'cpuDrawIndex';
  const deck = owner === 'player' ? m.playerDeck : m.cpuDeck;
  const ids = owner === 'player' ? m.playerCardIds : m.cpuCardIds;
  const reserved = m.storyRuntime?.drawnReserveIndexes?.[owner] ?? [];
  let cursor = m[indexKey];
  while (reserved.includes(cursor)) cursor++;
  const index = reserveIndex ?? cursor;
  if (index < cursor || reserved.includes(index) || !ids[index]) return { match: m };
  const card = createCardInstance(ids[index], owner, deck, index);
  const taken = index > cursor ? [...reserved, index] : reserved;
  let next = index === cursor ? cursor + 1 : cursor;
  while (taken.includes(next)) next++;
  return { card, match: { ...m, [hand]: [...m[hand], card], [indexKey]: next,
    ...(m.storyRuntime && taken.length ? { storyRuntime: { ...m.storyRuntime,
      drawnReserveIndexes: { ...m.storyRuntime.drawnReserveIndexes, [owner]: taken },
    } } : {}),
  } };
}

const storyLog = (before: Match, after: Match, id: string, owner: Owner, note: string): Match => {
  const logged = addEvent(before, after, { type: 'ability', owner, lane: 0, kind: 'story', note });
  if (logged[SUPPRESS_PRESENTATION_EVENTS]) return logged;
  return {
    ...logged,
    effectLog: [...logged.effectLog.slice(0, -1), {
      ...logged.effectLog.at(-1)!,
      cardInstanceId: `story:${id}`,
      cardId: 'story',
    }],
  };
};
const storyTriggerMet = (match: Match, trigger: StoryTrigger): boolean => {
  if (trigger.kind === "round") return match.round >= trigger.atLeast;
  if (trigger.kind === "total-power") {
    const total = ([0, 1, 2] as Lane[]).reduce((sum, targetLane) => sum + getLaneScoreForMatch(
      match,
      inLane(match, trigger.owner, targetLane),
      targetLane,
      trigger.owner,
    ), 0);
    return total >= trigger.atLeast;
  }
  return getDistrictResults(match).filter((result) => result.winner === trigger.owner).length >= trigger.atLeast;
};
const applyStoryEffect = (match: Match, effect: StoryEffect, effectId: string): Match => {
  if (!match.storyRuntime || match.storyRuntime.appliedEffectIds.includes(effectId)) return match;
  const before = match;
  let m: Match = {
    ...match,
    storyRuntime: {
      ...match.storyRuntime,
      appliedEffectIds: [...match.storyRuntime.appliedEffectIds, effectId],
    },
  };
  let detail = `Story effect ${effectId}: ${effect.kind}.`;
  if (effect.kind === "motion") {
    const key = effect.owner === "player" ? "playerMotion" : "cpuMotion";
    m = { ...m, [key]: Math.min(MAX_MOTION, Math.max(0, m[key] + effect.amount)) };
  } else if (effect.kind === "reinforcement") {
    const key = effect.owner === "player" ? "playerHand" : "cpuHand";
    const ids = effect.owner === 'player' ? m.playerCardIds : m.cpuCardIds;
    const character = (cards[effect.cardId]?.kind ?? 'character') === 'character';
    const reserveIndex = ids.indexOf(effect.cardId);
    if (character && !effect.allowDuplicate && reserveIndex >= 0) {
      const drawn = drawDeckCard(m, effect.owner, reserveIndex);
      m = drawn.match;
      detail += drawn.card ? ' Brought an existing character from the remaining deck.'
        : ' That character was already dealt; no duplicate created.';
    } else if (character && !effect.allowDuplicate
      && m.storyRuntime!.reinforcedCharacterIds?.[effect.owner]?.includes(effect.cardId)) {
      detail += ' That character already reinforced this side; no duplicate created.';
    } else {
      const card = createCardInstance(effect.cardId, effect.owner, `story:${m.storyEncounter!.id}:${effectId}`, 0);
      m = { ...m, [key]: [...m[key], card],
        ...(character && !effect.allowDuplicate ? { storyRuntime: { ...m.storyRuntime!,
          reinforcedCharacterIds: { ...m.storyRuntime!.reinforcedCharacterIds,
            [effect.owner]: [...(m.storyRuntime!.reinforcedCharacterIds?.[effect.owner] ?? []), effect.cardId],
          },
        } } : {}),
      };
    }
  } else if (effect.kind === 'draw') {
    let count = 0;
    for (let i = 0; i < Math.min(DECK_SIZE, effect.amount); i++) {
      const drawn = drawDeckCard(m, effect.owner);
      m = drawn.match;
      if (!drawn.card) break;
      count++;
    }
    detail += count ? ` Drew ${count} remaining deck card${count === 1 ? '' : 's'}.`
      : ' Deck empty; no card drawn.';
  } else if (effect.kind === "lane-power") {
    m = { ...m, storyRuntime: { ...m.storyRuntime!, lanePowerBonuses: [...m.storyRuntime!.lanePowerBonuses, { ...effect }] } };
  } else {
    m = { ...m, storyRuntime: { ...m.storyRuntime!, laneLocks: [...m.storyRuntime!.laneLocks, { owner: effect.owner, lanes: [...effect.lanes] }] } };
  }
  return storyLog(before, m, effectId, effect.kind === "motion" || effect.kind === "reinforcement" || effect.kind === 'draw' ? effect.owner : "cpu", detail);
};
function applyStoryEffects(match: Match, roundStartOnly = false): Match {
  if (!match.storyEncounter || !match.storyRuntime) return match;
  let m = match;
  const snapshot = match.storyEncounter;
  for (const [index, item] of (snapshot.modifiers?.roundMotionDeltas ?? []).entries()) {
    if (item.round === m.round) m = applyStoryEffect(m, { kind: "motion", owner: item.owner, amount: item.amount }, `round-motion:${index}:${item.round}`);
  }
  for (const [index, item] of (snapshot.modifiers?.reinforcements ?? []).entries()) {
    if (item.round === m.round) m = applyStoryEffect(m, { kind: "reinforcement", owner: item.owner, cardId: item.cardId, ...(item.allowDuplicate ? { allowDuplicate: true } : {}) }, `reinforcement:${index}:${item.round}`);
  }
  const phases = snapshot.phases ?? [];
  let next = match.storyRuntime.activePhaseIndex + 1;
  if (roundStartOnly) {
    while (next < phases.length && phases[next].trigger.kind === "round"
      && storyTriggerMet(m, phases[next].trigger)) {
      const phase = phases[next];
      const beforePhase = m;
      m = { ...m, storyRuntime: { ...m.storyRuntime!, activePhaseIndex: next } };
      m = storyLog(beforePhase, m, `phase:${phase.id}`, "cpu", `Story phase entered: ${phase.name}.`);
      for (const [effectIndex, effect] of (phase.onEnter ?? []).entries()) {
        m = applyStoryEffect(m, effect, `phase:${phase.id}:${effectIndex}`);
      }
      next += 1;
    }
    return m;
  }
  while (next < phases.length && storyTriggerMet(m, phases[next].trigger)) {
    const phase = phases[next];
    const beforePhase = m;
    m = {
      ...m,
      storyRuntime: { ...m.storyRuntime!, activePhaseIndex: next },
    };
    m = storyLog(beforePhase, m, `phase:${phase.id}`, "cpu", `Story phase entered: ${phase.name}.`);
    for (const [effectIndex, effect] of (phase.onEnter ?? []).entries()) {
      m = applyStoryEffect(m, effect, `phase:${phase.id}:${effectIndex}`);
    }
    next += 1;
  }
  return m;
}

export function getActiveStoryPhase(match: Match): NonNullable<StoryEncounterSnapshot["phases"]>[number] | null {
  const index = match.storyRuntime?.activePhaseIndex ?? -1;
  return index >= 0 ? match.storyEncounter?.phases?.[index] ?? null : null;
}
export function getStoryLockedLanes(match: Match, owner: Owner = "player"): Lane[] {
  const storyLocked = getStoryRuleLockedLanes(match, owner);
  const closed = (match.districtSnapshot?.locations ?? []).flatMap((d, i) =>
    d.effect.kind === 'close-lane' && match.round >= d.effect.atRound ? [i as Lane] : []);
  return [...new Set([...storyLocked, ...closed])].sort() as Lane[];
}
function getStoryRuleLockedLanes(match: Match, owner: Owner): Lane[] {
  const scheduled = (match.storyEncounter?.modifiers?.laneLocks ?? [])
    .filter((lock) => lock.round === match.round && (lock.owner === owner || lock.owner === "both"))
    .flatMap((lock) => lock.lanes);
  const entered = (match.storyRuntime?.laneLocks ?? [])
    .filter((lock) => lock.owner === owner || lock.owner === "both")
    .flatMap((lock) => lock.lanes);
  return [...new Set([...scheduled, ...entered])].sort() as Lane[];
}
export function getStoryModifierSummaries(value: Match | StoryEncounterSnapshot): string[] {
  const snapshot = "round" in value ? value.storyEncounter : value;
  if (!snapshot) return [];
  const modifiers = snapshot.modifiers;
  const summaries: string[] = [];
  const roundLimit = getMatchRoundLimit(snapshot);
  if (roundLimit !== DEFAULT_MATCH_ROUND_LIMIT) summaries.push(`Match length: ${roundLimit} rounds`);
  if (modifiers?.startingMotion) summaries.push(`Starting Motion: player ${modifiers.startingMotion.player ?? 2}, CPU ${modifiers.startingMotion.cpu ?? 2}`);
  if (modifiers?.handSize) summaries.push(`Opening hand: player ${modifiers.handSize.player ?? 5}, CPU ${modifiers.handSize.cpu ?? 5}`);
  for (const lock of modifiers?.laneLocks ?? []) summaries.push(`Round ${lock.round}: ${lock.owner} cannot play lane${lock.lanes.length === 1 ? "" : "s"} ${lock.lanes.join(", ")}`);
  for (const delta of modifiers?.roundMotionDeltas ?? []) summaries.push(`Round ${delta.round}: ${delta.owner} Motion ${delta.amount >= 0 ? "+" : ""}${delta.amount}`);
  for (const bonus of modifiers?.lanePowerBonuses ?? []) summaries.push(`${bonus.owner} lane ${bonus.lane} Hands ${bonus.amount >= 0 ? "+" : ""}${bonus.amount}`);
  for (const reinforcement of modifiers?.reinforcements ?? []) summaries.push(`Round ${reinforcement.round}: ${reinforcement.owner} reinforces with ${reinforcement.cardId}${reinforcement.allowDuplicate ? " (temporary practice copy)" : ""}`);
  for (const phase of snapshot.phases ?? []) {
    const trigger = phase.trigger.kind === "round" ? `At round ${phase.trigger.atLeast}`
      : phase.trigger.kind === "districts-held" ? `When ${phase.trigger.owner} holds at least ${phase.trigger.atLeast} districts`
      : `When ${phase.trigger.owner} has at least ${phase.trigger.atLeast} total Hands`;
    const effects = (phase.onEnter ?? []).map(effect => {
      if (effect.kind === "draw") return `${effect.owner} draws up to ${effect.amount} remaining card${effect.amount === 1 ? "" : "s"} from their deck; an empty deck adds no cards`;
      if (effect.kind === "motion") return `${effect.owner} Motion ${effect.amount >= 0 ? "+" : ""}${effect.amount}`;
      if (effect.kind === "reinforcement") return `${effect.owner} receives ${cards[effect.cardId]?.name ?? effect.cardId}${effect.allowDuplicate ? " as a temporary practice copy" : " if still available"}`;
      if (effect.kind === "lane-power") return `${effect.owner} district ${effect.lane + 1} Hands ${effect.amount >= 0 ? "+" : ""}${effect.amount}`;
      return `${effect.owner} cannot play district${effect.lanes.length === 1 ? "" : "s"} ${effect.lanes.map(lane => lane + 1).join(", ")}`;
    });
    summaries.push(`Phase ${phase.name}: ${phase.description?.trim() || `${trigger}${effects.length ? `: ${effects.join("; ")}` : ""}.`}`);
  }
  return summaries;
}

function resolveAbility(match: Match, source: CardInstance, options: {echoed?:boolean} = {}): Match {
  const result=resolveAbilityBase(match,source,options);
  const settled = activeAbility(source) ? creativeAbilityResolved(match, result, source, creativeTools()) : result;
  return selectedResolved(match, musicResolved(match, settled, source, waveTools(), options.echoed ?? false), source, waveTools(), options.echoed ?? false);
}
function resolveAbilityBase(match: Match, source: CardInstance, { echoed = false }: { echoed?: boolean } = {}): Match {
  const before = match;
  const l = source.lane!, enemy = source.owner === 'player' ? 'cpu' : 'player', kind = source.type === 'Fire' ? 'fire' : source.type === 'Water' ? 'water' : 'ability';
  let m = match;
  const targetIds = new Set<string>();
  const note = (text: string, timing: 'instant' | 'timed' = 'instant', duration: EventDuration | null = null, from?: Match) => {
    const changed = before.boards.flat().filter((old) => {
      const current = findCard(m, old.instanceId);
      return current && JSON.stringify(cardState(old)) !== JSON.stringify(cardState(current));
    }).map((card) => card.instanceId);
    const blocked = changed.map(id => findCard(m, id)).find(c => c?.owner !== source.owner && /blocked/.test(c?.lastEffectNote ?? ''));
    if (blocked) text += ` ${blocked.name}: ${blocked.lastEffectNote}`;
    const absorbed = [...targetIds].some(id => before.timedEffects.some(e => e.kind === 'nail-mitigation' && e.targetInstanceId === id) && !m.timedEffects.some(e => e.kind === 'nail-mitigation' && e.targetInstanceId === id));
    if (absorbed) text += ' Nail Tech absorbed 1 Hands of the reduction.';
    const arrivals = (m.districtRuntime?.trappedCardIds ?? []).filter(id => !before.districtRuntime?.trappedCardIds.includes(id));
    if (arrivals.length) text += ` THE TRAP: ${arrivals.map(id => findCard(m, id)?.name).join(', ')} gained +2 Hands.`;
    const held = [source.instanceId, ...targetIds].map(id => findCard(m, id)).filter(c => c?.lastEffectNote === 'COUNTY JAIL blocked movement.');
    if (held.length) text = `COUNTY JAIL held ${held.map(c => c!.name).join(', ')} in place. Movement did not resolve.`;
    const moved = [source.instanceId, ...targetIds, ...changed].some((id) => {
      const previous = findCard(before, id), current = findCard(m, id);
      return previous && current && previous.lane !== current.lane;
    });
    // Delayed counters may already have emitted their own authoritative transition.
    // A wrapper note starts from the settled state so replay frames never repeat it.
    const eventBefore = from ?? (m.effectLog.length > before.effectLog.length ? m : before);
    m = addEvent(eventBefore, m, { type: 'ability', sourceId: source.instanceId, owner: source.owner, targetIds: [...targetIds, ...changed], note: text, kind: moved ? 'move' : kind, timing, duration });
  };
  if ((source.statuses.silenced || source.statuses.frozen || source.statuses.weakened)
    && !(UNSILENCEABLE_CARD_IDS as readonly string[]).includes(source.cardId)) { note('Ability did not fire (silenced, frozen, or weakened).'); return m; }
  const selected = selectedReveal(m, source, waveTools(), echoed);
  if (selected) return !echoed && source.effect.includes('On Reveal:') ? {...selected,lastRevealedCardId:source.cardId,entranceHistory:[...(selected.entranceHistory??[]).filter(id=>id!==source.instanceId),source.instanceId]} : selected;
  const wave = streetLegendsReveal(m, source, waveTools(), echoed) ?? musicReveal(m, source, waveTools(), echoed);
  if (wave) return !echoed && source.effect.includes('On Reveal:') ? { ...wave, lastRevealedCardId: source.cardId, entranceHistory: [...(wave.entranceHistory ?? []).filter(id => id !== source.instanceId), source.instanceId] } : wave;
  const homecoming = homecomingReveal(m, source, homecomingTools(), echoed);
  if (homecoming) return !echoed ? { ...homecoming, lastRevealedCardId: source.cardId,
    entranceHistory: [...(homecoming.entranceHistory ?? []).filter(id => id !== source.instanceId), source.instanceId] } : homecoming;
  const creative = creativeReveal(m, source, creativeTools(), echoed);
  if (creative) return !echoed && source.effect.includes('On Reveal:') ? { ...creative, lastRevealedCardId: source.cardId,
    entranceHistory: [...(creative.entranceHistory ?? []).filter(id => id !== source.instanceId), source.instanceId] } : creative;
  if (Object.hasOwn(blockbusterWaveCards, source.cardId)) {
    const result = resolveBlockbusterWave(m, source, 0, blockbusterTools());
    m = result.match;
    result.targets.forEach(id => targetIds.add(id));
    note(result.note);
    return echoed ? m : { ...m, lastRevealedCardId: source.cardId,
      entranceHistory: [...(m.entranceHistory ?? []).filter(id => id !== source.instanceId), source.instanceId] };
  }
  if (Object.hasOwn(squabblehouseWaveCards, source.cardId)) {
    let succeeded = false;
    let detail = '';
    if (source.cardId === 'cane-corso-red' || source.cardId === 'blue-nose-pit') {
      if (!echoed) m = approachSquabblehouseOg(m, source.instanceId);
      const liveDog = findCard(m, source.instanceId);
      if (liveDog) m = resolveSquabblehouseDogReveal(m, liveDog, echoed);
      succeeded = findCard(m, source.instanceId)?.squabblehouseEffectRound === m.round;
      const ogId = source.cardId === 'cane-corso-red' ? 'triple-og-red' : 'triple-og-blue';
      detail = succeeded ? `${source.name} found its matching ${ogId} and backed it up.`
        : `${source.name} waits for a support opportunity in its matching OG’s district.`;
    } else if (source.cardId === 'squabblehouse-bus-boy') {
      const passenger = lowest(inLane(m, source.owner, l).filter(card => card.instanceId !== source.instanceId
        && isSquabblehouseStaffCharacter(card)));
      const destinations = ([0, 1, 2] as Lane[]).filter(destination => destination !== l
        && inLane(m, source.owner, destination).length < 4
        && !getStoryLockedLanes(m, source.owner).includes(destination))
        .sort((a, b) => getLaneScoreForMatch(m, inLane(m, source.owner, a), a, source.owner)
          - getLaneScoreForMatch(m, inLane(m, source.owner, b), b, source.owner) || a - b);
      const destination = destinations[0];
      const movable = passenger && !passenger.statuses.frozen && !passenger.statuses.locked
        && !m.districtRuntime?.detainedCardIds.includes(passenger.instanceId)
        && !squabblehouseMovementLocked(m, passenger);
      if (passenger && destination !== undefined && movable) {
        const from = passenger.lane;
        const moved = move(m, passenger, destination, 'Clear the Table moved this staff member.', false, true);
        if (findCard(moved, passenger.instanceId)?.lane === destination && from !== destination) {
          const beforeReward = moved;
          m = modify(beforeReward, passenger.instanceId, card => ({ ...card, powerModifier: card.powerModifier + 1,
            lastEffectNote: 'Clear the Table: successful move, +1 Hand.' }));
          m = addEvent(beforeReward, m, { type: 'ability', sourceId: source.instanceId, owner: source.owner,
            lane: destination, targetIds: [passenger.instanceId],
            note: 'Clear the Table: after arrival effects, the moved staff member gained +1 Hand.' });
          targetIds.add(passenger.instanceId);
          succeeded = true;
        } else m = moved;
      }
      detail = succeeded
        ? 'Clear the Table moved the weakest other friendly staff member to the weakest open district and gave it +1 Hand.'
        : 'Clear the Table found no movable staff member and legal open destination.';
    } else if (source.cardId === 'squabblehouse-cashier') {
      const target = highest(inLane(m, enemy, l).filter(card => (card.kind ?? 'character') === 'character'));
      let lockedTargetId: string | undefined;
      const beforeLockAttempt = m;
      if (target) {
        targetIds.add(target.instanceId);
        m = hostileEffect(m, source, target, (state, actual) => {
          lockedTargetId = actual.instanceId;
          return modify(state, actual.instanceId, card => ({
            ...card,
            squabblehouseCannotMoveThroughRound: Math.max(card.squabblehouseCannotMoveThroughRound ?? 0, state.round + 1),
            lastEffectNote: 'Pay Your Tab: cannot move or return through the end of next round.',
          }));
        }, false, false, true);
      }
      const beforeLockedTarget = lockedTargetId ? findCard(beforeLockAttempt, lockedTargetId) : undefined;
      const committedLockedTarget = lockedTargetId ? findCard(m, lockedTargetId) : undefined;
      const lockApplied = !!beforeLockedTarget && !!committedLockedTarget
        && (committedLockedTarget.squabblehouseCannotMoveThroughRound ?? 0)
          > (beforeLockedTarget.squabblehouseCannotMoveThroughRound ?? 0);
      if (lockApplied && lockedTargetId) targetIds.add(lockedTargetId);
      const isReceipt = (t: DistrictTrap) => t.kind === 'open-tab' && t.owner === source.owner && t.lane === l;
      const old = (m.districtTraps ?? []).find(isReceipt);
      const expiresAfterRound = Math.max(old?.expiresAfterRound ?? 0, m.round + 1);
      const extended = !old || expiresAfterRound > old.expiresAfterRound;
      if (extended) {
        const receipt = { kind: 'open-tab' as const, owner: source.owner, lane: l, source: { ...source, statuses: { ...source.statuses } }, expiresAfterRound, spentRound: old?.spentRound };
        m = { ...m, districtTraps: [...(m.districtTraps ?? []).filter(t => !isReceipt(t)), receipt] };
      }
      succeeded = lockApplied || extended;
      const effects: string[] = [];
      if (lockApplied && target) effects.push(`${target.name} locked through R${m.round + 1}`);
      effects.push(extended
        ? `Open Tab covers enemy departures through R${expiresAfterRound}`
        : `Open Tab already covers departures through R${expiresAfterRound}`);
      detail = effects.join('; ') + '.';
    } else if (source.cardId === 'waffle-warlord') {
      const staffedEverywhere = ([0, 1, 2] as Lane[]).every(district =>
        inLane(m, source.owner, district).some(isSquabblehouseStaffCharacter));
      const amount = staffedEverywhere ? 2 : 1;
      for (const district of [0, 1, 2] as Lane[]) {
        const ally = lowest(inLane(m, source.owner, district).filter(card =>
          card.instanceId !== source.instanceId && isSquabblehouseStaffCharacter(card)));
        if (!ally) continue;
        m = modify(m, ally.instanceId, card => ({ ...card, powerModifier: card.powerModifier + amount,
          lastEffectNote: `All-Star Hands: +${amount} Hand${amount === 1 ? '' : 's'}.` }));
        targetIds.add(ally.instanceId);
        succeeded = true;
      }
      detail = succeeded
        ? `All-Star Hands gave the weakest other staff member in each eligible district +${amount} Hand${amount === 1 ? '' : 's'}.`
        : 'All-Star Hands found no other staff member to boost.';
    } else if (source.cardId === 'squabblehouse-security') {
      const target = highest(inLane(m, enemy, l));
      if (target) {
        targetIds.add(target.instanceId);
        const prior = findCard(m, target.instanceId);
        const beforeDamage = m;
        m = targetEnemyPowerReduction(m, source, target, 2, 'Keep the Peace: strongest enemy -2 Hands.');
        succeeded = !!prior && directDamageAmount(beforeDamage, m, prior) > 0;
      }
      detail = target ? 'Keep the Peace checked the strongest enemy for -2 Hands.'
        : 'Keep the Peace found no enemy in this district.';
    } else if (source.cardId === 'squabblehouse-teknician') {
      const staff = [...(m.squabblehouseRevealHistory ?? [])].reverse()
    .filter(entry => entry.owner === source.owner && SQUABBLEHOUSE_TECH_STAFF.has(entry.cardId)
          && entry.sourceInstanceId !== source.instanceId)
        .map(entry => findCard(m, entry.sourceInstanceId))
        .find((card): card is CardInstance => !!card && activeAbility(card)
          && SQUABBLEHOUSE_TECH_STAFF.has(card.cardId));
      if (staff) {
        m = resolveSquabblehouseStaffEcho(m, findCard(m, source.instanceId) ?? source, staff, 'reveal');
        succeeded = findCard(m, source.instanceId)?.squabblehouseTeknicianRevealRound === m.round;
        targetIds.add(staff.instanceId);
      }
      detail = staff ? `Run It Back repeated ${staff.name}'s On Reveal once.`
        : 'Run It Back found no eligible friendly Squabblehouse staff On Reveal.';
    } else if (source.cardId === 'griddle-master') {
      const target = highest(inLane(m, enemy, l));
      let after: CardInstance | undefined;
      let damageResolved = 3;
      if (target) {
        targetIds.add(target.instanceId);
        const prior = findCard(m, target.instanceId)!;
        const beforeDamage = m;
        const breakProtection = target.statuses.protected;
        m = hostileEffect(m, source, target, (state, actual) => {
          let result = state;
          if (breakProtection) {
            const protectedCard = findCard(result, target.instanceId);
            if (protectedCard) {
              result = { ...result, timedEffects: result.timedEffects.filter(effect =>
                !((effect.kind === 'church-protection' || effect.kind === 'salon-protection')
                  && effect.targetInstanceId === protectedCard.instanceId)) };
              result = modify(result, protectedCard.instanceId, card => ({ ...card,
                statuses: { ...card.statuses, protected: false },
                lastEffectNote: 'Hot Off the Griddle: Protection removed before the attack.' }));
            }
          }
          const damageTarget = findCard(result, actual.instanceId) ?? actual;
          const damage = actual.statuses.burnStacks > 0 ? 5 : 3;
          damageResolved = damage;
          result = reduceHands(result, damageTarget, damage,
            `Hot Off the Griddle: ${damage} damage and 1 Burn.`, damageTarget.statuses.burnStacks + 1);
          return modify(result, actual.instanceId, card => ({
            ...card, burnSource: { instanceId: source.instanceId, owner: source.owner },
          }));
        }, false, false, true, breakProtection);
        after = findCard(m, target.instanceId);
        const dogTookPackage = m.boards.flat().some(card => card.owner === enemy && card.lane === l
          && ['cane-corso-red', 'blue-nose-pit'].includes(card.cardId)
          && card.lastEffectNote.includes('Hot Off the Griddle'));
        const protectionRemoved = !!after && prior.statuses.protected && !after.statuses.protected;
        succeeded = directDamageAmount(beforeDamage, m, prior) > 0 || (!!after && protectionRemoved)
          || (after?.statuses.burnStacks ?? 0) > prior.statuses.burnStacks || dogTookPackage;
      }
      if (target) {
        const pieces = [`${target.name} took ${damageResolved} damage and 1 Burn`];
        if (target.statuses.protected && !findCard(m, target.instanceId)?.statuses.protected) {
          pieces.push('Protection broken');
        }
        detail = `${pieces.join('; ')}.`;
      } else detail = 'No enemy here.';
    } else if (source.cardId === 'inmate-reformed') {
      const hasStaff = inLane(m, source.owner, l).some(card => card.instanceId !== source.instanceId
        && isSquabblehouseStaff(card) && (card.kind ?? 'character') === 'character');
      if (hasStaff) {
        m = modify(m, source.instanceId, card => ({ ...card, powerModifier: card.powerModifier + 2,
          lastEffectNote: 'Second Chance: friendly house staff here, +2 Hands.' }));
        succeeded = true;
      }
      const target = highest(inLane(m, enemy, l));
      if (target) {
        targetIds.add(target.instanceId);
        const beforeDamage = m;
        m = targetEnemyPowerReduction(m, source, target, 1, 'Second Chance: strongest enemy -1 Hand.');
        succeeded ||= directDamageAmount(beforeDamage, m, target) > 0;
      }
      detail = `Second Chance${hasStaff ? ' found staff here and gained +2 Hands' : ' had no staff bonus'}`
        + (target ? '; it checked the strongest enemy for -1 Hand.' : '; no enemy was here to check.');
    }
    note(succeeded ? `${source.ability} resolved. ${detail}` : `${source.ability}: ${detail}`);
    if (succeeded && !['cane-corso-red', 'blue-nose-pit'].includes(source.cardId)) m = trainWaveAbility(m, source.instanceId);
    return !echoed ? { ...m, lastRevealedCardId: source.cardId,
      entranceHistory: [...(m.entranceHistory ?? []).filter(id => id !== source.instanceId), source.instanceId] } : m;
  }
  if (Object.hasOwn(tripleOgCards, source.cardId)) {
    const id = source.cardId;
    // Movement and interception emit their own authoritative frames. The wrapper
    // note must start from the settled state of the last one, or replay jumps
    // over everything this reveal did afterwards.
    let tail: Match | undefined;
    const noteFromTail = (text: string) => note(text, 'instant', null, tail);
    const step = (next: Match): Match => {
      if (next.effectLog.length > m.effectLog.length) tail = next;
      return next;
    };
    const roomFor = (side: Owner, destination: Lane) => destination !== l
      && !getStoryLockedLanes(m, side).includes(destination) && inLane(m, side, destination).length < 4;
    const respectLane = (side: Owner): Lane | undefined => ([0, 1, 2] as Lane[]).filter(d => roomFor(side, d))[0];
    if (id === 'triple-og-blue') {
      const behind = getLaneScoreForMatch(m, inLane(m, source.owner, l), l, source.owner)
        < getLaneScoreForMatch(m, inLane(m, enemy, l), l, enemy);
      let homage = 0, blueHomage = 0;
      if (behind) {
        const allies = m.boards.flat().filter(c => !c.hazard && c.owner === source.owner
          && c.instanceId !== source.instanceId && (c.kind ?? 'character') === 'character');
        const blueSet = (card: CardInstance) => (card.gangTag ?? GANG_BY_CARD_ID[card.cardId]) === 'blue';
        // Blue loyalty fills the capped rally before any ordinary ally is taxed.
        const donors = [...allies.filter(blueSet), ...allies.filter(card => !blueSet(card))];
        for (const ally of donors) {
          if (homage >= 3) break;
          const before = findCard(m, ally.instanceId);
          if (!before) continue;
          if (blueSet(before)) {
            homage++; blueHomage++;
            targetIds.add(before.instanceId);
            continue;
          }
          // Ordinary allies still pay, but never give their last Hand.
          if (rawCombatPower(before) < 2 || cannotLoseHands(before)) continue;
          const beforePayment = m;
          m = modify(m, ally.instanceId, c => ({ ...c, powerModifier: c.powerModifier - 1,
            lastEffectNote: `${source.ability}: paid 1 Hand to ${source.name}.` }));
          if (directDamageAmount(beforePayment, m, before) > 0) { homage++; targetIds.add(ally.instanceId); }
        }
        if (homage) m = modify(m, source.instanceId, c => ({ ...c, powerModifier: c.powerModifier + homage,
          lastEffectNote: `${source.ability}: collected ${homage} Hand${homage === 1 ? '' : 's'}.` }));
      }
      const weakest = lowest(inLane(m, enemy, l));
      let sent = false;
      if (weakest) {
        const destination = ([0, 1, 2] as Lane[]).filter(d => roomFor(weakest.owner, d))
          .sort((a, b) => getLaneScoreForMatch(m, inLane(m, source.owner, b), b, source.owner)
            - getLaneScoreForMatch(m, inLane(m, source.owner, a), a, source.owner) || a - b)[0];
        if (destination !== undefined) {
          targetIds.add(weakest.instanceId);
          m = step(forceEnemyMove(m, source, weakest, destination));
          const moved = findCard(m, weakest.instanceId);
          if (moved?.lane === destination) {
            sent = true;
            m = step(targetEnemyPowerReduction(m, source, moved, -1, `${source.ability}: -1 Hand on the way out.`));
          }
        }
      }
      let reinforced = 0;
      for (const district of ([0, 1, 2] as Lane[]).filter(d => d !== l)) {
        const ally = lowest(inLane(m, source.owner, district)
          .filter(card => (card.gangTag ?? GANG_BY_CARD_ID[card.cardId]) === 'blue'));
        if (!ally) continue;
        targetIds.add(ally.instanceId);
        m = modify(m, ally.instanceId, card => ({ ...card, powerModifier: card.powerModifier + 1,
          lastEffectNote: `${source.ability}: Blue Set reinforcement, +1 Hand.` }));
        m = grantProtection(m, source, ally.instanceId);
        reinforced++;
      }
      noteFromTail(`${source.ability}: ${behind ? homage ? `collected +${homage} Hands (${blueHomage} from Blue Set without Hands loss; ${homage - blueHomage} paid by other allies).` : 'the side had nothing to give.' : 'this district was not losing, so no homage was owed.'}`
        + (sent ? ` ${weakest!.name} was sent to your strongest district with -1 Hand.` : '')
        + (reinforced ? ` Reinforced the weakest Blue Set ally in ${reinforced} other district${reinforced === 1 ? '' : 's'} for +1 Hand and Protection each.` : ''));
      if (!echoed && (homage > 0 || sent || reinforced > 0)) m = trainWaveAbility(m, source.instanceId);
    } else if (id === 'triple-og-red') {
      let taken = 0, affected = 0, respected = 0;
      const lineup = [...inLane(m, source.owner, l).filter(c => c.instanceId !== source.instanceId), ...inLane(m, enemy, l)]
        .filter(c => (c.kind ?? 'character') === 'character');
      const heavyTargets = new Set(lineup.filter(c => c.owner === enemy && !c.statuses.protected
        && !c.statuses.uncounterable && !cannotLoseHands(c))
        .sort((a, b) => getEffectiveCardPower(b) - getEffectiveCardPower(a) || a.instanceId.localeCompare(b.instanceId))
        .slice(0, 3).map(c => c.instanceId));
      for (const other of lineup) {
        const before = findCard(m, other.instanceId);
        if (!before) continue;
        const shielded = before.statuses.protected || before.statuses.uncounterable || cannotLoseHands(before);
        if (shielded) {
          const destination = respectLane(before.owner);
          if (destination === undefined) continue;
          targetIds.add(before.instanceId);
          m = step(before.owner === source.owner
            ? move(m, before, destination, `${source.ability}: moved out of respect.`)
            : forceEnemyMove(m, source, before, destination));
          if (findCard(m, before.instanceId)?.lane === destination) respected++;
          continue;
        }
        // Allies take the same destruction-aware damage as enemies, so a 1-Hand
        // ally leaves the board instead of lingering at zero.
        const beforeDamage = m;
        const damage = before.owner === enemy && heavyTargets.has(before.instanceId) ? 2 : 1;
        m = step(before.owner === source.owner
          ? reduceHands(m, before, 1, `${source.ability}: -1 Hand.`)
          : targetEnemyPowerReduction(m, source, before, damage, `${source.ability}: -${damage} Hands.`));
        if (rawCombatPower(before) > 0 && directDamageAmount(beforeDamage, m, before) > 0) {
          taken += directDamageAmount(beforeDamage, m, before); affected++; targetIds.add(before.instanceId);
        }
      }
      const gained = Math.min(6, taken);
      if (gained) m = modify(m, source.instanceId, c => ({ ...c, powerModifier: c.powerModifier + gained,
        lastEffectNote: `${source.ability}: took ${gained} Hand${taken === 1 ? '' : 's'} off the district.` }));
      noteFromTail(`${source.ability}: ${affected} card${affected === 1 ? '' : 's'} lost ${taken} Hands total and ${source.name} gained +${gained} (maximum 6).`
        + (respected ? ` ${respected} untouchable card${respected === 1 ? ' was' : 's were'} moved out of respect.` : ''));
      if (!echoed && (taken > 0 || respected > 0)) m = trainWaveAbility(m, source.instanceId);
    } else if (id === 'initiation') {
      m = { ...m, districtTraps: [...(m.districtTraps ?? [])
        .filter(t => !(t.kind === 'initiation' && t.owner === source.owner && t.lane === l)),
        { kind: 'initiation' as const, owner: source.owner, lane: l, source, expiresAfterRound: 99,
          ...(echoed ? { echoed: true } : {}) }] };
      noteFromTail(`${source.ability}: this district is marked. Your next character here gets put on by your set.`);
    } else if (id === 'block-spinner') {
      const target = highest(inLane(m, enemy, l));
      const beforeBurn = m;
      if (target) { targetIds.add(target.instanceId); m = step(applyBurn(m, source, target, 1, `${source.ability}: 1 Burn.`)); }
      const burned = burnLanded(beforeBurn, m, source.instanceId);
      m = { ...m, districtTraps: [...(m.districtTraps ?? [])
        .filter(t => !(t.kind === 'spinner' && t.owner === source.owner && t.lane === l)),
        { kind: 'spinner' as const, owner: source.owner, lane: l, source, expiresAfterRound: m.round + 2, ...(echoed ? { echoed: true } : {}) }] };
      noteFromTail(`${source.ability}: ${target ? `${target.name} took 1 Burn.` : 'nobody was here to burn.'} The block keeps spinning for the next enemy played here.`);
      if (burned && !echoed) m = trainWaveAbility(m, source.instanceId);
    } else if (id === 'look-out') {
      m = modify(m, source.instanceId, c => ({ ...c, lookoutReady: (c.lookoutCalls ?? 0) < 3 && c.lookoutCallRound !== m.round, lastEffectNote: `${source.ability}: watching the block.` }));
      noteFromTail(`${source.ability}: the next district your opponent plays into is called out; your next card there costs 1 less Motion.`);
    }
    return echoed ? m : { ...m, lastRevealedCardId: source.cardId,
      entranceHistory: [...(m.entranceHistory ?? []).filter(id2 => id2 !== source.instanceId), source.instanceId] };
  }
  if (Object.hasOwn(afterHoursWaveCards, source.cardId)) {
    const allies = inLane(m, source.owner, l).filter(c => c.instanceId !== source.instanceId);
    let succeeded = false;
    const addHands = (target: CardInstance | undefined, amount: number, text: string) => {
      // Reactions can destroy the source or recipient before its follow-up.
      // A resolved attack stays resolved; never buff a missing character.
      if (!target || !findCard(m, target.instanceId)) return;
      targetIds.add(target.instanceId);
      m = modify(m, target.instanceId, c => ({ ...c, powerModifier: c.powerModifier + amount, lastEffectNote: text }));
      succeeded = true;
    };
    const openDestinations = () => ([0, 1, 2] as Lane[])
      .filter(destination => destination !== l && !getStoryLockedLanes(m, source.owner).includes(destination)
        && inLane(m, source.owner, destination).length < 4)
      .sort((a, b) => getLaneScoreForMatch(m, inLane(m, source.owner, a), a, source.owner)
        - getLaneScoreForMatch(m, inLane(m, source.owner, b), b, source.owner) || a - b);
    if (source.cardId === 'sugarfoot') {
      const target = highest(inLane(m, enemy, l));
      if (target) {
        targetIds.add(target.instanceId);
        let landed = false;
        let hitAlreadyWeakened = false;
        m = hostileEffect(m, source, target, (state, actual) => {
          landed = true;
          hitAlreadyWeakened = actual.statuses.weakened;
          return queueDisruptionReactions(state, modify(state, actual.instanceId, c => ({
            ...c, statuses: { ...c.statuses, weakened: true }, lastEffectNote: 'Sweet Weakness: Weakened.',
          })), source, actual.instanceId);
        }, false, false, true);
        if (landed && findCard(m, target.instanceId)?.lastEffectNote !== 'Turn It Around: hostile effect negated; +2 Hands.') {
          succeeded = true;
          if (hitAlreadyWeakened) addHands(findCard(m, source.instanceId)!, 1, 'Sweet Weakness: already Weakened, +1 Hand.');
        }
      }
    } else if (source.cardId === 'yn-gokarter') {
      const destination = openDestinations()[0];
      if (destination !== undefined) {
        m = move(m, findCard(m, source.instanceId)!, destination, 'Victory Lap: moved to the weakest open district.');
        if (findCard(m, source.instanceId)?.lane === destination) {
          succeeded = true;
          const target = lowest(inLane(m, source.owner, destination).filter(c => c.instanceId !== source.instanceId));
          if (target) addHands(target, 1, 'Victory Lap: +1 Hand.');
        }
      }
    } else if (source.cardId === 'yn-atv-lord') {
      const target = lowest(allies);
      const destination = openDestinations()[0];
      if (target && destination !== undefined) {
        targetIds.add(target.instanceId);
        m = move(m, target, destination, 'Trail Guide: moved to the weakest open district.');
        if (findCard(m, target.instanceId)?.lane === destination) {
          addHands(findCard(m, target.instanceId)!, 1, 'Trail Guide: successful move, +1 Hand.');
        }
      }
    } else if (source.cardId === 'homeless-wiseman') {
      const destination = ([0, 1, 2] as Lane[])
        .filter(candidate => !getStoryLockedLanes(m, enemy).includes(candidate) && inLane(m, enemy, candidate).length < 4)
        .sort((a, b) => getLaneScoreForMatch(m, inLane(m, enemy, a), a, enemy)
          - getLaneScoreForMatch(m, inLane(m, enemy, b), b, enemy) || a - b)[0];
      if (destination !== undefined) {
        m = { ...m, districtTraps: [
          ...(m.districtTraps ?? []).filter(trap => !(trap.kind === 'wiseman' && trap.owner === source.owner)),
          { kind: 'wiseman', owner: source.owner, lane: destination, source: findCard(m, source.instanceId) ?? source, expiresAfterRound: m.round + 1 },
        ] };
        succeeded = true;
      }
    } else if (source.cardId === 'juneteenth-chair-guy') {
      const target = highest(inLane(m, enemy, l));
      if (target) {
        targetIds.add(target.instanceId);
        const beforeDamage = m;
        m = targetEnemyPowerReduction(m, source, target, 2, 'Fold-Out Justice: -2 Hands.');
        succeeded ||= directDamageAmount(beforeDamage, m, target) > 0;
      }
      const ally = lowest(allies);
      if (ally) {
        targetIds.add(ally.instanceId);
        const wasProtected = ally.statuses.protected;
        m = grantProtection(m, source, ally.instanceId);
        succeeded ||= !wasProtected && !!findCard(m, ally.instanceId)?.statuses.protected;
      }
    } else if (source.cardId === 'squabble-house-manager') {
      if (inLane(m, enemy, l).length) addHands(findCard(m, source.instanceId)!, 1, 'Home Advantage: enemy here, +1 Hand.');
    }
    note(succeeded ? `${source.ability} resolved.` : `${source.ability} found no legal target, open district, or removable status.`);
    if (succeeded) m = trainWaveAbility(m, source.instanceId);
    return !echoed ? { ...m, lastRevealedCardId: source.cardId } : m;
  }
  if (Object.hasOwn(cellblockWaveCards, source.cardId)) {
    const allies = inLane(m, source.owner, l).filter(c => c.instanceId !== source.instanceId);
    let succeeded = false;
    let resolutionNote: string | undefined;
    const buff = (target: CardInstance, amount: number) => {
      targetIds.add(target.instanceId);
      m = modify(m, target.instanceId, c => ({ ...c, powerModifier: c.powerModifier + amount,
        lastEffectNote: `${source.ability}: +${amount} Hands.` }));
      succeeded = true;
    };
    if (source.cardId === 'inmate-crafty' && allies.some(c => !c.hazard && (c.kind === 'support'
      || ((c.kind ?? 'character') === 'character' && ['inmate-crafty', 'inmate-boyfriend', 'inmate-informant', 'inmate-contraband'].includes(c.cardId))))) {
      buff(source, 3);
    } else if (source.cardId === 'inmate-boyfriend') {
      const target = lowest(allies);
      if (target) buff(target, 3);
      const remote = lowest(m.boards.flat().filter(c => !c.hazard && c.owner === source.owner
        && c.lane !== l && c.instanceId !== source.instanceId && (c.kind ?? 'character') === 'character'
        && ['inmate-crafty', 'inmate-boyfriend', 'inmate-informant', 'inmate-contraband'].includes(c.cardId)));
      if (remote) buff(remote, 2);
      if (target || remote) resolutionNote = 'Looking Out resolved.'
        + (target ? ` ${target.name} here gained +3 Hands.` : '')
        + (remote ? ` ${remote.name} in another district gained +2 Hands.` : '');
    } else if (source.cardId === 'inmate-informant') {
      const target = highest(inLane(m, enemy, l));
      if (target) {
        targetIds.add(target.instanceId);
        m = targetEnemyPowerReduction(m, source, target, 3, 'Quiet Tip: -3 Hands.');
        // Count actual damage (including an intercepted hit), not a consumed shield.
        succeeded = before.boards.flat().some(old => old.owner === enemy
          && directDamageAmount(before, m, old) > 0);
      }
    } else if (source.cardId === 'inmate-contraband' && allies.some(c => (c.kind ?? 'character') === 'character')) {
      const key = source.owner === 'player' ? 'playerMotion' : 'cpuMotion';
      const previous = m[key];
      m = refundMotion(m, source.owner, 1);
      succeeded = m[key] > previous;
    } else if (source.cardId === 'lebron-james') {
      // Snapshot the condition before cleansing an ally changes the district score.
      const losing = getLaneScoreForMatch(m, inLane(m, source.owner, l), l, source.owner)
        < getLaneScoreForMatch(m, inLane(m, enemy, l), l, enemy);
      const target = lowest(allies);
      if (target) {
        targetIds.add(target.instanceId);
        m = cleanseAlly(m, target.instanceId, c => ({ ...c, statuses: { ...cleanseStatuses(c.statuses), protected: true },
          burnSource: undefined, lastEffectNote: 'Regular Guy: cleansed and protected.' }));
        m = { ...m, timedEffects: [...m.timedEffects.filter(e => e.id !== `regular-guy:${source.instanceId}:${target.instanceId}`), {
          id: `regular-guy:${source.instanceId}:${target.instanceId}`, kind: 'church-protection', sourceInstanceId: source.instanceId,
          targetInstanceId: target.instanceId, owner: source.owner, lane: l, startsAtRound: m.round,
          expiresAtRound: 7, expiration: 'match-complete',
        }] };
        succeeded = JSON.stringify(target.statuses) !== JSON.stringify(findCard(m, target.instanceId)!.statuses);
      }
      if (losing) buff(source, 3);
    }
    note(succeeded ? resolutionNote ?? `${source.ability} resolved.` : `${source.ability}: condition not met, effect blocked, or already at cap.`);
    if (!echoed && succeeded) m = trainWaveAbility(m, source.instanceId);
    return !echoed ? { ...m, lastRevealedCardId: source.cardId } : m;
  }
  if (Object.hasOwn(neighborhoodWaveCards, source.cardId)) {
    const allies = inLane(m, source.owner, l).filter(c => c.instanceId !== source.instanceId);
    let succeeded = false;
    let resolutionNote: string | undefined;
    if (source.cardId === 'hair-stylist' || source.cardId === 'stylist') {
      const target = lowest(allies);
      if (target) {
        targetIds.add(target.instanceId);
        if (source.cardId === 'hair-stylist') {
          m = cleanseAlly(m, target.instanceId, c => ({ ...c, statuses: cleanseStatuses(c.statuses), burnSource: undefined,
            powerModifier: c.powerModifier + 1, lastEffectNote: 'Blowout: cleansed, +1 Hand.' }));
        } else {
          m = modify(m, target.instanceId, c => ({ ...c, statuses: { ...c.statuses, protected: true },
            powerModifier: c.powerModifier + 2, lastEffectNote: 'Fresh Fit: +2 Hands and Protect.' }));
          m = { ...m, timedEffects: [...m.timedEffects, {
            id: `fresh-fit:${source.instanceId}:${target.instanceId}`, kind: 'church-protection', sourceInstanceId: source.instanceId,
            targetInstanceId: target.instanceId, owner: source.owner, lane: l, startsAtRound: m.round,
            expiresAtRound: 7, expiration: 'match-complete',
          }] };
        }
        succeeded = true;
      }
    } else if (source.cardId === 'demario') {
      for (let draw = 0; draw < 1; draw++) {
        const result = plantDemarioMushroom(m, source, draw, false);
        m = result.match;
        if (result.token) { targetIds.add(result.token.instanceId); succeeded = true; }
      }
      resolutionNote = `Special Delivery: ${targetIds.size} Mushrooms summoned in random open districts.`;
    } else if (source.cardId === 'luigion') {
      const powered = source.id === LUIGION_POWERED.id || source.name === LUIGION_POWERED.name;
      const mushroom = !echoed && !source.luigionMushroomUsed
        ? lowest(allies.filter(c => c.cardId === 'demario-mushroom')) : undefined;
      if (mushroom) {
        targetIds.add(mushroom.instanceId);
        m = { ...m, boards: m.boards.map(items => items.filter(c => c.instanceId !== mushroom.instanceId)) as Match['boards'],
          timedEffects: m.timedEffects.filter(e => e.targetInstanceId !== mushroom.instanceId) };
        m = fairytaleDeparture(m, mushroom);
        m = modify(m, source.instanceId, c => ({ ...c, luigionMushroomUsed: true }));
      }
      const otherCharacter = lowest(allies.filter(c => !c.hazard && (c.kind ?? 'character') === 'character'
        && c.instanceId !== source.instanceId));
      // Keep the powered burst ceiling: its Mushroom replaces the solo fallback.
      const bonus = powered ? 1 + (mushroom ? 2 : otherCharacter ? 0 : 1)
        : 1 + (otherCharacter ? 0 : 1) + (mushroom ? 2 : 0);
      resolutionNote = `${source.ability}: gained +${bonus - (mushroom ? 2 : 0)} Hands.`
        + (mushroom ? ' Consumed a local friendly Mushroom for +2 Hands.' : '')
        + (otherCharacter ? ` ${otherCharacter.name} gained +1 Hand.` : '');
      m = modify(m, source.instanceId, c => ({ ...c, powerModifier: c.powerModifier + bonus,
        lastEffectNote: `Power-Up: +${bonus} Hands${mushroom ? '; consumed a local friendly Mushroom' : ''}.` }));
      if (otherCharacter) {
        targetIds.add(otherCharacter.instanceId);
        m = modify(m, otherCharacter.instanceId, c => ({ ...c, powerModifier: c.powerModifier + 1, lastEffectNote: 'Power-Up: weakest other character +1 Hand.' }));
      }
      succeeded = true;
      if (powered && !echoed) {
        const destinations = ([0, 1, 2] as Lane[]).filter(destination => destination !== l && inLane(m, source.owner, destination).length < 4)
          .sort((a, b) => getLaneScoreForMatch(m, inLane(m, source.owner, a), a, source.owner)
            - getLaneScoreForMatch(m, inLane(m, source.owner, b), b, source.owner) || a - b);
        if (destinations.length) {
          const destination = destinations[0];
          m = move(m, findCard(m, source.instanceId) ?? source, destination, 'Powered Luigion jumped to the weakest open district.');
          if (findCard(m, source.instanceId)?.lane === destination) {
            m = modify(m, source.instanceId, c => ({ ...c, powerModifier: c.powerModifier + 1, lastEffectNote: 'Powered Luigion jumped: +1 Hand.' }));
            resolutionNote += ' Jumped to the weakest open district and gained +1 Hand.';
          } else {
            resolutionNote += ' Jump was blocked; no jump bonus.';
          }
        } else {
          resolutionNote += ' No other open district; no jump bonus.';
        }
      }
    } else if (source.cardId === 'black-cowboy' && inLane(m, enemy, l).length < 4) {
      const target = lowest(m.boards.flat().filter(c => !c.hazard && c.owner === enemy && c.lane !== l));
      if (target) {
        targetIds.add(target.instanceId);
        m = forceEnemyMove(m, source, target, l);
        succeeded = findCard(m, target.instanceId)?.lane === l;
      }
    }
    note(succeeded ? resolutionNote ?? `${source.ability} resolved.` : `${source.ability} found no legal target or space.`);
    if (succeeded) m = trainWaveAbility(m, source.instanceId);
    return !echoed ? { ...m, lastRevealedCardId: source.cardId } : m;
  }
  if (Object.hasOwn(sideOzWaveCards, source.cardId)) {
    const result = resolveSideOzAbility(m, source, echoed);
    return !echoed
      ? { ...result, lastRevealedCardId: source.cardId,
        entranceHistory: [...(result.entranceHistory ?? []).filter(id => id !== source.instanceId), source.instanceId] }
      : result;
  }
  if (Object.hasOwn(storyCharacterWaveCards, source.cardId)) {
    let succeeded = false;
    const allies = m.boards.flat().filter(c => !c.hazard && c.owner === source.owner && c.instanceId !== source.instanceId
      && c.kind !== 'support');
    const enemiesHere = () => inLane(m, enemy, l);
    const addHands = (target: CardInstance | undefined, amount: number, text: string) => {
      // Reactions can destroy the source or recipient before its follow-up.
      // A resolved attack stays resolved; never buff a missing character.
      if (!target || !findCard(m, target.instanceId)) return;
      targetIds.add(target.instanceId);
      m = modify(m, target.instanceId, c => ({ ...c, powerModifier: c.powerModifier + amount, lastEffectNote: text }));
      succeeded = true;
    };
    if (source.cardId === 'ganger-blue') {
      const remote = allies.filter(c => c.lane !== l);
      const ally = lowest(remote.filter(c => (c.gangTag ?? GANG_BY_CARD_ID[c.cardId]) === 'blue')) ?? lowest(remote);
      if (ally) {
        const amount = (ally.gangTag ?? GANG_BY_CARD_ID[ally.cardId]) === 'blue' ? 4 : 3;
        addHands(ally, amount, `Blue Side Cover: +${amount} Hands and Protected.`);
        if (amount === 4) addHands(findCard(m, source.instanceId)!, 1, 'Blue Side Cover: backed Blue Set, +1 Hand.');
        const wasProtected = ally.statuses.protected;
        m = grantProtection(m, source, ally.instanceId);
        succeeded ||= !wasProtected && !!findCard(m, ally.instanceId)?.statuses.protected;
      } else {
        addHands(findCard(m, source.instanceId)!, 1, 'Blue Side Cover: no remote ally, +1 Hand.');
      }
    } else if (source.cardId === 'ganger-red') {
      const target = highest(enemiesHere().filter(card => !cannotLoseHands(card)));
      if (target) {
        targetIds.add(target.instanceId);
        const beforeDamage = m;
        m = targetEnemyPowerReduction(m, source, target, 2, 'Red Side Retaliation: -2 Hands.');
        const protectionConsumed = beforeDamage.timedEffects.some(effect =>
          effect.targetInstanceId === target.instanceId
          && (effect.kind === 'church-protection' || effect.kind === 'salon-protection')
          && !m.timedEffects.some(remaining => remaining.id === effect.id));
        succeeded = directDamageAmount(beforeDamage, m, target) > 0;
        if (succeeded) addHands(findCard(m, source.instanceId)!, 1, 'Red Side Retaliation: damage landed, +1 Hand.');
      }
    } else if (source.cardId === 'snitch') {
      const target = highest(enemiesHere());
      if (target) {
        targetIds.add(target.instanceId);
        const status = target.statuses.silenced ? 'weakened' : 'silenced';
        const beforeStatus = target.statuses[status];
        m = hostileEffect(m, source, target, (state, actual) => queueDisruptionReactions(
          state, modify(state, actual.instanceId, card => ({
            ...card, statuses: { ...card.statuses, [status]: true },
            lastEffectNote: `Loose Lips: ${status === 'silenced' ? 'Silenced' : 'Weakened'}.`,
          })), source, actual.instanceId,
        ), false, false, true);
        succeeded = !beforeStatus && !!findCard(m, target.instanceId)?.statuses[status];
      }
    } else if (source.cardId === 'cracked-head') {
      const targets = enemiesHere().sort((a, b) => getEffectiveCardPower(b) - getEffectiveCardPower(a)
        || a.instanceId.localeCompare(b.instanceId)).slice(0, 3);
      let damaged = 0;
      for (const target of targets) {
        targetIds.add(target.instanceId);
        const beforeDamage = m;
        m = targetEnemyPowerReduction(m, source, target, 1, 'Block Crowned: -1 Hand.');
        if (directDamageAmount(beforeDamage, m, target) > 0) damaged++;
      }
      if (damaged) {
        addHands(findCard(m, source.instanceId)!, Math.min(2, damaged), `Block Crowned: +${Math.min(2, damaged)} Hands.`);
      }
    }
    note(succeeded ? `${source.ability} resolved.` : `${source.ability} found no legal target or its effect was blocked.`);
    if (succeeded && !echoed) m = trainWaveAbility(m, source.instanceId);
    return !echoed ? { ...m, lastRevealedCardId: source.cardId,
      entranceHistory: [...(m.entranceHistory ?? []).filter(id => id !== source.instanceId), source.instanceId] } : m;
  }
  if (Object.hasOwn(fairytaleCards, source.cardId)) {
    const result = resolveFairytaleAbility(m, source, echoed);
    return !echoed && source.effect.includes('On Reveal:')
      ? { ...result, lastRevealedCardId: source.cardId, entranceHistory: [...(result.entranceHistory ?? []).filter(id => id !== source.instanceId), source.instanceId] }
      : result;
  }
  if (source.cardId === 'rastamon') {
    const allies = inLane(m, source.owner, l).filter(c => c.instanceId !== source.instanceId);
    const affected = lowest(allies.filter(c => c.statuses.frozen || c.statuses.silenced));
    if (affected) {
      targetIds.add(affected.instanceId);
      m = cleanseAlly(m, affected.instanceId, c => ({ ...c, statuses: cleanseStatuses(c.statuses),
        powerModifier: c.powerModifier + 2, lastEffectNote: 'Natural Cure: cleansed, +2 Hands.' }));
      note('Natural Cure cleansed an ally and gave it +2.');
    } else {
      const ally = lowest(allies);
      if (ally) {
        targetIds.add(ally.instanceId);
        m = modify(m, ally.instanceId, c => ({ ...c, powerModifier: c.powerModifier + 1, lastEffectNote: 'Natural Cure: fallback, +1 Hand.' }));
        note('Natural Cure gave another ally +1 Hand.');
      } else note('Natural Cure found no other ally.');
    }
  }
  else if (source.cardId === 'roaster') {
    const t = highest(inLane(m, enemy, l));
    if (t) {
      targetIds.add(t.instanceId);
      const amount = t.playedRound === m.round ? -2 : -1;
      m = targetEnemyBurnAndPowerReduction(m, source, t, 1, amount, `Ratio'd Receipts: 1 Burn, ${Math.abs(amount)} immediate Hands loss.`);
      note(`Ratio'd Receipts targeted ${t.name} (1 Burn + ${Math.abs(amount)} immediate Hands loss).`);
    } else note("Ratio'd Receipts found no enemy.");
  }
  else if (source.cardId === 'nerd') {
    const candidates = inLane(m, enemy, l);
    const t = highest(candidates.filter(isActiveOngoing)) ?? highest(candidates);
    if(t) {
      targetIds.add(t.instanceId);
      m=targetEnemy(m,source,t,c=>({...c,statuses:{...c.statuses,silenced:true},lastEffectNote:'Unaware: silenced.'}),true);
      const disabled=isActiveOngoing(t)&&findCard(m,t.instanceId)?.statuses.silenced;
      if (disabled) m = modify(m, source.instanceId, c => ({ ...c, powerModifier: c.powerModifier + 1 }));
      const revealed=disabled?[...(enemy==='player'?m.playerHand:m.cpuHand)].sort((a,b)=>a.instanceId.localeCompare(b.instanceId))[0]:undefined;
      if(revealed)targetIds.add(revealed.instanceId);
      note('Unaware prioritized an active Ongoing enemy through Side Eye.'+(revealed?' Read the source: revealed '+revealed.name+' ('+revealed.cost+' Motion).':''));
    } else note('Unaware found no enemy.');
  }
  else if (source.cardId === 'cornball') {
    let burned = 0;
    for (const t of inLane(m, enemy, l)) {
      targetIds.add(t.instanceId);
      m = applyBurn(m, source, t, 1, 'Scare the Hoes: 1 Burn.');
      burned++;
    }
    note(burned ? `Scare the Hoes applied 1 Burn to ${burned} enemies.` : 'Scare the Hoes found no enemies.');
  }
  else if (source.cardId === 'plug') { m = addDiscountToken(m, source.owner, source, 'another-district'); m = { ...m, plugDiscountLane: { ...m.plugDiscountLane, [source.owner]: l } }; note('Connections: next card in another district costs 1 less Motion.'); }
  else if (source.cardId === 'sneaker') {
    // Steal: copy the highest-Hands enemy's printed Power onto Sneaker (capped at +3) and apply Weaken.
    const target = highest(m.boards.flat().filter(c => !c.hazard && c.owner === enemy && c.kind !== 'support'));
    if (target) {
      targetIds.add(target.instanceId);
      const bonus = Math.min(3, target.basePower);
      m = modify(m, source.instanceId, c => ({ ...c, powerModifier: c.powerModifier + bonus, lastEffectNote: `Flip Season: +${bonus} Hands (stolen from ${target.name}).` }));
      m = applyWeaken(m, source, target, 'Flip Season: Weakened.');
      note(`Flip Season stole ${bonus} Hands from ${target.name}.`);
    } else note('Flip Season found no enemy.');
  }
  else if (source.cardId === 'bossbabe') note('Network Boost watches the first two plays in other districts.');
  else if (source.cardId === 'scammer') {
    const candidates = inLane(m, enemy, l);
    const ongoing = highest(candidates.filter(isActiveOngoing));
    const target = ongoing ?? highest(candidates);
    if (target) {
      targetIds.add(target.instanceId);
      const copiedId = abilityCardId(target);
      const printed = cards[copiedId] ?? target;
      m = modify(m, source.instanceId, card => ({ ...card,
        basePower: Math.min(7, target.basePower),
        powerModifier: card.powerModifier + (ongoing ? 0 : 1),
        copiedAbilityCardId: ongoing ? copiedId : undefined,
        ability: ongoing ? printed.ability : source.ability,
        effect: ongoing ? printed.effect : source.effect,
        lastEffectNote: ongoing ? `Imposter copied ${target.name}'s base Hands and ongoing kit; no entrance fired.`
          : `Imposter copied ${target.name}'s base Hands and gained +1 Hand; no ability copied.`,
      }));
      note(findCard(m, source.instanceId)!.lastEffectNote);
    } else note('Imposter found no enemy to copy.');
  }
  else if (source.cardId === 'streamer') {
    // Reset the owner's cheap-play trigger counter to 0; the existing reactive logic in resolveCardPlay
    // arms up to 2 fresh Follower Frenzy triggers. This converts Streamer from "while-on-board" reactive
    // to "On Reveal trigger reset" without changing the reactive buff behavior.
    m = { ...m, cheapBuffsUsed: { ...m.cheapBuffsUsed, [source.owner]: 0 } };
    note('Follower Frenzy armed — the next 2 cheap plays gain +1 Hand.');
  }
  else if (source.cardId === 'gamer') {
    // City Tour: visit the other two districts and buff each lane's lowest-Hands friendly card.
    let buffed = 0;
    for (const targetLane of [0, 1, 2] as Lane[]) {
      if (targetLane === l) continue;
      const target = lowest(inLane(m, source.owner, targetLane));
      if (target) {
        targetIds.add(target.instanceId);
        m = modify(m, target.instanceId, c => ({ ...c, powerModifier: c.powerModifier + 2, lastEffectNote: 'City Tour: +2 Hands.' }));
        buffed++;
      }
    }
    note(buffed ? `City Tour visited ${buffed} other districts.` : 'City Tour found no allies.');
  }
  else if (source.cardId === 'stockz') { note('Compound Interest is watching your next character plays.'); }
  else if (source.cardId === 'techbro') { const supported = inLane(m, source.owner, l).some(c => c.instanceId !== source.instanceId); if (supported) { m = modify(m, source.instanceId, (c) => ({ ...c, powerModifier: c.powerModifier + 2, lastEffectNote: 'VC Funded Flex: +2 Hands.' })); note('VC Funded Flex gained +2 Hands with an ally here.'); } else note('VC Funded Flex needs another friendly card here.'); }
  else if (source.cardId === 'bikelife') { const to = lowestFriendlyLane(m, source.owner, l); m = move(m, source, to, 'Ride Out moved here, +1 Hands.'); const arrived = findCard(m, source.instanceId); if (arrived?.lane === to && activeAbility(arrived)) { m = modify(m, source.instanceId, (c) => ({ ...c, powerModifier: c.powerModifier + 1, lastEffectNote: 'Ride Out moved here, +1 Hands.' })); note('Ride Out moved Bikelife and gave +1.'); } else note('Ride Out was interrupted before its bonus.'); }
  else if (source.cardId === 'vibe') { const t = lowest(m.boards.flat().filter((c) => !c.hazard && c.owner === source.owner && c.instanceId !== source.instanceId && c.lane !== l)); if (t) { targetIds.add(t.instanceId); m = move(m, t, l, 'Wave Check pulled this card here, +1 Hands.'); if (findCard(m, t.instanceId)?.lane === l) { m = modify(m, t.instanceId, (c) => ({ ...c, powerModifier: c.powerModifier + 1, lastEffectNote: 'Wave Check pulled this card here, +1 Hands.' })); m = modify(m, source.instanceId, (c) => ({ ...c, powerModifier: c.powerModifier + 1, lastEffectNote: 'Wave Check: +1 Hands.' })); } note('Wave Check pulled the lowest ally here; both gained +1.'); } else note('Wave Check needs an ally in another district.'); }
  else if (source.cardId === 'hooper') { if (getLaneScoreForMatch(m, inLane(m, source.owner, l), l, source.owner) < getLaneScoreForMatch(m, inLane(m, enemy, l), l, enemy)) { const t = highest(inLane(m, enemy, l)); if (t) { targetIds.add(t.instanceId); m = targetEnemyPowerReduction(m, source, t, -2, 'Ankle Breaker: -2 Hands.'); } m = modify(m, source.instanceId, (c) => ({ ...c, powerModifier: c.powerModifier + 2, lastEffectNote: 'Ankle Breaker: +2 Hands.' })); note('Ankle Breaker flipped the pressure.'); } else note('Ankle Breaker only triggers while losing.'); }
  else if (source.cardId === 'baby') { if (inLane(m, enemy, l).length > inLane(m, source.owner, l).length) { m = modify(m, source.instanceId, (c) => ({ ...c, powerModifier: c.powerModifier + 2, lastEffectNote: 'Mama Bear: +2 Hands.' })); note('Mama Bear gained +2.'); } else note('Mama Bear found no crowd disadvantage.'); }
  else if (source.cardId === 'guap') {
    if (m.guapRounds?.[source.owner] === m.round) {
      m = modify(m, source.instanceId, c => ({ ...c, lastEffectNote: 'FINNAM!: already used this round.' }));
      note('FINNAM! already resolved this round.');
    } else {
      const allies = m.boards.flat().filter(c => !c.hazard && c.owner === source.owner
        && c.instanceId !== source.instanceId && (c.kind ?? 'character') === 'character');
      const bonus = Math.min(5, allies.length);
      m = { ...m, guapRounds: { ...m.guapRounds, [source.owner]: m.round } };
      m = modify(m, source.instanceId, c => ({ ...c, guapRound: m.round, powerModifier: c.powerModifier + bonus, lastEffectNote: `FINNAM!: +${bonus} Hands across the board.` }));
      for (const target of m.boards.flat().filter(c => !c.hazard && c.owner === enemy)) {
        targetIds.add(target.instanceId);
        m = targetEnemyPowerReduction(m, source, target, -1, 'FINNAM!: -1 Hands across the board.');
      }
      note(`FINNAM! GUAP erupted across the board (+${bonus}, -1 AOE).`);
    }
  }
  else if (source.cardId === 'oink') {
    let weakenedCount = 0;
    for (const t of inLane(m, enemy, l)) {
      targetIds.add(t.instanceId);
      m = applyWeaken(m, source, t, 'Civic Pressure: Weakened.');
      if (findCard(m, t.instanceId)?.statuses.weakened) weakenedCount++;
    }
    if (weakenedCount > 0) m = modify(m, source.instanceId, c => ({ ...c, powerModifier: c.powerModifier + weakenedCount, lastEffectNote: `Civic Pressure: +${weakenedCount} Hands.` }));
    note(`Civic Pressure weakened ${weakenedCount} enemies.`);
  }
  else if (source.cardId === 'snow') { const t = highest(inLane(m, enemy, l)); if (t) { targetIds.add(t.instanceId); m = targetEnemy(m, source, t, (c) => ({ ...c, statuses: { ...c.statuses, frozen: true }, lastEffectNote: 'Cold Shoulder: frozen.' })); note('Cold Shoulder froze the highest enemy.'); } else note('Cold Shoulder found no enemy.'); }
  else if (source.cardId === 'buddy') {
    if (echoed) {
      note('Buddy Buds and Earth Squabble do not repeat through echoes.');
    } else if (source.buddyForm === 'squabble-earth') {
      m = applyBuddyEarthToBoard(m, source);
      note('Earth Squabble: enemies lose 1 Hand and friendly Earth cards gain 2 Hands for two rounds.',
        'timed', { unit: 'round', startsAtRound: m.round, expiresAtRound: source.buddyEarthExpiresAtRound ?? m.round + 2, expiration: 'round-start' });
    } else {
      m = plantBuddyBuds(m, source);
      note(findCard(m, source.instanceId)?.lastEffectNote ?? 'Buddy Buds could not find an eligible district.');
    }
  }
  else if (source.cardId === 'folks') {
    for (const target of m.boards.flat().filter(c => !c.hazard && c.owner === enemy)) {
      targetIds.add(target.instanceId);
      m = applyBurn(m, source, target, 3, 'Whole Block Hot: 3 Burn.');
    }
    for (const ally of m.boards.flat().filter(c => !c.hazard && c.owner === source.owner && c.instanceId !== source.instanceId && c.kind !== 'support' && c.type === 'Fire')) {
      targetIds.add(ally.instanceId);
      m = modify(m, ally.instanceId, c => ({ ...c, powerModifier: c.powerModifier + 1, lastEffectNote: 'Whole Block Hot: Fire ally +1 Hand.' }));
    }
    note(targetIds.size ? 'Whole Block Hot: 3 Burn across the enemy board; other Fire allies +1 Hand.' : 'Whole Block Hot needs an enemy or another Fire ally.');
  }
  else if (source.cardId === 'drfade') {
    const hostile = highest(inLane(m, enemy, l));
    const friendly = lowest(m.boards.flat().filter(c => !c.hazard && c.owner === source.owner && c.lane !== l));
    if (hostile) {
      targetIds.add(hostile.instanceId);
      m = targetEnemyPowerReduction(m, source, hostile, -2, 'The First Lesson: -2 Hands.');
    }
    if (friendly) {
      targetIds.add(friendly.instanceId);
      m = modify(m, friendly.instanceId, c => ({ ...c, powerModifier: c.powerModifier + 2, lastEffectNote: 'Corner advice: +2 Hands.' }));
    }
    note(hostile || friendly ? 'The First Lesson: throw hands here, coach an ally across the block.' : 'Dr. Fade is holding this district. His lesson needs another fighter.');
  }
  else if (source.cardId === 'barber') {
    const friendly = lowest(inLane(m, source.owner, l).filter((c) => c.instanceId !== source.instanceId));
    const hostile = highest(inLane(m, enemy, l));
    if (friendly) { targetIds.add(friendly.instanceId); m = modify(m, friendly.instanceId, (c) => ({ ...c, powerModifier: c.powerModifier + 2, lastEffectNote: "Line Up: +2 Hands." })); }
    if (hostile) { targetIds.add(hostile.instanceId); m = targetEnemyPowerReduction(m, source, hostile, -1, "Line Up: -1 Hands."); }
    note(friendly || hostile ? "Line Up sharpened the district." : "Line Up found no other cards.");
  }
  else if (source.cardId === 'bottle') {
    if (m.round >= 4) m = modify(m, source.instanceId, (c) => ({ ...c, powerModifier: c.powerModifier + 2, lastEffectNote: "Last Call: +2 Hands." }));
    m = addDiscountToken(m, source.owner, source, "poison-character");
    const tokenOrder = m.nextDiscountOrder - 1;
    m = { ...m, discountTokens: m.discountTokens.map(token => token.createdOrder === tokenOrder ? { ...token, expiresAfterRound: m.round + 1 } : token) };
    note(`${m.round >= 4 ? "Last Call gave +2 Hands. " : ""}Last Call set aside a Poison-character discount through next round.`);
  }
  else if (source.cardId === 'church') {
    const target = lowest(inLane(m, source.owner, l).filter((c) => c.instanceId !== source.instanceId));
    if (!target) note("Covered needs another friendly card.");
    else if (target.statuses.protected) { const amount = target.type === 'Light' ? 3 : 2; targetIds.add(target.instanceId); m = modify(m, target.instanceId, (c) => ({ ...c, powerModifier: c.powerModifier + amount, lastEffectNote: `Covered: already protected, +${amount} Hands.` })); note("Covered reinforced an already protected ally."); }
    else {
      const amount = target.type === 'Light' ? 3 : 2;
      targetIds.add(target.instanceId);
      m = modify(m, target.instanceId, (c) => ({ ...c, powerModifier: c.powerModifier + amount, statuses: { ...c.statuses, protected: true }, lastEffectNote: `Covered: +${amount} Hands and protected from one targeted hostile ability.` }));
      m = { ...m, timedEffects: [...m.timedEffects, { id: `church:${source.instanceId}:${target.instanceId}`, kind: "church-protection", sourceInstanceId: source.instanceId, targetInstanceId: target.instanceId, owner: source.owner, lane: l, startsAtRound: m.round, expiresAtRound: 7, expiration: "match-complete" }] };
      note(`Covered gave the lowest-Hands friendly card +${amount} Hands and protection.`);
    }
  }
  else if (source.cardId === 'carmeet') {
    const destination = lowestFriendlyLane(m, source.owner, l);
    m = move(m, source, destination, "Sideshow moved to the weakest other district.");
    const target = findCard(m, source.instanceId)?.lane === destination ? lowest(inLane(m, source.owner, destination).filter((c) => c.instanceId !== source.instanceId)) : undefined;
    if (target) { targetIds.add(target.instanceId); m = modify(m, target.instanceId, (c) => ({ ...c, powerModifier: c.powerModifier + 1, lastEffectNote: "Sideshow: +1 Hands." })); }
    note(target ? "Sideshow moved and gave an ally +1 Hands." : "Sideshow moved to the weakest other district.");
  }
  else if (source.cardId === 'promoter') {
    const revealed = [...(enemy === "player" ? m.playerHand : m.cpuHand)].sort((a, b) => a.instanceId.localeCompare(b.instanceId))[0];
    if (!revealed) note("Guest List found no opponent hand card.");
    else { targetIds.add(revealed.instanceId); if (revealed.cost >= 4) m = addDiscountToken(m, source.owner, source, "another-district"); note(`Guest List revealed ${revealed.name} (${revealed.cost} Motion)${revealed.cost >= 4 ? " and set aside an another-district discount." : "."}`); }
  }
  else if (source.cardId === 'nail') {
    const target = lowest(inLane(m, source.owner, l).filter((c) => c.instanceId !== source.instanceId));
    if (!target) note("Fresh Set needs another friendly card.");
    else { targetIds.add(target.instanceId); m = modify(m, target.instanceId, (c) => ({ ...c, powerModifier: c.powerModifier + 2, lastEffectNote: "Fresh Set: +2 Hands." })); m = { ...m, timedEffects: [...m.timedEffects.filter((effect) => effect.kind !== "nail-mitigation" || effect.targetInstanceId !== target.instanceId), { id: `nail:${source.instanceId}:${target.instanceId}`, kind: "nail-mitigation", sourceInstanceId: source.instanceId, targetInstanceId: target.instanceId, owner: source.owner, lane: l, startsAtRound: m.round, expiresAtRound: 7, expiration: "match-complete" }] }; note("Fresh Set gave +2 Hands and reinforced the next hostile reduction."); }
  }
  else if (source.cardId === 'og') {
    const ownCount = m.boards.flat().filter((c) => !c.hazard && c.owner === source.owner).length, enemyCount = m.boards.flat().filter((c) => !c.hazard && c.owner === enemy).length;
    if (enemyCount > ownCount) m = modify(m, source.instanceId, (c) => ({ ...c, powerModifier: c.powerModifier + 3, lastEffectNote: "Back In My Day: +3 Hands." }));
    if (enemyCount >= ownCount + 3) { const target = lowest(inLane(m, enemy, l)); if (target) { targetIds.add(target.instanceId); m = targetEnemyPowerReduction(m, source, target, -1, "Back In My Day: -1 Hands."); } }
    note(enemyCount > ownCount ? "Back In My Day punished the board advantage." : "Back In My Day found no larger opposing board.");
  }
  else if (source.cardId === 'delivery') {
    const target = lowest(inLane(m, source.owner, l).filter((c) => c.instanceId !== source.instanceId && c.cost <= 2));
    if (!target) note("Drop Off needs another friendly 1- or 2-Cost card here.");
    else { targetIds.add(target.instanceId); const destination = lowestFriendlyLane(m, source.owner, l); m = move(m, target, destination, "Drop Off moved this card to the weakest other district."); note("Drop Off moved the lowest-Hands eligible ally."); }
  }
  else if (source.cardId === 'shiesty') {
    const maxExtraCopies = 8;
    let summoned = 0;
    for (let roll = 0; roll < maxExtraCopies; roll++) {
      const seed = JSON.stringify(['shiesty-chain', source.instanceId, before.round, before.nextEventSequence, l, roll, before.districtSnapshot]);
      if (seededIndex(seed, 2) !== 0) break;
      m = summonCard(m, source.owner, l, cards.shiesty, 'shiesty', source);
      const copy = m.boards[l].at(-1)!;
      targetIds.add(copy.instanceId);
      summoned++;
    }
    const capped = summoned === maxExtraCopies;
    note(summoned
      ? `Mean Mug's 50% chain summoned ${summoned} extra Shiesty YN${summoned === 1 ? '' : 's'}.${capped ? ' Chain capped at 8 extras.' : ''}`
      : "Mean Mug's 50% summon chance missed.");
  }
  else if (['youngbull', 'transplant', 'edgar', 'nguyen', 'manman'].includes(source.cardId)) {
    const allies = inLane(m, source.owner, l).filter(c => c.instanceId !== source.instanceId);
    const enemiesHere = inLane(m, enemy, l);
    const succeeds = source.cardId === 'youngbull' ? true
      : source.cardId === 'shiesty' ? m.boards.flat().length > before.boards.flat().length
      : source.cardId === 'torta' ? allies.length > 0
      : source.cardId === 'transplant' ? allies.length === 0
      : source.cardId === 'edgar' ? allies.some(c => c.kind !== 'support' && c.cost <= 2)
      : source.cardId === 'nguyen' ? m.boards.flat().some(c => !c.hazard && c.owner === source.owner && c.lane !== l)
      : allies.filter(c => c.kind !== 'support').length >= 2;
    const amount = source.cardId === 'manman' ? 3 : source.cardId === 'edgar' ? 2 : 1;
    if (succeeds) {
      m = modify(m, source.instanceId, c => ({ ...c, powerModifier: c.powerModifier + amount, lastEffectNote: `${source.ability}: +${amount} Hands.` }));
      if (source.cardId === 'youngbull') {
        const burnTarget = highest(enemiesHere);
        if (burnTarget) { targetIds.add(burnTarget.instanceId); m = applyBurn(m, source, burnTarget, 1, 'Step Up: 1 Burn.'); }
      }
    }
    note(succeeds ? `${source.ability}: +${amount} Hands${source.cardId === 'youngbull' && enemiesHere.length ? ' + 1 Burn' : ''}.` : `${source.ability}: condition not met.`);
  }
  else if (source.cardId === 'tayaty') {
    // Act Up always grants +1, then resolves the previous On Reveal with Tayaty as its source.
    m = modify(m, source.instanceId, c => ({ ...c, powerModifier: c.powerModifier + 1, lastEffectNote: 'Act Up: +1 Hand.' }));
    const echoCardId = match.lastRevealedCardId;
    const echoedCard = echoCardId && !['tayaty', 'oz'].includes(echoCardId) ? cards[echoCardId] : null;
    if (echoCardId && echoedCard && canEchoCreativeEntrance(echoCardId)) {
      const current = findCard(m, source.instanceId)!;
      const echoSource: CardInstance = { ...current, cardId: echoCardId, ability: echoedCard.ability, effect: echoedCard.effect };
      m = resolveAbility(m, echoSource, { echoed: true });
      note(`Act Up echoed ${echoedCard.name}'s ${echoedCard.ability}.`);
    } else {
      m = grantProtection(m, source, source.instanceId);
      note('Act Up: no repeatable entrance; gained +1 Hand and a Stand-In shield.');
    }
  }
  else if (source.cardId === 'waterboy') {
    const supported = inLane(m, source.owner, l).some(c => c.instanceId !== source.instanceId);
    if (supported) {
      const motionKey = source.owner === 'player' ? 'playerMotion' : 'cpuMotion';
      m = refundMotion(m, source.owner, 1);
    }
    note(supported ? 'Cold Water restored 1 Motion.' : 'Cold Water needs another friendly card here.');
  }
  else if (source.cardId === 'buspass') {
    m = addDiscountToken(m, source.owner, source, 'character-transfer');
    m = {...m,discountTokens:m.discountTokens.map(t=>t.sourceInstanceId===source.instanceId && t.eligibility==='character-transfer'?{...t,bonusHandsOnUse:PVP_SUPPORT.transfer}:t)};
    note(`Transfer Ticket: next character costs 1 less Motion and arrives with +${PVP_SUPPORT.transfer} Hands.`);
  }
  else if (source.cardId === 'sideofhands') {
    const ally = lowest(inLane(m, source.owner, l).filter(card => card.instanceId !== source.instanceId
      && (card.kind ?? 'character') === 'character'));
    const target = highest(inLane(m, enemy, l).filter(card => (card.kind ?? 'character') === 'character'));
    if (ally) {
      targetIds.add(ally.instanceId);
      m = modify(m, ally.instanceId, card => ({ ...card, powerModifier: card.powerModifier + 2,
        lastEffectNote: 'A Side of Hands: +2 Hands.' }));
    }
    let hostileLanded = false;
    if (target) {
      targetIds.add(target.instanceId);
      const beforeDamage = m;
      m = hostileEffect(m, source, target, (state, actual) =>
        reduceHands(state, actual, 2, 'Side Order: -2 Hands.'), false, false, true);
      hostileLanded = directDamageAmount(beforeDamage, m, target) > 0;
    }
    note(`A Side of Hands: ${ally ? `${ally.name} gained +2 Hands.` : 'no friendly character was here.'} `
      + (hostileLanded ? `${target!.name} lost 2 Hands.` : target ? 'the hostile reduction was blocked.' : 'no enemy character was here.'));
  }
  else if (source.cardId === 'energydrink' || source.cardId === 'charger') {
    const eligible = inLane(m, source.owner, l).filter(c => c.instanceId !== source.instanceId && c.kind !== 'support').length;
    const key = source.owner === 'player' ? 'playerMotion' : 'cpuMotion';
    const gain = source.cardId === 'energydrink'
      ? Math.min(MAX_MOTION - m[key], 3)
      : Math.min(MAX_MOTION - m[key], Math.min(3, eligible));
    m = refundMotion(m, source.owner, gain);
    if (source.cardId === 'charger' && eligible >= 3) {
      const electric = lowest(inLane(m, source.owner, l).filter(c => (c.kind ?? 'character') === 'character' && c.type === 'Electric'));
      if (electric) { targetIds.add(electric.instanceId); m = grantProtection(m, source, electric.instanceId); }
    }
    note(source.cardId === 'energydrink'
      ? `Second Wind restored ${gain} Motion (maximum ${MAX_MOTION}).`
      : `Refund restored ${gain} Motion (${eligible} friendly characters here).`);
  }
  else if (source.cardId === 'firstaid' || source.cardId === 'boombox') {
    const targets = inLane(m, source.owner, l).filter(c => c.kind !== 'support' && (source.cardId === 'boombox' || c.statuses.frozen || c.statuses.silenced));
    for (const target of targets) {
      targetIds.add(target.instanceId);
      m = cleanseAlly(m, target.instanceId, c => source.cardId === 'firstaid'
        ? { ...c, statuses: cleanseStatuses(c.statuses), lastEffectNote: 'Patch Up: cleansed.' }
        : { ...c, powerModifier: c.powerModifier + 1, lastEffectNote: 'Turn It Up: +1 Hands.' });
    }
    note(targets.length ? `${source.ability} helped ${targets.length} friendly characters.` : `${source.ability} found no eligible friendly characters.`);
  }
  else if (source.cardId === 'subwaymap' || source.cardId === 'workboots') {
    const target = lowest(inLane(m, source.owner, l).filter(c => c.kind !== 'support'));
    if (!target) note(`${source.ability} needs a friendly character here.`);
    else {
      targetIds.add(target.instanceId);
      const destination = lowestFriendlyLane(m, source.owner, l);
      if (source.cardId === 'subwaymap') m = move(m, target, destination, 'Alternate Route moved this character.');
      const succeeded = source.cardId === 'workboots' || findCard(m, target.instanceId)?.lane === destination;
      const amount = source.cardId === 'workboots' ? 2 : 1;
      if (succeeded) m = modify(m, target.instanceId, c => ({ ...c, powerModifier: c.powerModifier + amount, lastEffectNote: `${source.ability}: +${amount} Hands.` }));
      if (source.cardId === 'workboots' && !target.statuses.protected) {
        m = modify(m, target.instanceId, c => ({ ...c, statuses: { ...c.statuses, protected: true } }));
        m = { ...m, timedEffects: [...m.timedEffects, { id: `workboots:${source.instanceId}:${target.instanceId}`, kind: 'church-protection', sourceInstanceId: source.instanceId, targetInstanceId: target.instanceId, owner: source.owner, lane: l, startsAtRound: m.round, expiresAtRound: 7, expiration: 'match-complete' }] };
      }
      note(succeeded ? `${source.ability}: ${target.name} gained +${amount} Hands${source.cardId === 'workboots' ? ' and protection' : ' after moving'}.` : 'Alternate Route could not move its target.');
    }
  }
  else if (source.cardId === 'bustdown') {
    const target = lowest(inLane(m, source.owner, l).filter(c => c.kind !== 'support' && c.instanceId !== source.instanceId));
    if (target && !target.statuses.protected) {
      targetIds.add(target.instanceId);
      m = modify(m, target.instanceId, c => ({ ...c, statuses: { ...c.statuses, protected: true }, lastEffectNote: 'Wrist Check: protected from one targeted hostile ability.' }));
      m = { ...m, timedEffects: [...m.timedEffects, { id: `bustdown:${source.instanceId}:${target.instanceId}`, kind: 'church-protection', sourceInstanceId: source.instanceId, targetInstanceId: target.instanceId, owner: source.owner, lane: l, startsAtRound: m.round, expiresAtRound: 7, expiration: 'match-complete' }] };
    }
    note(!target ? 'Wrist Check needs another friendly card here.' : target.statuses.protected ? 'Wrist Check: ally is already protected.' : `Wrist Check protected ${target.name}.`);
  }
  else if (source.cardId === 'pinaynurse' || source.cardId === 'soulfood') {
    const allies = inLane(m, source.owner, l).filter(c => c.instanceId !== source.instanceId && (source.cardId !== 'soulfood' || c.kind !== 'support'));
    // Frozen allies drop to 0 Hands and can tie with other weak allies; a cleanse must reach the one that needs it.
    const target = lowest(allies.filter(needsCleanse)) ?? lowest(allies);
    const amount = source.cardId === 'pinaynurse' ? 3 : PVP_SUPPORT.soulFood;
    if (target) {
      targetIds.add(target.instanceId);
      m = cleanseAlly(m, target.instanceId, c => ({ ...c, statuses: cleanseStatuses(c.statuses), powerModifier: c.powerModifier + amount, lastEffectNote: `${source.ability}: cleansed, +${amount} Hands.` }));
    }
    note(target ? `${source.ability} cleansed an ally and gave +${amount} Hands.` : `${source.ability} needs another friendly card here.`);
  }
  else if (['earthy', 'cognac'].includes(source.cardId)) {
    const allies = inLane(m, source.owner, l).filter(c => c.instanceId !== source.instanceId && (source.cardId !== 'cognac' || c.kind !== 'support'));
    const target = lowest(allies);
    const targets = target ? [target] : [];
    const amount = source.cardId === 'cognac' ? (target?.type === 'Fire' ? PVP_SUPPORT.fireCognac : PVP_SUPPORT.cognac) : 1;
    for (const ally of targets) {
      targetIds.add(ally.instanceId);
      m = modify(m, ally.instanceId, c => ({ ...c, powerModifier: c.powerModifier + amount, lastEffectNote: `${source.ability}: +${amount} Hands.` }));
    }
    note(targets.length ? `${source.ability} gave ${targets.length} allies +${amount} Hands.` : `${source.ability} needs another friendly card.`);
  }
  else if (source.cardId === 'mural') {
    const diverse = inLane(m, source.owner, l).some(c => c.instanceId !== source.instanceId && canonicalElement(c.type) !== canonicalElement(source.type));
    const target = highest(inLane(m, enemy, l));
    if (diverse && target) {
      targetIds.add(target.instanceId);
      m = applyLock(m, source, target, 'Fresh Color: Locked.');
    } else {
      m = modify(m, source.instanceId, c => ({ ...c, powerModifier: c.powerModifier + 1, lastEffectNote: 'Fresh Color: +1 Hands.' }));
    }
    note(!diverse ? 'Fresh Color needs another friendly type.' : target ? 'Fresh Color Locked the highest enemy.' : 'Fresh Color gained +1 Hands with no enemy here.');
  }
  else if (['bodegacat', 'dogwalker', 'dancecaptain', 'midnightmayor'].includes(source.cardId)) {
    const allies = inLane(m, source.owner, l).filter(c => c.instanceId !== source.instanceId);
    const succeeds = source.cardId === 'bodegacat' ? allies.length === 0
      : source.cardId === 'dogwalker' ? allies.filter(c => c.kind !== 'support').length >= 2
      : source.cardId === 'dancecaptain' ? m.boards.every(board => board.some(c => c.owner === source.owner)) : true;
    const amount = source.cardId === 'dogwalker' ? 3 : source.cardId === 'dancecaptain' ? 3
      : source.cardId === 'midnightmayor' ? Math.min(3, new Set(inLane(m, source.owner, l).map(c => canonicalElement(c.type))).size) : 1;
    if (succeeds) m = modify(m, source.instanceId, c => ({ ...c, powerModifier: c.powerModifier + amount, lastEffectNote: `${source.ability}: +${amount} Hands.` }));
    note(succeeds ? `${source.ability}: +${amount} Hands.` : `${source.ability}: condition not met.`);
  }
  else if (source.cardId === 'crossingguard') {
    const target = lowest(inLane(m, source.owner, l).filter(c => c.instanceId !== source.instanceId));
    if (target && !target.statuses.protected) {
      targetIds.add(target.instanceId);
      m = modify(m, target.instanceId, c => ({ ...c, statuses: { ...c.statuses, protected: true }, lastEffectNote: 'Safe Crossing: protected from one targeted hostile ability.' }));
      m = { ...m, timedEffects: [...m.timedEffects, { id: `crossingguard:${source.instanceId}:${target.instanceId}`, kind: 'church-protection', sourceInstanceId: source.instanceId, targetInstanceId: target.instanceId, owner: source.owner, lane: l, startsAtRound: m.round, expiresAtRound: 7, expiration: 'match-complete' }] };
    }
    note(!target ? 'Safe Crossing needs another ally here.' : target.statuses.protected ? 'Safe Crossing: ally is already protected.' : `Safe Crossing protected ${target.name}.`);
  }
  else if (source.cardId === 'laundry' || source.cardId === 'nightmedic') {
    const medicTarget = source.cardId === 'nightmedic'
      ? lowest(inLane(m, source.owner, l).filter(c => c.instanceId !== source.instanceId
        && (c.kind ?? 'character') === 'character' && c.type === 'Light'))
      : undefined;
    const eligible = inLane(m, source.owner, l).filter(c => c.instanceId !== source.instanceId
      && (source.cardId === 'nightmedic' ? needsCleanse(c) : c.statuses.frozen || c.statuses.silenced));
    const target = lowest(eligible);
    const targets = source.cardId === 'nightmedic' ? eligible : target ? [target] : [];
    for (const ally of targets) {
      targetIds.add(ally.instanceId);
      m = cleanseAlly(m, ally.instanceId, c => ({ ...c, statuses: cleanseStatuses(c.statuses), powerModifier: c.powerModifier + (source.cardId === 'laundry' ? 1 : 0), lastEffectNote: `${source.ability}: cleansed.` }));
    }
    if (medicTarget) {
      targetIds.add(medicTarget.instanceId);
      m = modify(m, medicTarget.instanceId, c => ({ ...c, powerModifier: c.powerModifier + 1, lastEffectNote: 'All Clear: +1 Hand to the weakest other local Light character.' }));
    }
    note(`${targets.length ? `${source.ability} cleansed ${targets.length} allies.` : `${source.ability} found no status to cleanse.`}${medicTarget ? ' The weakest local Light character gained +1 Hand.' : ''}`);
  }
  else if (['busker', 'cornercoach', 'piratedj', 'partytitan'].includes(source.cardId)) {
    const allies = inLane(m, source.owner, l).filter(c => c.instanceId !== source.instanceId);
    const target = lowest(allies);
    const targets = source.cardId === 'busker' ? allies.filter(c => c.cost === 1)
      : source.cardId === 'cornercoach' ? target ? [target] : []
      : ([0, 1, 2] as Lane[]).filter(targetLane => source.cardId === 'partytitan' || targetLane !== l)
        .map(targetLane => lowest(inLane(m, source.owner, targetLane).filter(c => c.instanceId !== source.instanceId))).filter((c): c is CardInstance => !!c);
    const amount = source.cardId === 'cornercoach' ? 2 : 1;
    for (const ally of targets) {
      targetIds.add(ally.instanceId);
      m = modify(m, ally.instanceId, c => ({ ...c, powerModifier: c.powerModifier + amount, lastEffectNote: `${source.ability}: +${amount} Hands.` }));
    }
    note(targets.length ? `${source.ability} gave ${targets.length} allies +${amount} Hands.` : `${source.ability} found no eligible ally.`);
  }
  else if (source.cardId === 'nightcashier') {
    if (m.round >= 4) { const motionKey = source.owner === 'player' ? 'playerMotion' : 'cpuMotion'; m = refundMotion(m, source.owner, 1); }
    note(m.round >= 4 ? 'Late Shift restored 1 Motion.' : 'Late Shift needs round 4 or later.');
  }
  else if (source.cardId === 'chessregular') {
    const enemies = inLane(m, enemy, l);
    if (enemies.length === 1) {
      const target = enemies[0];
      const stacks = getEffectiveCardPower(target) >= 3 ? 2 : 1;
      targetIds.add(target.instanceId);
      m = applyBurn(m, source, target, stacks, `Quiet Fork: ${stacks} Burn.`);
      note(`Quiet Fork applied ${stacks} Burn to the lone enemy.`);
    } else note('Quiet Fork needs exactly one enemy here.');
  }
  else if (source.cardId === 'bigzoey') {
    const ally = lowest(inLane(m, source.owner, l).filter(c => c.instanceId !== source.instanceId));
    const target = lowest(inLane(m, enemy, l));
    if (ally) { targetIds.add(ally.instanceId); m = modify(m, ally.instanceId, c => ({ ...c, powerModifier: c.powerModifier + 2, lastEffectNote: 'Hold the Block: +2 Hands.' })); }
    if (target) { targetIds.add(target.instanceId); m = targetEnemyPowerReduction(m, source, target, -2, 'Hold the Block: -2 Hands.'); }
    note(ally || target ? 'Hold the Block shifted the district.' : 'Hold the Block found no other cards.');
  }
  else if (source.cardId === 'bushedo-brown') {
    let succeeded = false;
    const ally = lowest(inLane(m, source.owner, l).filter(c => c.instanceId !== source.instanceId && !c.hazard && c.kind !== 'support'));
    if (ally) {
      targetIds.add(ally.instanceId);
      m = modify(m, ally.instanceId, c => ({ ...c, powerModifier: c.powerModifier + 2,
        lastEffectNote: 'Personal Security: +2 Hands and Protection.' }));
      m = grantProtection(m, source, ally.instanceId);
      succeeded = true;
    }
    const boosted = kumiteBonusTarget(inLane(m, enemy, l));
    const target = boosted ?? highest(inLane(m, enemy, l));
    if (target) {
      targetIds.add(target.instanceId);
      if (boosted) {
        const stripped = trimEnemyBonusHands(m, source, target, 4, 'Personal Security: confiscated bonus Hands.');
        m = stripped.match;
        if (stripped.recipientId) targetIds.add(stripped.recipientId);
        succeeded ||= stripped.removed > 0;
      } else {
        const hit = kumiteStrike(m, source, target, 2, 'Personal Security: 2 damage.');
        m = hit.match;
        if (hit.recipientId) targetIds.add(hit.recipientId);
        succeeded ||= hit.landed;
      }
    }
    note('Personal Security reinforced an ally and challenged inflated Hands.');
    if (succeeded && !echoed) m = trainWaveAbility(m, source.instanceId);
  }
  else if (source.cardId === 'franklin-duke') {
    let succeeded = false;
    const target = highest(inLane(m, enemy, l));
    if (target && (getEffectiveCardPower(target) > getEffectiveCardPower(source) || removableBonusHands(target) > 0)) {
      targetIds.add(target.instanceId);
      const hit = kumiteStrike(m, source, target, 4, 'Read The Strike: 4 damage to a taller or boosted fighter.');
      m = hit.match;
      if (hit.recipientId) targetIds.add(hit.recipientId);
      if (hit.landed) {
        m = modify(m, source.instanceId, c => ({ ...c, powerModifier: c.powerModifier + 3,
          lastEffectNote: 'Read The Strike: counter landed, +3 Hands.' }));
        succeeded = true;
      }
    } else {
      const ally = lowest(m.boards.flat().filter(c => c.owner === source.owner && c.lane !== l && !c.hazard && c.kind !== 'support'));
      if (ally) {
        targetIds.add(ally.instanceId);
        m = modify(m, ally.instanceId, c => ({ ...c, powerModifier: c.powerModifier + 3,
          lastEffectNote: 'Read The Strike: remote ally +3 Hands and Protection.' }));
        m = grantProtection(m, source, ally.instanceId);
        succeeded = true;
      }
    }
    note('Read The Strike countered a taller or boosted fighter, or coached an ally elsewhere.');
    if (succeeded && !echoed) m = trainWaveAbility(m, source.instanceId);
  }
  else if (source.cardId === 'chonk-lee') {
    let hits = 0;
    for (const lane of [0, 1, 2] as Lane[]) {
      const target = highest(inLane(m, enemy, lane));
      if (!target) continue;
      targetIds.add(target.instanceId);
      const hit = kumiteStrike(m, source, target, 2, 'No Mercy: 2 damage.');
      m = hit.match;
      if (hit.recipientId) targetIds.add(hit.recipientId);
      if (hit.landed) hits++;
    }
    if (hits) m = modify(m, source.instanceId, c => ({ ...c, powerModifier: c.powerModifier + Math.min(3, hits),
      lastEffectNote: `No Mercy: +${Math.min(3, hits)} Hands from landed hits.` }));
    note(`No Mercy landed ${hits} district hit${hits === 1 ? '' : 's'}.`);
    if (hits && !echoed) m = trainWaveAbility(m, source.instanceId);
  }
  else if (source.cardId === 'leroy') {
    const diverse = new Set(m.boards.flat().filter(c => !c.hazard && c.owner === source.owner).map(c => canonicalElement(c.type))).size >= 3;
    let succeeded = diverse;
    if (diverse) {
      m = modify(m, source.instanceId, c => ({ ...c, goldenGlow: true, powerModifier: c.powerModifier + 3,
        lastEffectNote: 'Golden Glow: three friendly types, +3 Hands and Protection.' }));
      m = grantProtection(m, source, source.instanceId);
    }
    const target = kumiteBonusTarget(inLane(m, enemy, l)) ?? highest(inLane(m, enemy, l));
    if (target) {
      targetIds.add(target.instanceId);
      let recipient: CardInstance | undefined;
      const beforeStrike = m;
      m = hostileEffect(m, source, target, (state, actual) => {
        recipient = actual;
        const stripped = trimBonusHandsUnshielded(state, actual, 4, 'Golden Glow: removed up to 4 bonus Hands.');
        const current = findCard(stripped.match, actual.instanceId);
        return current ? reduceHands(stripped.match, current, 2, 'Golden Glow: 2 damage.') : stripped.match;
      }, false, false, true);
      if (recipient) {
        targetIds.add(recipient.instanceId);
        succeeded ||= committedDamageBetween(beforeStrike, m, recipient.instanceId) > 0
          || bonusHandsRemovedBetween(beforeStrike, m, recipient.instanceId) > 0;
      }
    }
    note(diverse ? 'Golden Glow punished bonus Hands and rewarded three friendly types.'
      : 'Golden Glow challenged bonus Hands; three friendly types unlock its full glow.');
    if (succeeded && !echoed) m = trainWaveAbility(m, source.instanceId);
  }
  else if (source.cardId === 'dragonflyjones') {
    const candidates = inLane(m, enemy, l);
    const target = kumiteBonusTarget(candidates) ?? [...candidates].filter(c => c.cost >= 4)
      .sort((a, b) => b.cost - a.cost || getEffectiveCardPower(b) - getEffectiveCardPower(a) || a.instanceId.localeCompare(b.instanceId))[0]
      ?? highest(candidates);
    let landed = false;
    if (target) {
      targetIds.add(target.instanceId);
      const amount = removableBonusHands(target) > 0 || target.cost >= 4 ? 4 : 2;
      const hit = kumiteStrike(m, source, target, amount, `Secret Technique: ${amount} damage.`);
      m = hit.match;
      if (hit.recipientId) targetIds.add(hit.recipientId);
      landed = hit.landed;
      if (landed) m = modify(m, source.instanceId, c => ({ ...c, powerModifier: c.powerModifier + 1,
        lastEffectNote: 'Secret Technique: hit landed, +1 Hand.' }));
    }
    note(landed ? 'Secret Technique punished a boosted or costly enemy, or landed its lighter fallback.' : 'Secret Technique found no target or its hit was blocked.');
    if (landed && !echoed) m = trainWaveAbility(m, source.instanceId);
  }
  else if (source.cardId === 'shonuff') {
    const boosted = kumiteBonusTarget(inLane(m, enemy, l));
    const target = boosted ?? highest(inLane(m, enemy, l));
    let succeeded = false;
    if (target) {
      targetIds.add(target.instanceId);
      if (boosted) {
        const stolen = trimEnemyBonusHands(m, source, target, 5, "Who's the Master?: confiscated bonus Hands.");
        m = stolen.match;
        if (stolen.recipientId) targetIds.add(stolen.recipientId);
        if (stolen.removed > 0) {
          m = modify(m, source.instanceId, c => ({ ...c, powerModifier: c.powerModifier + stolen.removed,
            lastEffectNote: `Who's the Master?: +${stolen.removed} confiscated Hands.` }));
          succeeded = true;
        }
      } else {
        const hit = kumiteStrike(m, source, target, 3, "Who's the Master?: 3 damage.");
        m = hit.match;
        if (hit.recipientId) targetIds.add(hit.recipientId);
        succeeded = hit.landed;
      }
    }
    note(!target ? "Who's the Master? found no enemy." : boosted ? "Who's the Master? challenged boosted Hands." : "Who's the Master? pressured the highest enemy.");
    if (succeeded && !echoed) m = trainWaveAbility(m, source.instanceId);
  }
  else if (source.cardId === 'yasuke') {
    let succeeded = false;
    const ally = lowest(inLane(m, source.owner, l).filter(c => c.instanceId !== source.instanceId && !c.statuses.protected));
    if (ally) {
      targetIds.add(ally.instanceId);
      m = modify(m, ally.instanceId, c => ({ ...c, powerModifier: c.powerModifier + 2,
        lastEffectNote: 'Black Blade: +2 Hands and Protection.' }));
      m = grantProtection(m, source, ally.instanceId);
      succeeded = true;
    }
    const target = highest(inLane(m, enemy, l));
    if (target) {
      targetIds.add(target.instanceId);
      const hit = kumiteStrike(m, source, target, 2, 'Black Blade: 2 damage.');
      m = hit.match;
      if (hit.recipientId) targetIds.add(hit.recipientId);
      succeeded ||= hit.landed;
    }
    note(ally && target ? 'Black Blade defended an ally and pressured the enemy.'
      : ally ? 'Black Blade defended an ally.' : target ? 'Black Blade pressured the enemy.' : 'Black Blade found no other cards.');
    if (succeeded && !echoed) m = trainWaveAbility(m, source.instanceId);
  }
  else if (source.cardId === 'mansamusa') {
    for (const district of [0, 1, 2] as Lane[]) {
      const ally = lowest(inLane(m, source.owner, district).filter(c => c.instanceId !== source.instanceId && c.kind !== 'support' && !c.hazard));
      if (!ally) continue;
      targetIds.add(ally.instanceId);
      const amount = ally.type === 'Earth' ? 2 : 1;
      m = modify(m, ally.instanceId, c => ({ ...c, powerModifier: c.powerModifier + amount, lastEffectNote: `Gold Road: +${amount} Hands.` }));
    }
    m = addDiscountToken(m, source.owner, source, 'another-district');
    note('Gold Road rewarded the board and opened a cheaper route to another district.');
  }
  else if (source.cardId === 'tron') {
    const allies = [...inLane(m, source.owner, l)]
      .filter(c => c.instanceId !== source.instanceId && c.kind !== 'support')
      .sort((a, b) => getEffectiveCardPower(a) - getEffectiveCardPower(b) || a.instanceId.localeCompare(b.instanceId)).slice(0, 3);
    for (const ally of allies) {
      targetIds.add(ally.instanceId);
      m = modify(m, ally.instanceId, c => ({ ...c, powerModifier: c.powerModifier + 1, lastEffectNote: 'For the Hood: +1 Hands.' }));
    }
    if (allies.length === 3) m = refundMotion(m, source.owner, 1);
    note(allies.length ? `For the Hood helped ${allies.length} characters${allies.length === 3 ? ' and restored up to 1 Motion' : ''}.` : 'For the Hood needs other friendly characters here.');
  }
  else if (source.cardId === 'johnhenry') {
    const allies = m.boards.flat().filter(c => c.owner === source.owner && c.instanceId !== source.instanceId
      && c.kind !== 'support' && !c.hazard && c.type === 'Earth');
    const boost = Math.min(4, allies.length);
    if (boost) m = modify(m, source.instanceId, c => ({ ...c, powerModifier: c.powerModifier + boost, lastEffectNote: `Steel Driver: +${boost} Hands.` }));
    const target = allies.length >= 2 ? highest(inLane(m, enemy, l)) : undefined;
    if (target) {
      targetIds.add(target.instanceId);
      m = targetEnemyPowerReduction(m, source, target, -2, 'Steel Driver: -2 Hands.');
    }
    note(boost ? `Steel Driver gained +${boost} Hands${target ? ' and pressured the enemy' : ''}.` : 'Steel Driver needs a gang here.');
  }
  else if (['subwaymagician', 'ogdominican', 'conductor'].includes(source.cardId)) {
    if (source.cardId === 'subwaymagician') {
      const target = highest(inLane(m, enemy, l));
      if (target) { targetIds.add(target.instanceId); m = applyWeaken(m, source, target, 'Now You See Me: Weakened.'); }
    }
    const traveler = source.cardId === 'conductor' ? lowest(inLane(m, source.owner, l).filter(c => c.instanceId !== source.instanceId)) : source;
    if (traveler) {
      targetIds.add(traveler.instanceId);
      const destination = lowestFriendlyLane(m, source.owner, l);
      m = move(m, traveler, destination, `${source.ability}: moved to the weakest other district.`);
      const amount = source.cardId === 'conductor' ? 2 + (traveler.type === 'Water' ? 1 : 0) : source.cardId === 'ogdominican' ? 2 : 0;
      if (amount && findCard(m, traveler.instanceId)?.lane === destination) {
        m = cleanseAlly(m, traveler.instanceId, c => ({ ...c,
          ...(source.cardId === 'conductor' ? { statuses: cleanseStatuses(c.statuses) } : {}),
          powerModifier: c.powerModifier + amount,
          lastEffectNote: `${source.ability}: moved, +${amount} Hands${source.cardId === 'conductor' ? ', cleansed' : ''}.`,
        }));
      }
    }
    note(traveler ? `${source.ability} resolved.` : 'Last Stop needs another ally here.');
  }
  else if (source.cardId === 'ashlee') {
    // +1 Hand to every other friendly card already in Ashlee's district.
    const alliesHere = inLane(m, source.owner, l).filter(c => c.instanceId !== source.instanceId && c.kind !== 'support');
    for (const ally of alliesHere) {
      targetIds.add(ally.instanceId);
      m = modify(m, ally.instanceId, c => ({ ...c, powerModifier: c.powerModifier + 1, lastEffectNote: 'Jet Set: +1 Hand.' }));
    }
    const plantCrew = m.boards.flat().filter(c => !c.hazard && c.owner === source.owner && c.type === 'Plant' && c.kind !== 'support');
    const occupiedPlantDistricts = ([0, 1, 2] as Lane[]).filter(district => plantCrew.some(c => c.lane === district));
    const fullPlantCrew = occupiedPlantDistricts.length >= 2;
    if (fullPlantCrew) for (const district of occupiedPlantDistricts) {
      const ally = lowest(plantCrew.filter(c => c.lane === district))!;
      targetIds.add(ally.instanceId);
      m = modify(m, ally.instanceId, c => ({ ...c, powerModifier: c.powerModifier + 2,
        lastEffectNote: 'Jet Set: Plant in at least two districts, +2 Hands.' }));
    }
    // Drop Guyana the gorilla into the weakest friendly district (uncounterable: shrugs off power reductions).
    const destination = lowestFriendlyLane(m, source.owner, l);
    m = summonCard(m, source.owner, destination, SUMMON_TEMPLATES.guyana, 'guyana', source, true);
    // Pressure the highest-Hands enemy on the board.
    const highestEnemy = highest(m.boards.flat().filter(c => !c.hazard && c.owner === enemy && c.kind !== 'support'));
    if (highestEnemy) {
      targetIds.add(highestEnemy.instanceId);
      m = targetEnemyPowerReduction(m, source, highestEnemy, -1, 'Jet Set: -1 Hand.');
    }
    note(`Jet Set summoned Guyana (+4, uncounterable) into district ${destination + 1}, gave +1 Hand to ${alliesHere.length} ally${alliesHere.length === 1 ? '' : 'ies'}${fullPlantCrew ? ', and gave one Plant ally in each occupied district +2 Hands for a spread Plant crew' : ''}${highestEnemy ? ', and pressured the highest-Hands enemy' : ''}.`);
  }
  else if (source.cardId === 'kyle') {
    for (let index = 0; index < 4; index++) {
      const destination = seededIndex(smileBombSeed(m, source.instanceId, index), 3) as Lane;
      m = summonCard(m, enemy, destination, SUMMON_TEMPLATES['smile-bomb'], 'smile-bomb', source);
      const bomb = m.boards[destination].at(-1)!;
      m = modify(m, bomb.instanceId, card => ({ ...card,
        smileBomb: { sourceInstanceId: source.instanceId, sourceOwner: source.owner, detonatesAtRound: m.round + 1 },
        lastEffectNote: 'Planted by KYLE. Explodes at the start of round ' + (m.round + 1) + '.',
      }));
      targetIds.add(bomb.instanceId);
    }
    note('Smile Bombs planted 4 bombs in enemy districts. Each hits one random enemy for -2 Hands next round.', 'timed',
      { unit: 'round', startsAtRound: m.round, expiresAtRound: m.round + 1, expiration: 'round-start' });
  }
  else if (source.cardId === 'captainjigga') {
    // Two Steward tokens always spawn into Jigga's lane. Each one auto-targets
    // a different highest-Hands enemy (up to 2); if no enemies are on the
    // board yet, the stewards still appear but no -2 resolves.
    const destination = l;
    const stewards: string[] = [];
    for (const artworkId of ['steward', 'steward-blue']) {
      m = summonCard(m, source.owner, destination, SUMMON_TEMPLATES.steward, 'steward', source, false, artworkId);
      stewards.push(m.boards[destination].at(-1)!.instanceId);
    }
    for (const stewardId of stewards) {
      const ally = lowest(inLane(m, source.owner, destination).filter(c => c.type === 'Air'
        && c.kind !== 'support' && c.kind !== 'token' && c.instanceId !== source.instanceId && c.instanceId !== stewardId));
      if (ally) {
        targetIds.add(ally.instanceId);
        m = modify(m, ally.instanceId, c => ({ ...c, powerModifier: c.powerModifier + 1,
          lastEffectNote: 'Cabin Gang: a Steward gave this Air ally +1 Hand.' }));
      }
    }
    const enemyPool = [...m.boards.flat().filter(c => !c.hazard && c.owner === enemy && c.kind !== 'support')]
      .sort((a, b) => getEffectiveCardPower(b) - getEffectiveCardPower(a));
    const picked: CardInstance[] = [];
    for (const candidate of enemyPool) {
      if (picked.length >= 2) break;
      if (!picked.find(p => p.instanceId === candidate.instanceId)) picked.push(candidate);
    }
    for (const target of picked) {
      targetIds.add(target.instanceId);
      m = targetEnemyPowerReduction(m, source, target, -2, 'Cabin Gang: -2 Hands.');
    }
    note(`Cabin Gang dispatched 2 stewards${picked.length ? `, ${picked.length} hit${picked.length === 1 ? '' : 's'} enemy Hands` : ' (no enemies in range)'}.`);
  }
  else if ((Object.hasOwn(characterWaveCards, source.cardId) || Object.hasOwn(homecomingCards, source.cardId))) {
    const id = source.cardId;
    const allies = inLane(m, source.owner, l).filter(c => c.instanceId !== source.instanceId && c.kind !== 'support');
    const enemies = inLane(m, enemy, l);
    const buff = (target: CardInstance | undefined, amount: number, text = source.ability) => {
      if (!target) return;
      targetIds.add(target.instanceId);
      m = modify(m, target.instanceId, c => ({ ...c, powerModifier: c.powerModifier + amount, lastEffectNote: text + ': +' + amount + ' Hands.' }));
    };
    const protect = (target: CardInstance | undefined) => {
      if (!target || target.statuses.protected) return;
      targetIds.add(target.instanceId);
      m = modify(m, target.instanceId, c => ({ ...c, statuses: { ...c.statuses, protected: true }, lastEffectNote: source.ability + ': Protected.' }));
      m = { ...m, timedEffects: [...m.timedEffects, { id: 'wave-cover:' + source.instanceId + ':' + target.instanceId,
        kind: 'church-protection', sourceInstanceId: source.instanceId, targetInstanceId: target.instanceId,
        owner: source.owner, lane: target.lane!, startsAtRound: m.round, expiresAtRound: 7, expiration: 'match-complete' }] };
    };
    if (id === 'homelessguy') {
      if (source.wildEmptyWallet) {
        const target = highest(enemies);
        if (target) {
          targetIds.add(target.instanceId);
          m = hostileEffect(m, source, target, (state, actual) => {
            if (actual.statuses.uncounterable) return state;
            let after = reduceHands(state, actual, 2, 'Nothing to Lose: up to 2 Hands stolen.');
            const stolen = Math.min(2, directDamageAmount(state, after, actual));
            if (stolen) after = modify(after, source.instanceId, c => ({ ...c, powerModifier: c.powerModifier + stolen }));
            return after;
          }, false, false, true);
        }
        note(target ? 'Nothing to Lose spent the last deployment Motion: attempted to steal 2 Hands.' : 'Nothing to Lose: no enemy to steal from.');
      } else {
        const amount = source.wildInvestment ?? 0;
        const key = source.owner === 'player' ? 'playerMotion' : 'cpuMotion';
        if (amount > 0) {
          m = { ...m, [key]: m[key] - amount };
          buff(findCard(m, source.instanceId), amount + 1, 'Nothing to Lose');
        }
        note('Nothing to Lose invested ' + amount + ' extra Motion for +' + (amount > 0 ? amount + 1 : 0) + ' Hands.');
      }
    } else if (id === 'fangirl' || id === 'grownfanboy') {
      const idol = highest(id === 'fangirl' ? allies : m.boards.flat().filter(c => !c.hazard && c.owner === source.owner
        && c.instanceId !== source.instanceId && c.kind !== 'support'));
      if (idol) m = modify(m, source.instanceId, c => ({ ...c, idolId: idol.instanceId, lastEffectNote: source.ability + ': idol is ' + idol.name + '.' }));
      note(idol ? source.ability + ': ' + idol.name + ' is your idol.' : source.ability + ' needs another ally when revealed.');
    } else if (id === 'lawlessyn') {
      const target = lowest(enemies);
      const destinations = ([0, 1, 2] as Lane[]).filter(d => d !== l && !getStoryLockedLanes(m, enemy).includes(d))
        .sort((a, b) => getLaneScoreForMatch(m, inLane(m, enemy, b), b, enemy) - getLaneScoreForMatch(m, inLane(m, enemy, a), a, enemy) || a - b);
      if (target && destinations.length) {
        targetIds.add(target.instanceId);
        const originalLane = target.lane;
        m = forceEnemyMove(m, source, target, destinations[0]);
        const displaced = findCard(m, target.instanceId);
        if (displaced && displaced.lane !== originalLane) {
          buff(findCard(m, source.instanceId), 1, 'Wrong Block: successful displacement, +1 Hand.');
        }
      }
      note(target && destinations.length ? 'Wrong Block targeted the weakest enemy for relocation.' : 'Wrong Block found no legal enemy destination.');
    } else if (id === 'streetapostle') {
      note('Spread the Word is watching for another Plant ally to gain Hands.');
    } else if (id === 'asphaltapostle') {
      const target = lowest(m.boards.flat().filter(c => c.owner === source.owner && c.instanceId !== source.instanceId
        && c.kind !== 'support' && !c.hazard && c.type === 'Earth'));
      if (target) {
        protect(target);
        m = modify(m, target.instanceId, c => ({ ...c, powerModifier: c.powerModifier + 1, lastEffectNote: 'Concrete Congregation: +1 Hands and Protected.' }));
      }
      note(target ? 'Concrete Congregation protects the weakest other Earth ally and gives it +1 Hand.' : 'Concrete Congregation found no other friendly Earth character.');
    } else if (id === 'colognecriminal') {
      const existing = m.lingeringScents?.find(s => s.owner === source.owner && s.lane === l && s.expiresAfterRound >= m.round);
      m = { ...m, lingeringScents: [...(m.lingeringScents ?? []).filter(s => s.expiresAfterRound >= m.round && !(s.owner === source.owner && s.lane === l)), {
        owner: source.owner, lane: l, source, expiresAfterRound: m.round + 1, triggeredRound: existing?.triggeredRound,
      }] };
      m = trainWaveAbility(m, source.instanceId);
      note('Lingering Scent marks this district through round ' + (m.round + 1) + '. Enemies already here are unaffected.');
    } else if (id === 'passportbro') {
      const destinationsFor = (traveler: CardInstance) => ([0, 1, 2] as Lane[])
        .filter(d => canMoveTo(m, traveler, d) && movementCapacityAvailable(m, traveler, d))
        .sort((a, b) => getLaneScoreForMatch(m, inLane(m, source.owner, a), a, source.owner)
          - getLaneScoreForMatch(m, inLane(m, source.owner, b), b, source.owner) || a - b);
      const traveler = lowest(allies.filter(ally => destinationsFor(ally).length));
      const destination = traveler ? destinationsFor(traveler)[0] : undefined;
      let traveled = false;
      if (traveler && destination !== undefined) {
        targetIds.add(traveler.instanceId);
        m = move(m, traveler, destination, 'Geographic Arbitrage moved this ally.');
        traveled = findCard(m, traveler.instanceId)?.lane === destination;
        if (traveled) m = cleanseAlly(m, traveler.instanceId, card => ({
          ...card, statuses: cleanseStatuses(card.statuses), powerModifier: card.powerModifier + 2,
          lastEffectNote: 'Geographic Arbitrage: successful travel cleansed this ally and gave +2 Hands.',
        }));
      }
      note(traveled ? 'Geographic Arbitrage moved the weakest movable ally to its weakest legal open district, cleansed it and gave +2 Hands.'
        : traveler ? 'Geographic Arbitrage was blocked before its passenger could travel.' : 'Geographic Arbitrage found no legal passenger route.');
    } else if (id === 'seafoodassassin') {
      for (const target of enemies) {
        targetIds.add(target.instanceId);
        m = hostileEffect(m, source, target, (state, actual) => reduceHands(state, actual,
          actual.statuses.burnStacks + 2, 'Extra Sauce: all accumulated Burn detonated and consumed.', 0), false, false, true);
      }
      note('Extra Sauce applied 2 Burn and immediately detonated accumulated Burn on exposed enemies here.');
    } else if (id === 'homelesslegend') {
      note('Built Different is ready to survive a lethal hit and recover lost Hands.');
    } else if (id === 'godofhookah') {
      const spark = lowest(m.boards.flat().filter(c => c.owner === enemy && c.lane !== l
        && (c.kind ?? 'character') === 'character' && !c.hazard && c.statuses.burnStacks === 0));
      if (spark) {
        targetIds.add(spark.instanceId);
        m = applyBurn(m, source, spark, 1, 'Pass the Hose: lit the next district; 1 Burn.');
      }
      note(spark ? 'Pass the Hose attempted a remote ignition; the Burn relay is ready.' : 'Pass the Hose has no unburned remote target; the Burn relay is ready.');
    } else if (id === 'mailman') {
      note('Express Delivery is watching for your second Electric character each round.');
    }
  }
  else if (Object.hasOwn(elementalWaveCards, source.cardId)) {
    const id = source.cardId;
    const allies = m.boards.flat().filter(c => !c.hazard && c.owner === source.owner && c.kind !== 'support' && c.instanceId !== source.instanceId);
    const inDistrict = allies.filter(c => c.lane === l);
    const buff = (target: CardInstance | undefined, amount: number) => {
      if (!target) return;
      targetIds.add(target.instanceId);
      m = modify(m, target.instanceId, c => ({ ...c, powerModifier: c.powerModifier + amount, lastEffectNote: `${source.ability}: +${amount} Hands.` }));
    };
    const cleanse = (target: CardInstance | undefined, amount: number) => {
      if (!target || !needsCleanse(target)) return;
      targetIds.add(target.instanceId);
      m = cleanseAlly(m, target.instanceId, c => ({ ...c, statuses: cleanseStatuses(c.statuses), powerModifier: c.powerModifier + amount, lastEffectNote: `${source.ability}: cleansed, +${amount} Hands.` }));
    };
    if (id === 'puddle') cleanse(lowest(inDistrict.filter(c => c.statuses.frozen || c.statuses.silenced)), 1);
    else if (id === 'hydrant') for (const target of inDistrict) cleanse(target, 1);
    else if (id === 'floodgate') for (const lane of [0, 1, 2] as Lane[]) cleanse(lowest(allies.filter(c => c.lane === lane && needsCleanse(c))), 2);
    else if (id === 'seedvendor' || id === 'mosskeeper') {
      buff(lowest((id === 'seedvendor' ? inDistrict : allies).filter(c => c.type === 'Plant')), id === 'seedvendor' ? 1 : 2);
    } else if (id === 'canopy') {
      for (const target of inDistrict.filter(c => c.type === 'Plant')) buff(target, 1);
      const plants = allies.filter(c => c.type === 'Plant').concat(findCard(m, source.instanceId)!);
      if ([0, 1, 2].every(lane => plants.some(c => c.lane === lane))) {
        for (const lane of [0, 1, 2] as Lane[]) buff(lowest(plants.filter(c => c.lane === lane)), 1);
      }
    } else if (id === 'circuityn') {
      if (allies.some(c => c.type === 'Electric' && c.lane !== l)) m = refundMotion(m, source.owner, 1);
    } else if (id === 'flashcourier') m = addDiscountToken(m, source.owner, source, 'another-district');
    else if (id === 'powerstation') {
      let helped = false;
      for (const lane of [0, 1, 2] as Lane[]) {
        if (lane === l) continue;
        const target = lowest(allies.filter(c => c.type === 'Electric' && c.lane === lane));
        if (target) { buff(target, 1); helped = true; }
      }
      if (helped) m = refundMotion(m, source.owner, 1);
    } else if (id === 'gustscout' || id === 'blockmessenger' || id === 'skyline') {
      const traveler = id === 'gustscout' ? source : lowest(inDistrict.filter(c => id !== 'skyline' || c.type === 'Air'));
      if (traveler) {
        const destination = lowestFriendlyLane(m, source.owner, l);
        targetIds.add(traveler.instanceId);
        m = move(m, traveler, destination, `${source.ability}: moved to the weakest other district.`);
        if (findCard(m, traveler.instanceId)?.lane === destination) buff(findCard(m, traveler.instanceId), id === 'skyline' ? 2 : 1);
      }
    }
    const changed = [...targetIds].some(key => {
      const old = findCard(before, key), current = findCard(m, key);
      return old && (!current || old.lane !== current.lane || old.powerModifier !== current.powerModifier || JSON.stringify(old.statuses) !== JSON.stringify(current.statuses));
    });
    note(changed || m.playerMotion !== before.playerMotion || m.cpuMotion !== before.cpuMotion || m.discountTokens.length !== before.discountTokens.length
      ? `${source.ability} resolved.` : `${source.ability}: no eligible ally or effect yet.`);
  }
  else if (Object.hasOwn(streetWaveCards, source.cardId)) {
    const id = source.cardId;
    const allies = inLane(m, source.owner, l).filter(c => c.instanceId !== source.instanceId && c.kind !== 'support');
    const enemies = inLane(m, enemy, l);
    const buff = (target: CardInstance | undefined, amount: number) => {
      if (!target) return;
      targetIds.add(target.instanceId);
      m = modify(m, target.instanceId, c => ({ ...c, powerModifier: c.powerModifier + amount, lastEffectNote: `${source.ability}: +${amount} Hands.` }));
    };
    const reduce = (target: CardInstance | undefined, amount: number) => {
      if (!target) return;
      targetIds.add(target.instanceId);
      m = targetEnemyPowerReduction(m, source, target, -amount, `${source.ability}: -${amount} Hands.`);
    };
    const cleanse = (target: CardInstance, amount: number) => {
      if (source.cardId === 'foodz' ? !needsCleanse(target) && !m.creativeMarks?.some(x=>x.kind==='pending-appeal'&&x.targets.includes(target.instanceId)) : !target.statuses.frozen && !target.statuses.silenced) return;
      targetIds.add(target.instanceId);
      m = cleanseAlly(m, target.instanceId, c => ({ ...c, statuses: cleanseStatuses(c.statuses), powerModifier: c.powerModifier + amount, lastEffectNote: `${source.ability}: cleansed${amount ? `, +${amount} Hands` : ''}.` }));
    };
    const losing = () => getLaneScoreForMatch(m, inLane(m, source.owner, l), l, source.owner) < getLaneScoreForMatch(m, enemies, l, enemy);
    if (['homelessyn', 'sportsprodigy', 'fein', 'divorceddad', 'failedathlete'].includes(id)) {
      const succeeds = id === 'homelessyn' ? enemies.length > inLane(m, source.owner, l).length - 1
        : id === 'sportsprodigy' ? losing()
        : id === 'fein' ? enemies.length > 0
        : id === 'alchy' ? m.round >= 4
        : id === 'divorceddad' ? allies.length === 0 && enemies.length > 0
        : id === 'failedathlete' ? m.round >= 4 && losing()
        : inLane(m, source.owner, l).length === 1;
      const amount = id === 'failedathlete' || id === 'homelessyn' ? 3 : id === 'sportsprodigy' || id === 'divorceddad' ? 2 : 1;
      if (succeeds) {
        buff(source, amount);
        if (id === 'sportsprodigy') reduce(highest(enemies), 1);
        if (id === 'fein' && enemies.length >= 2) {
          const burnTarget = highest(enemies);
          if (burnTarget) { targetIds.add(burnTarget.instanceId); m = applyBurn(m, source, burnTarget, 1, 'One More: 1 Burn.'); }
        }
      } else if (id === 'sportsprodigy' && !source.sportsComebackArmed && !source.sportsComebackUsed) {
        m = modify(m, source.instanceId, c => ({
          ...c,
          sportsComebackArmed: true,
          sportsComebackUntilRound: m.round + 1,
          lastEffectNote: 'Next Up: comeback armed through next round.',
        }));
      }
    } else if (id === 'stud') {
      const target = lowest(allies);
      buff(target, 2);
      if (target && !target.statuses.protected) {
        m = modify(m, target.instanceId, c => ({ ...c, statuses: { ...c.statuses, protected: true } }));
        m = { ...m, timedEffects: [...m.timedEffects, { id: `stud:${source.instanceId}:${target.instanceId}`, kind: 'church-protection', sourceInstanceId: source.instanceId, targetInstanceId: target.instanceId, owner: source.owner, lane: l, startsAtRound: m.round, expiresAtRound: 7, expiration: 'match-complete' }] };
      }
    } else if (id === 'gothkid') {
      const destination = ([0, 1, 2] as Lane[]).find(lane => m.boards[lane].length === 0 && canMoveTo(m, source, lane));
      if (destination !== undefined) {
        m = move(m, source, destination, 'Dead Air: moved into an empty district.');
        const goth = findCard(m, source.instanceId);
        if (goth?.lane === destination) {
          m = { ...m, districtTraps: [...(m.districtTraps ?? []).filter(t => t.kind !== 'dead-air' || t.source.instanceId !== source.instanceId),
            { kind: 'dead-air', owner: source.owner, lane: destination, source: goth, expiresAfterRound: getMatchRoundLimit(m) }] };
          targetIds.add(source.instanceId);
        }
      } else {
        const target = lowest(enemies.filter(c => c.cost <= 3));
        if (target) {
          targetIds.add(target.instanceId);
          m = targetEnemy(m, source, target, c => ({
            ...c,
            statuses: { ...c.statuses, silenced: true },
            lastEffectNote: `${source.ability}: Silenced.`,
          }));
        }
      }
    } else if (id === 'redpill') {
      const target = highest(enemies);
      if (target) {
        if (target.statuses.weakened) {
          targetIds.add(target.instanceId);
          m = targetEnemy(m, source, target, c => ({ ...c, statuses: { ...c.statuses, silenced: true }, lastEffectNote: `${source.ability}: already Weakened, silenced.` }));
          if (findCard(m, target.instanceId)?.statuses.silenced) buff(source, 2);
        } else { targetIds.add(target.instanceId); m = applyWeaken(m, source, target, `${source.ability}: Weakened.`); }
      }
    } else if (id === 'stonerjr' || id === 'stonersr') {
      const eligible = allies.filter(c => c.statuses.frozen || c.statuses.silenced);
      const targets = id === 'stonerjr' ? [lowest(eligible)].filter((c): c is CardInstance => !!c) : eligible;
      for (const target of targets) cleanse(target, 1);
    } else if (id === 'bblnice' || id === 'failedrapper') {
      for (const target of allies.filter(c => id === 'bblnice' || c.cost <= 2)) buff(target, 1);
    } else if (id === 'bbldemon') {
      for (const target of enemies) reduce(target, 1);
    } else if (id === 'break' || id === 'bboy') {
      const traveler = id === 'break' ? lowest(allies) : source;
      if (traveler) {
        targetIds.add(traveler.instanceId);
        const destination = lowestFriendlyLane(m, source.owner, l);
        m = move(m, traveler, destination, `${source.ability}: moved to the weakest other district.`);
        if (findCard(m, traveler.instanceId)?.lane === destination) {
          const target = id === 'break' ? findCard(m, traveler.instanceId)
            : lowest(inLane(m, source.owner, destination).filter(c => c.instanceId !== source.instanceId && c.kind !== 'support'));
          buff(target, 1);
        }
      }
    } else if (id === 'krump' && enemies.length) {
      buff(source, 2); reduce(highest(enemies), 2);
    } else if (id === 'yunghustle') {
      if (m.boards.flat().some(c => !c.hazard && c.owner === source.owner && c.kind !== 'support' && c.lane !== l)) {
        const key = source.owner === 'player' ? 'playerMotion' : 'cpuMotion';
        m = refundMotion(m, source.owner, 1);
      }
    } else if (id === 'simmy') {
      reduce(highest(enemies), 3); buff(lowest(allies), 2);
    } else if (id === 'foodz') {
      const crew = m.boards.flat().filter(c => !c.hazard && c.owner === source.owner && c.instanceId !== source.instanceId && c.kind !== 'support');
      const recovery = lowest(crew.filter(c => c.type === 'Light' && needsCleanse(c)));
      for (const target of crew) cleanse(target, 0);
      for (const district of [0, 1, 2] as const) {
        const target = lowest(inLane(m, source.owner, district).filter(c => c.instanceId !== source.instanceId && (c.kind ?? 'character') === 'character'));
        if (target) buff(target, 2);
      }
      if (recovery) buff(findCard(m, recovery.instanceId), 2);
      if (!m.foodzCommunityServed?.[source.owner]) {
        const neighbors = ([0, 1, 2] as const).map(district => lowest(inLane(m, source.owner, district)
          .filter(c => c.instanceId !== source.instanceId && isHomelessCharacter(c))))
          .filter((c): c is CardInstance => !!c);
        if (neighbors.length) {
          m = { ...m, foodzCommunityServed: { ...m.foodzCommunityServed, [source.owner]: true } };
          for (const target of neighbors) {
            buff(target, 2);
            m = grantProtection(m, source, target.instanceId);
          }
        }
      }
    }
    const succeeded = [...targetIds].some(key => {
      const old = findCard(before, key), current = findCard(m, key);
      return old && (!current || old.lane !== current.lane || old.powerModifier !== current.powerModifier || old.statuses.frozen !== current.statuses.frozen || old.statuses.silenced !== current.statuses.silenced || old.statuses.protected !== current.statuses.protected
        || (needsCleanse(old) && !needsCleanse(current)));
    }) || m.playerMotion !== before.playerMotion || m.cpuMotion !== before.cpuMotion;
    note(succeeded ? `${source.ability} resolved.` : `${source.ability}: condition not met or effect blocked.`);
  }
  else if (Object.hasOwn(elementalBondWaveCards, source.cardId)) {
    const id = source.cardId;
    const allies = inLane(m, source.owner, l).filter(c => c.instanceId !== source.instanceId && c.kind !== 'support');
    const enemies = inLane(m, enemy, l);
    const buff = (target: CardInstance | undefined, amount: number) => {
      if (!target) return;
      targetIds.add(target.instanceId);
      m = modify(m, target.instanceId, c => ({
        ...c,
        powerModifier: c.powerModifier + amount,
        lastEffectNote: `${source.ability}: +${amount} Hands.`,
      }));
    };
    const cleanse = (target: CardInstance | undefined, amount = 1) => {
      if (!target || (!target.statuses.frozen && !target.statuses.silenced)) return;
      targetIds.add(target.instanceId);
      m = cleanseAlly(m, target.instanceId, c => ({
        ...c,
        statuses: cleanseStatuses(c.statuses),
        powerModifier: c.powerModifier + amount,
        lastEffectNote: `${source.ability}: cleansed, +${amount} Hands.`,
      }));
    };
    const reduce = (target: CardInstance | undefined, amount: number) => {
      if (!target) return false;
      targetIds.add(target.instanceId);
      const beforeDamage = m;
      const reduction = amount + elementalMatchupBonus(source.type, target.type);
      m = targetEnemyPowerReduction(m, source, target, -reduction, `${source.ability}: -${reduction} Hands.`);
      return directDamageAmount(beforeDamage, m, target) > 0;
    };
    const travel = (card: CardInstance) => {
      targetIds.add(card.instanceId);
      const destination = lowestFriendlyLane(m, source.owner, l);
      m = move(m, card, destination, `${source.ability}: moved to the weakest other district.`);
      return findCard(m, card.instanceId)?.lane === destination;
    };
    const weaken = (target: CardInstance | undefined) => {
      if (!target) return;
      targetIds.add(target.instanceId);
      m = applyWeaken(m, source, target, `${source.ability}: Weakened.`);
    };
    if (id === 'riptidebruiser') {
      if (reduce(highest(enemies), 1)) buff(findCard(m, source.instanceId), 1);
    } else if (id === 'stillwatermedic') {
      const target = lowest(allies.filter(c => c.statuses.frozen || c.statuses.silenced));
      cleanse(target);
      if (target) buff(findCard(m, source.instanceId), 1);
    } else if (id === 'monsoonanchor') {
      weaken(highest(enemies));
    } else if (id === 'rootnurse') {
      const remaining = source.owner === 'player' ? m.playerMotion : m.cpuMotion;
      if (remaining >= 4) buff(findCard(m, source.instanceId), 2);
      else {
        const crew = m.boards.flat().filter(c => !c.hazard && c.kind !== 'support'
          && c.owner === source.owner && c.instanceId !== source.instanceId);
        const patient = lowest(crew.filter(c => c.statuses.frozen || c.statuses.silenced));
        if (patient) cleanse(patient, 3);
        else {
          const plant = lowest(crew.filter(c => c.type === 'Plant'));
          if (plant) buff(plant, 3);
          else buff(findCard(m, source.instanceId), 2);
        }
      }
    } else if (id === 'rainmaker') {
      if (!echoed && !source.rainmakerRefundUsed) {
        targetIds.add(source.instanceId);
        m = modify(m, source.instanceId, c => ({ ...c, rainmakerRefundUsed: true,
          lastEffectNote: `${source.ability}: one-use 2 Motion refund.` }));
        m = refundMotion(m, source.owner, 2);
      }
    } else if (id === 'batteryback') {
      const broken = lowest(m.boards.flat().filter(c => !c.hazard && c.owner === source.owner
        && c.kind !== 'support' && c.lane !== l && c.powerModifier < 0));
      if (broken) { buff(broken, 1); m = refundMotion(m, source.owner, 1); }
    } else if (id === 'wiretap') {
      m = addDiscountToken(m, source.owner, source, 'another-district');
    } else if (id === 'livewire') {
      if (travel(source)) {
        const moved = findCard(m, source.instanceId)!;
        buff(moved, 1);
        m = addDiscountToken(m, source.owner, moved, 'livewire-cross-district');
      }
    } else if (id === 'gust') {
      if (travel(source)) reduce(lowest(inLane(m, enemy, findCard(m, source.instanceId)!.lane!)), 1);
    } else if (id === 'sprout') {
      const plant = lowest(allies.filter(c => c.type === 'Plant'));
      if (plant) { buff(plant, 2); buff(findCard(m, source.instanceId), 1); }
    } else if (id === 'gardenwall') {
      reduce(highest(m.boards.flat().filter(c => !c.hazard && c.owner === enemy && c.lane !== l)), 2);
      buff(lowest(allies), 1);
      buff(lowest(m.boards.flat().filter(c => !c.hazard && c.kind !== 'support'
        && c.owner === source.owner && c.type === 'Plant' && c.lane !== l)), 1);
    } else if (id === 'crosswind') {
      weaken(highest(enemies));
      const traveler = lowest(allies);
      if (traveler && travel(traveler)) buff(findCard(m, traveler.instanceId), 2);
    } else if (id === 'cloudbreak') {
      if (travel(source)) {
        const left = lowest(inLane(m, source.owner, l).filter(c => (c.kind ?? 'character') === 'character'));
        buff(findCard(m, source.instanceId), 1);
        if (left) { buff(left, left.type === 'Air' ? 3 : 2); m = grantProtection(m, source, left.instanceId); }
      }
    }
    const succeeded = [...targetIds].some(key => {
      const old = findCard(before, key), current = findCard(m, key);
      return old && (!current || old.lane !== current.lane || old.powerModifier !== current.powerModifier
        || JSON.stringify(old.statuses) !== JSON.stringify(current.statuses));
    }) || m.playerMotion !== before.playerMotion || m.cpuMotion !== before.cpuMotion
      || m.discountTokens.length > before.discountTokens.length;
    note(succeeded
      ? id === 'wiretap' ? `${source.ability}: next card in another district costs 1 less Motion.` : `${source.ability} resolved.`
      : `${source.ability}: condition not met or effect blocked.`);
  }
  else if (source.cardId === 'wifey') {
    const duration: EventDuration = { unit: 'round', startsAtRound: m.round, expiresAtRound: m.round + 1, expiration: 'round-start' };
    m = modify(m, source.instanceId, (c) => ({ ...c, statuses: { ...c.statuses, protected: true }, lastEffectNote: 'Side Eye is protecting this lane.' }));
    m = { ...m, timedEffects: [...m.timedEffects.filter((effect) => effect.sourceInstanceId !== source.instanceId || effect.kind === 'salon-protection'), { id: `wifey:${source.instanceId}:${m.round}`, kind: 'wifey-protection', sourceInstanceId: source.instanceId, owner: source.owner, lane: l, startsAtRound: m.round, expiresAtRound: m.round + 1, expiration: 'round-start' }] };
    note('Side Eye will block one targeted effect this round.', 'timed', duration);
  }
  const mechanicallyChanged = (id: string) => {
    const old = findCard(before, id), current = findCard(m, id);
    return !!old && (!current || old.lane !== current.lane || old.powerModifier !== current.powerModifier
      || old.basePower !== current.basePower || old.moved !== current.moved
      || old.copiedAbilityCardId !== current.copiedAbilityCardId || old.networkBoosts !== current.networkBoosts
      || JSON.stringify(old.statuses) !== JSON.stringify(current.statuses));
  };
  const protectionBlockedIds = [...targetIds].filter(id => before.timedEffects.some(e =>
    (e.kind === 'salon-protection' || e.kind === 'church-protection') && e.targetInstanceId === id
      && !m.timedEffects.some(active => active.id === e.id)));
  const changedTargetIds = [...targetIds].filter(mechanicallyChanged);
  const successfulChangedTargetIds = changedTargetIds.filter(id => !protectionBlockedIds.includes(id));
  const boardAdditionSucceeded = m.boards.flat().some(card => !findCard(before, card.instanceId));
  const movementSucceeded = [source.instanceId, ...targetIds].some(id => findCard(before, id)?.lane !== findCard(m, id)?.lane);
  const meaningfulExpansionChange = mechanicallyChanged(source.instanceId) || successfulChangedTargetIds.length > 0 || boardAdditionSucceeded;
  const isExpansion = Object.hasOwn(expansionCards, source.cardId) || Object.hasOwn(streetWaveCards, source.cardId) || Object.hasOwn(elementalWaveCards, source.cardId)
    || (Object.hasOwn(characterWaveCards, source.cardId) || Object.hasOwn(homecomingCards, source.cardId))
    || Object.hasOwn(mythicLegendCards, source.cardId) || source.kind === 'support';
  const baseSucceeded = protectionBlockedIds.length ? meaningfulExpansionChange || m.playerMotion !== before.playerMotion || m.cpuMotion !== before.cpuMotion
    : source.cardId === 'shiesty' ? m.boards.flat().length > before.boards.flat().length
    : isExpansion ? meaningfulExpansionChange || m.playerMotion !== before.playerMotion || m.cpuMotion !== before.cpuMotion
      || m.discountTokens.length > before.discountTokens.length
    : match.districtSnapshot && ['bikelife', 'vibe', 'carmeet', 'delivery'].includes(source.cardId)
    ? movementSucceeded
    : source.cardId === "plug" || source.cardId === "streamer" || source.cardId === "gamer" || source.cardId === "bossbabe" || source.cardId === "stockz" || source.cardId === "buddy"
    ? true
    : mechanicallyChanged(source.instanceId)
      || successfulChangedTargetIds.length > 0 || m.discountTokens.length > before.discountTokens.length
      || m.playerMotion !== before.playerMotion || m.cpuMotion !== before.cpuMotion;
  // Fixed upgrades resolve after the printed ability in authored unlock order.  Their
  // small bounded effect budget prevents progression from changing base-card identity.
  if (!echoed && baseSucceeded && (Object.hasOwn(characterWaveCards, source.cardId) || Object.hasOwn(homecomingCards, source.cardId))) m = trainWaveAbility(m, source.instanceId);
  if (!echoed && !source.statuses.silenced && !source.statuses.frozen && baseSucceeded && !KUMITE_COMBAT_IDS.has(source.cardId) && !(source.cardId === 'rainmaker' && source.rainmakerRefundUsed) && !(Object.hasOwn(characterWaveCards, source.cardId) || Object.hasOwn(homecomingCards, source.cardId))) {
    for (const upgrade of snapshotUpgradesForCard(m.abilityUpgradeSnapshot, source.owner, source.cardId)) {
      const beforeUpgrade = m;
      const effect = upgrade.effect;
      const target = effect.kind === "self-power"
        ? findCard(m, source.instanceId)
        : successfulChangedTargetIds
          .map((id) => findCard(m, id))
          .find((card): card is CardInstance => !!card && card.owner === (effect.target === "friendly" ? source.owner : enemy));
      if (!target) continue;
      m = modify(m, target.instanceId, (card) => ({
        ...card,
        powerModifier: card.powerModifier + upgrade.effect.amount,
        lastEffectNote: `${upgrade.name}: ${upgrade.effect.amount >= 0 ? "+" : ""}${upgrade.effect.amount} Hands.`,
      }));
      if (upgrade.effect.amount < 0) m = removeDestroyedCard(m, target.instanceId);
      m = addEvent(beforeUpgrade, m, {
        type: "ability",
        sourceId: source.instanceId,
        owner: source.owner,
        targetIds: [target.instanceId],
        kind,
        note: `${upgrade.name} upgraded ${target.name}: ${upgrade.effect.amount >= 0 ? "+" : ""}${upgrade.effect.amount} Hands.`,
        abilityMetadata: {
          upgradeId: upgrade.id,
          upgradeName: upgrade.name,
          sourceCardId: source.cardId,
          sourceInstanceId: source.instanceId,
          targetInstanceIds: [target.instanceId],
          result: "applied",
        },
      });
    }
  }
  if (!echoed && source.effect.startsWith('On Reveal:')) {
    m = { ...m, lastRevealedCardId: source.cardId, entranceHistory: [...(m.entranceHistory ?? []).filter(id => id !== source.instanceId), source.instanceId] };
  }
  return m;
}

/** Keep confiscation deltas inside one completed public action, never persisted matches. */
function clearResolvedHandsAccounting(match: Match): Match {
  if (!Object.hasOwn(match, NON_DAMAGE_HANDS_LOSS)) return match;
  const { [NON_DAMAGE_HANDS_LOSS]: _resolvedAccounting, ...settled } = match;
  return settled;
}

export function playCard(match: Match, owner: Owner, instanceId: string, targetLane: Lane, squabble = false, investment = 0): Match {
  return clearResolvedHandsAccounting(resolveSwookieRecruitment(resolveCardPlay(match, owner, instanceId, targetLane, squabble, true, investment)));
}

/** Spend Motion and resolve a card while keeping the current crew's turn open. */
function applyDistrictArrival(match: Match, owner: Owner, instanceId: string, targetLane: Lane): Match {
  const district = match.districtSnapshot?.locations[targetLane], runtime = match.districtRuntime;
  if (!district || !runtime) return match;
  const effect = district.effect;
  let after = match, note = '';
  let targetIds = [instanceId];
  if (effect.kind === 'detain-first' && runtime.plays[owner][targetLane] === 1) {
    after = { ...match, districtRuntime: { ...runtime, detainedCardIds: [...runtime.detainedCardIds, instanceId] } };
    note = `${district.name}: this side's first arrival cannot move for the rest of the fade.`;
  }
  const bonus = runtime.roundPlays[owner][targetLane] === 1
    && ((effect.kind === 'comeback' && runtime.trailing[owner][targetLane]) || (effect.kind === 'late-arrival' && match.round >= effect.startsAtRound) || effect.kind === 'tithe') ? effect.amount : 0;
  if (bonus) {
    note = `${district.name}: +${bonus} Hands for this round's first arrival.`;
    after = modify(after, instanceId, card => ({ ...card, powerModifier: card.powerModifier + bonus, lastEffectNote: note }));
  }
  if (runtime.roundPlays[owner][targetLane] === 1 && effect.kind === 'salon-protection') {
    note = `${district.name}: this arrival blocks its next targeted enemy ability.`;
    after = modify(after, instanceId, card => ({ ...card, statuses: { ...card.statuses, protected: true }, lastEffectNote: note }));
    after = { ...after, timedEffects: [...after.timedEffects, {
      id: `salon:${instanceId}`, kind: 'salon-protection', sourceInstanceId: instanceId, targetInstanceId: instanceId,
      owner, lane: targetLane, startsAtRound: match.round, expiresAtRound: 7, expiration: 'match-complete',
    }] };
  }
  if (runtime.roundPlays[owner][targetLane] === 1 && effect.kind === 'crew-cleanse') {
    targetIds = inLane(after, owner, targetLane).filter(c => c.instanceId !== instanceId
      && (c.statuses.frozen || c.statuses.silenced || c.powerModifier < 0)).map(c => c.instanceId);
    note = targetIds.length ? `${district.name}: cleared Freeze, Silence, and negative Hands from ${targetIds.length} allies.` : `${district.name}: no allies needed a cleanup.`;
    for (const id of targetIds) after = cleanseAlly(after, id, card => ({ ...card,
      powerModifier: Math.max(0, card.powerModifier), statuses: cleanseStatuses(card.statuses), lastEffectNote: note,
    }));
  }
  if (effect.kind === 'silence-arrival') {
    note = district.name + ': this card enters Silenced.';
    after = modify(after, instanceId, c => ({ ...c, statuses: { ...c.statuses, silenced: true }, lastEffectNote: note }));
  }
  if (runtime.roundPlays[owner][targetLane] === 1 && effect.kind === 'pawn-sacrifice') {
    const sacrifice = lowest(inLane(after, owner, targetLane).filter(c => c.instanceId !== instanceId));
    if (sacrifice) {
      const gain = getEffectiveCardPower(sacrifice);
      targetIds.push(sacrifice.instanceId);
      note = district.name + ': traded ' + sacrifice.name + ' for +' + gain + ' permanent Hands.';
      after = { ...after, boards: after.boards.map(items => items.filter(c => c.instanceId !== sacrifice.instanceId)) as Match['boards'],
        timedEffects: after.timedEffects.filter(e => e.sourceInstanceId !== sacrifice.instanceId && e.targetInstanceId !== sacrifice.instanceId) };
      after = modify(after, instanceId, c => ({ ...c, powerModifier: c.powerModifier + gain, lastEffectNote: note }));
    } else note = district.name + ': no other ally to trade.';
  }
  if (runtime.roundPlays[owner][targetLane] === 1 && effect.kind === 'market-draw') {
    const drawn = drawDeckCard(after, owner);
    // Keep the identity out of public event notes and targets.
    note = district.name + (drawn.card ? ': drew one card.' : ': deck empty; no card drawn.');
    after = drawn.match;
  }
  if (runtime.roundPlays[owner][targetLane] === 1 && effect.kind === 'feed-neighbors') {
    targetIds = after.boards.flat().filter(c => !c.hazard && c.owner === owner && c.lane !== targetLane).map(c => c.instanceId);
    note = district.name + ': served +' + effect.amount + ' Hands to ' + targetIds.length + ' allies in other lanes.';
    for (const id of targetIds) after = modify(after, id, c => ({ ...c, powerModifier: c.powerModifier + effect.amount, lastEffectNote: note }));
  }
  if (effect.kind === 'rush-hour' && runtime.roundPlays.player[targetLane] + runtime.roundPlays.cpu[targetLane] === 1) {
    targetIds = after.boards[targetLane].filter(c => c.instanceId !== instanceId).map(c => c.instanceId);
    const destination = lane((targetLane + 1) % 3);
    for (const id of targetIds) {
      const traveler = after.boards[targetLane].find(c => c.instanceId === id);
      if (traveler) after = move(after, traveler, destination, district.name + ': traffic pushed this card right.');
    }
    const moved = targetIds.filter(id => findCard(after, id)?.lane === destination).length;
    note = district.name + ': pushed ' + moved + ' cards right; ' + (targetIds.length - moved) + ' held in place.';
  }
  return note ? addEvent(match, after, { type: 'ability', owner, lane: targetLane, targetIds,
    kind: effect.kind === 'rush-hour' ? 'move' : 'story', note }) : after;
}
/** One deterministic ride, after the played card and its upgrades have resolved. */
function applyDistrictDeparture(match: Match, owner: Owner, instanceId: string, targetLane: Lane): Match {
  if (match.districtSnapshot?.locations[targetLane].effect.kind !== 'subway'
    || match.districtRuntime?.roundPlays[owner][targetLane] !== 1) return match;
  const card = match.boards[targetLane].find(c => c.instanceId === instanceId);
  if (!card) return match;
  const destination = lane((targetLane + 1) % 3);
  const after = move(match, card, destination, `THE SUBWAY: rode to ${match.districtSnapshot.locations[destination].name}.`);
  const moved = findCard(after, instanceId);
  // Arrival effects can defeat the rider. Keep their committed state and replay
  // events without inventing a final movement target for a card that is gone.
  if (!moved) return after;
  return addEvent(match, after, { type: 'ability', owner, lane: destination, targetIds: [instanceId],
    kind: moved.lane === destination ? 'move' : 'blocked', note: moved.lastEffectNote,
  });
}
export function playTurnCard(match: Match, owner: Owner, instanceId: string, targetLane: Lane, squabble = false, investment = 0): Match {
  return clearResolvedHandsAccounting(resolveSwookieRecruitment(resolveCardPlay(match, owner, instanceId, targetLane, squabble, false, investment)));
}

// playCard retains the original one-card turn for stored legacy transcripts.
function resolveCardPlay(match: Match, owner: Owner, instanceId: string, targetLane: Lane, squabble: boolean, endTurn: boolean, investment = 0): Match {
  if (![0, 1, 2].includes(targetLane)) throw new Error('Choose a valid district');
  if ((owner === 'player' && match.phase !== 'player') || (owner === 'cpu' && match.phase !== 'cpu-reveal')) throw new Error('Owner cannot play in this phase');
  const handKey = owner === 'player' ? 'playerHand' : 'cpuHand', motionKey = owner === 'player' ? 'playerMotion' : 'cpuMotion', card = match[handKey].find((c) => c.instanceId === instanceId);
  if (!card) throw new Error('Card is not in this hand');
  if (squabblehouseMovementLocked(match, card)) {
    throw new Error(`Pay Your Tab prevents redeployment through round ${card.squabblehouseCannotMoveThroughRound}`);
  }
  if (isMythicalTripleOg(card.cardId) && TRIPLE_OG_LANE[card.cardId] !== targetLane) {
    const side = TRIPLE_OG_LANE[card.cardId] === 0 ? 'left' : 'right';
    throw new Error(`${card.name} only sets up in the ${side} district`);
  }
  if (!isMythicalTripleOg(card.cardId) && getStoryLockedLanes(match, owner).includes(targetLane)) throw new Error('Lane is locked');
  if (card.cardId === 'sideofhands' && squabble) throw new Error('Support cards cannot use SQUABBLE');
  if (squabble && (match.squabbleByOwner ? match.squabbleByOwner[owner] : owner !== 'player' || match.squabbleUsed)) throw new Error('SQUABBLE is unavailable');
  const cost = getLegalCardCost(match, owner, card, targetLane);
  if (match[motionKey] < cost) throw new Error('Not enough Motion');
  const isDice = card.cardId === 'the-dice-game', isConcert = card.cardId === 'the-concert';
  if (!Number.isInteger(investment) || investment < 0 || investment > (isDice ? 3 : isConcert ? 1 : 4)
    || (investment > 0 && !isDice && !isConcert && (card.cardId !== 'homelessguy' || !activeAbility(card)))
    || blockbusterExtraCost(card.cardId, investment) > match[motionKey] - cost) throw new Error('Invalid extra Motion investment');
  if (isDice && (match[owner === 'player' ? 'cpuMotion' : 'playerMotion'] < (investment || 1))) throw new Error('Both sides need enough Motion for this wager');
  if (card.kind === 'blockbuster' && squabble) throw new Error('Blockbusters cannot use SQUABBLE');
  const discountLane = match.plugDiscountLane[owner];
  const usedToken = discountFor(match, owner, card, targetLane);
  const usedPlugDiscount = (!!usedToken && findCard(match, usedToken.sourceInstanceId)?.cardId === "plug")
    || (!usedToken && discountLane !== null && discountLane !== targetLane);
  const taxed = activeLandlord(match, owner, targetLane) && !(match.landlordTaxUsed?.[owner]?.[targetLane] ?? false);
  const taxState = match.landlordTaxUsed ?? { player: { 0: false, 1: false, 2: false }, cpu: { 0: false, 1: false, 2: false } };
  const arrivalOrder = nextArrivalOrder(match);
  let m: Match = {
    ...match,
    nextArrivalOrder: arrivalOrder + 1,
    [handKey]: match[handKey].filter((c) => c.instanceId !== instanceId),
    [motionKey]: match[motionKey] - cost,
    plugDiscountLane: { ...match.plugDiscountLane, [owner]: usedPlugDiscount ? null : discountLane },
    discountTokens: (match.discountTokens ?? []).filter((token) => token.id !== usedToken?.id),
    districtTraps: (match.districtTraps ?? []).filter(t => !(t.kind === 'dmv' && t.owner !== owner && t.lane === targetLane && t.expiresAfterRound >= match.round)),
    landlordTaxUsed: taxed ? { ...taxState, [owner]: { ...taxState[owner], [targetLane]: true } } : taxState,
    squabbleUsed: match.squabbleUsed || (owner === 'player' && squabble),
    ...(match.squabbleByOwner ? { squabbleByOwner: { ...match.squabbleByOwner, [owner]: match.squabbleByOwner[owner] || squabble } } : {}),
  };
  m = streetLegendsPaidAudit(m, owner, targetLane, card);
  if (card.kind === 'blockbuster') {
    const source = { ...card, lane: targetLane, playedRound: m.round };
    const staged = { ...m, boards: m.boards.map((cs,i) => i === targetLane ? [...cs,source] : cs) as Match['boards'] };
    m = addEvent(match, staged, { type: 'play', sourceId: instanceId, owner, lane: targetLane, note: `${card.name}: lane event played for ${cost} Motion.` });
    const beforeEffect = m;
    const resolved = resolveBlockbusterWave(m, source, investment, blockbusterTools());
    m = { ...resolved.match, boards: resolved.match.boards.map(cs => cs.filter(c => c.instanceId !== instanceId)) as Match['boards'],
      phase: endTurn ? owner === 'player' ? 'cpu-reveal' : 'resolved' : match.phase };
    m = settleLeaderReactions(m);
    m = musicAfterAction(match, creativeAfterAction(match,m,creativeTools()), waveTools());
    return applyStoryEffects(addEvent(beforeEffect, m, { type: 'ability', sourceId: instanceId, owner, lane: targetLane,
      targetIds: resolved.targets, note: resolved.note, kind: 'ability' }));
  }
  if (m.districtRuntime) {
    const runtime = m.districtRuntime;
    const plays = [...runtime.plays[owner]] as [number, number, number];
    const roundPlays = [...runtime.roundPlays[owner]] as [number, number, number];
    plays[targetLane]++; roundPlays[targetLane]++;
    m = { ...m, districtRuntime: { ...runtime, plays: { ...runtime.plays, [owner]: plays }, roundPlays: { ...runtime.roundPlays, [owner]: roundPlays } } };
  }
  let placed: CardInstance = { ...card, lane: targetLane, playedRound: m.round, arrivalOrder,
    rabbitReturnDiscount: false,
    powerModifier: card.powerModifier + (squabble ? card.basePower : 0),
    ...(card.cardId === 'buddy' ? {
      type: squabble ? 'Earth' : 'Plant',
      // Keep the legacy normal-form wire key; the actual normal element is Plant.
      buddyForm: squabble ? 'squabble-earth' as const : 'earth' as const,
      ...(squabble ? { buddyEarthExpiresAtRound: m.round + 2 } : {}),
    } : {}),
    lastEffectNote: squabble ? 'SQUABBLE doubled base Hands.' : `Played for ${cost} Motion.` };
  if (card.cardId === 'luigion') placed = { ...placed, luigionMushroomUsed: false };
  if (card.cardId === 'luigion' && squabble) placed = { ...placed, ...LUIGION_POWERED };
  if (card.cardId === 'homelessguy') placed = { ...placed, wildInvestment: investment, wildEmptyWallet: match[motionKey] === cost };
  m = reconcileContinuousPower({ ...m, boards: m.boards.map((items, i) => i === targetLane ? [...items, placed] : items) as Match['boards'] });
  {
    const activeBuddies = m.boards.flat().filter(buddy => buddy.instanceId !== instanceId && buddy.cardId === 'buddy'
      && buddy.buddyForm === 'squabble-earth' && (buddy.buddyEarthExpiresAtRound ?? 0) > m.round
      && !buddy.statuses.silenced && !buddy.statuses.frozen && !buddy.statuses.weakened);
    for (const buddy of activeBuddies) {
      const arrival = findCard(m, instanceId);
      if (arrival) m = applyBuddyEarthToTarget(m, buddy, arrival);
    }
  }
  if (taxed) {
    const landlord = m.boards[targetLane].find(c => c.owner !== owner && abilityCardId(c) === 'landlord' && activeAbility(c));
    if (landlord) m = modify(m, landlord.instanceId, c => ({ ...c, powerModifier: c.powerModifier + 1, lastEffectNote: 'Rent Due was paid: +1 Hand.' }));
  }
  if (usedToken?.eligibility === 'electric-delivery') m = modify(m, instanceId, c => ({
    ...c, powerModifier: c.powerModifier + 2, lastEffectNote: 'Express Delivery: Package received; +2 Hands.',
  }));
  if (usedToken?.bonusHandsOnUse) m = modify(m, instanceId, c => ({
    ...c, powerModifier: c.powerModifier + usedToken.bonusHandsOnUse!,
    lastEffectNote: ` ${usedToken.eligibility === "character-transfer" ? "Transfer Ticket" : "No Place Like Home"}: discounted deployment, +${usedToken.bonusHandsOnUse} Hands.`.trim(),
  }));
  m = addEvent(match, m, {
    type: 'play', sourceId: instanceId, owner, lane: targetLane,
    note: `${card.name} was played in district ${targetLane + 1} for ${cost} Motion.${usedToken ? ` ${usedToken.eligibility} discount used.` : ''}${taxed ? " Rent Due added 1 Motion." : ""}${squabble ? ' SQUABBLE doubled its base Hands.' : ''}`,
  });
  m = deadAirArrival(m, instanceId, targetLane);
  m = applyInitiationMark(m, instanceId, owner, targetLane);
  m = applySpinnerTrap(m, instanceId, targetLane);
  m = applyLookoutWatch(m, owner, targetLane);
  const nextBonus = m.blueNextBonus?.[owner] ?? 0;
  if (nextBonus > 0) {
    const beforeBonus = m;
    m = { ...m, blueNextBonus: { ...m.blueNextBonus, [owner]: 0 } };
    m = modify(m, instanceId, c => ({ ...c, powerModifier: c.powerModifier + nextBonus,
      lastEffectNote: `Measured Strike: inherited +${nextBonus} Hand${nextBonus === 1 ? '' : 's'}.` }));
    m = addEvent(beforeBonus, m, { type: 'ability', sourceId: instanceId, owner,
      targetIds: [instanceId], note: `Blue Big Trippin's last stand gave the next deployed card +${nextBonus} Hand${nextBonus === 1 ? '' : 's'}.` });
  }
  const cover = m.boards.flat().filter(c => c.owner === owner && c.cardId === 'blueside2'
    && c.instanceId !== instanceId && c.blueCoverReady && activeAbility(c))
    .sort((a, b) => (a.arrivalOrder ?? 0) - (b.arrivalOrder ?? 0) || a.instanceId.localeCompare(b.instanceId))[0];
  if (cover) {
    const beforeCover = m;
    m = modify(m, cover.instanceId, c => ({ ...c, blueCoverReady: false }));
    m = grantProtection(m, cover, instanceId);
    m = addEvent(beforeCover, m, { type: 'ability', sourceId: cover.instanceId, owner,
      targetIds: [instanceId], note: `Stand Behind Me protected the next deployed ally, ${card.name}.` });
  }
  if (usedToken?.eligibility === 'livewire-cross-district'
    && (placed.kind ?? 'character') === 'character' && !placed.hazard) {
    const beforeLivewireReward = m;
    m = modify(m, instanceId, c => ({ ...c, powerModifier: c.powerModifier + 1,
      lastEffectNote: 'Switch Carriers: discounted cross-district play, +1 Hand.' }));
    m = addEvent(beforeLivewireReward, m, { type: 'ability', sourceId: usedToken.sourceInstanceId,
      owner, targetIds: [instanceId], note: 'Switch Carriers gave its discounted character +1 Hand on placement.' });
  }
  m = addEvent(m, m, {
    type: 'reveal', sourceId: instanceId, owner, lane: targetLane,
    note: `${card.name} revealed in district ${targetLane + 1}.`,
  });
  m = applyDistrictArrival(m, owner, instanceId, targetLane);
  m = squabblehouseSecurityArrival(m, instanceId);
  m = squabblehouseManagerArrival(m, instanceId);
  m = streetLegendsArrival(m, instanceId, waveTools());
  m = recordElectricPlay(m, placed);
  m = homecomingArrival(fairytaleArrival(m, instanceId), instanceId, homecomingTools());
  m = applyScentEntry(m, instanceId);
  // STOCKZ compounds once per later friendly character play, in any district.
  // Permanent powerModifier carries these gains through every round.
  if ((card.kind ?? 'character') === 'character') {
    for (const investor of m.boards.flat().filter(c => !c.hazard && c.owner === owner && abilityCardId(c) === 'stockz'
      && c.instanceId !== instanceId && activeAbility(c))) {
      const beforeTrigger = m;
      m = modify(m, investor.instanceId, c => ({ ...c, powerModifier: c.powerModifier + 1, lastEffectNote: 'Compound Interest: +1 Hand.' }));
      m = addEvent(beforeTrigger, m, { type: 'ability', sourceId: investor.instanceId, owner, targetIds: [investor.instanceId], note: 'Compound Interest gained +1 Hand from a new friendly character.' });
    }
  }
  // Existing engines see a cheap arrival before its own ability resolves.
  if (cost <= 2) for (const streamer of m.boards.flat().filter((c) => !c.hazard && c.owner === owner && abilityCardId(c) === 'streamer' && activeAbility(c))) if (m.cheapBuffsUsed[owner] < 2) {
    const beforeTrigger = m;
    m = modify(m, placed.instanceId, (c) => ({ ...c, powerModifier: c.powerModifier + 1, lastEffectNote: 'Follower Frenzy: +1 Hands.' }));
    m = { ...m, cheapBuffsUsed: { ...m.cheapBuffsUsed, [owner]: m.cheapBuffsUsed[owner] + 1 } };
    m = addEvent(beforeTrigger, m, { type: 'ability', sourceId: streamer.instanceId, owner, targetIds: [placed.instanceId], note: 'Follower Frenzy gave the cheap play +1 Hands.' });
  }
  // Gamer moved from reactive Tryhard Trigger (cheap-play watch) to proactive City Tour On Reveal.
  // The reactive cheap-play hook was removed; resolveAbility now handles Gamer's branch directly.
  for (const boss of m.boards.flat().filter(c => !c.hazard && c.owner === owner && abilityCardId(c) === 'bossbabe'
    && c.lane !== targetLane && activeAbility(c) && (c.networkBoosts ?? 0) < 2)) {
    const beforeTrigger = m;
    const triggers = (boss.networkBoosts ?? 0) + 1;
    m = modify(m, boss.instanceId, c => ({ ...c, networkBoosts: triggers, powerModifier: c.powerModifier + 1,
      lastEffectNote: `Network Boost: +1 Hands (${triggers}/2).`,
    }));
    if (triggers === 2) m = addDiscountToken(m, owner, boss, 'printed-four-plus');
    m = addEvent(beforeTrigger, m, { type: 'ability', sourceId: boss.instanceId, owner, targetIds: [boss.instanceId],
      note: `Network Boost gained +1 Hands.${triggers === 2 ? ' Your next 4-Cost or higher card costs 1 less Motion.' : ''}`,
    });
  }
  const prediction = (m.districtTraps ?? []).find(t => t.kind === 'wiseman' && t.owner !== owner
    && t.expiresAfterRound >= m.round);
  if (prediction && !placed.hazard && (placed.kind ?? 'character') === 'character') {
    const beforePrediction = m;
    m = { ...m, districtTraps: m.districtTraps!.filter(t => t !== prediction) };
    m = addEvent(beforePrediction, m, { type: 'ability', sourceId: prediction.source.instanceId, owner: prediction.owner,
      lane: prediction.lane, targetIds: [instanceId], note: 'Told You consumed its public prediction.' });
    const beforePayoff = m;
    if (targetLane !== prediction.lane) {
      const order = m.nextDiscountOrder;
      m = { ...m, nextDiscountOrder: order + 1, discountTokens: [
        ...m.discountTokens.filter(t => !(t.eligibility === 'wiseman-prediction' && t.owner === prediction.owner && t.targetLane === prediction.lane)),
        { id: `wiseman:${prediction.source.instanceId}:${order}`, owner: prediction.owner,
          sourceInstanceId: prediction.source.instanceId, eligibility: 'wiseman-prediction', targetLane: prediction.lane,
          sourceLane: prediction.source.lane, createdOrder: order, expiresAfterRound: m.round + 1 },
      ] };
      m = addEvent(beforePayoff, m, { type: 'ability', sourceId: prediction.source.instanceId, owner: prediction.owner,
        lane: prediction.lane, targetIds: [], note: 'Told You: they dodged. Your next character in the predicted district costs 2 less Motion (minimum 1) through next round.' });
    } else {
      const actual = m.boards.flat().find(c => c.instanceId === instanceId);
      const eventCount = m.effectLog.length;
      if (actual) m = hostileEffect(m, prediction.source, actual, (state, target) =>
        queueDisruptionReactions(state, modify(state, target.instanceId, c => ({ ...c,
          statuses: { ...c.statuses, weakened: true }, lastEffectNote: 'Told You: predicted character Weakened.' })),
          prediction.source, target.instanceId), false, false, true);
      if (m.effectLog.length === eventCount) m = addEvent(beforePayoff, m, { type: 'ability', sourceId: prediction.source.instanceId,
        owner: prediction.owner, lane: prediction.lane, targetIds: actual ? [instanceId] : [],
        note: actual ? 'Told You: predicted character targeted with Weaken; Protection and immunity can block it.' : 'Told You: predicted character already left the board.' });
    }
  }
  const plateArrival = findCard(m, instanceId);
  if (plateArrival) m = selectedArrived(m, plateArrival, waveTools());
  let entranceOutcome: MusicEntranceOutcome = 'none';
  const revealed = m.boards.flat().find(c => c.instanceId === instanceId);
  if (revealed) {
    // Demario's Mushroom is a one-use lane resource for the next subsequently
    // played character.  Resolve it here, exactly once, before On Reveal; echoes
    // never pass through placement and therefore cannot consume it.
    if (!revealed.hazard && (revealed.kind ?? 'character') === 'character'
      && revealed.cardId !== 'luigion') {
      const mushroom = inLane(m, owner, targetLane).find(c => c.instanceId !== instanceId && c.cardId === 'demario-mushroom');
      if (mushroom) {
        const beforeMushroom = m;
        m = { ...m, boards: m.boards.map(items => items.filter(c => c.instanceId !== mushroom.instanceId)) as Match['boards'],
          timedEffects: m.timedEffects.filter(e => e.targetInstanceId !== mushroom.instanceId) };
        m = fairytaleDeparture(m, mushroom);
        m = modify(m, instanceId, c => ({ ...c, powerModifier: c.powerModifier + 2, lastEffectNote: 'Mushroom Delivery: consumed Mushroom, +2 Hands.' }));
        m = addEvent(beforeMushroom, m, { type: 'ability', sourceId: mushroom.instanceId, owner, lane: targetLane,
          targetIds: [instanceId, mushroom.instanceId], note: 'Mushroom Delivery: the next friendly character consumed a Mushroom for +2 Hands.' });
      }
    }
    if (findCard(m, instanceId)?.cardId === 'snow') m = resolveSwookieRecruitment(m, instanceId);
    const survivingReveal = findCard(m, instanceId);
    const trap = (m.districtTraps ?? []).find(t => t.kind === 'stakeout' && t.owner !== owner && t.lane === targetLane && t.expiresAfterRound >= m.round);
    const entrance = survivingReveal ? hasEntrance(survivingReveal) : false;
    if (survivingReveal && survivingReveal.owner !== owner) {
      entranceOutcome = 'cancelled';
    } else if (trap && survivingReveal && entrance) {
      entranceOutcome = 'cancelled';
      const beforeTrap = m;
      // Both watched districts share one case, not one cancellation per lane.
      m = { ...m, districtTraps: m.districtTraps!.filter(t => !(t.kind === 'stakeout'
        && t.owner === trap.owner && t.source.instanceId === trap.source.instanceId)) };
      m = modify(m, instanceId, c => ({ ...c, lastEffectNote: 'Stakeout canceled this entrance.' }));
      const detective = m.boards.flat().find(c => c.instanceId === trap.source.instanceId);
      const rewardedIds: string[] = [];
      if (detective && activeAbility(detective)) {
        const ally = lowest(m.boards.flat().filter(c => !c.hazard && c.owner === trap.owner
          && c.instanceId !== detective.instanceId && (c.kind ?? 'character') === 'character'));
        for (const target of [detective, ...(ally ? [ally] : [])]) {
          rewardedIds.push(target.instanceId);
          m = modify(m, target.instanceId, c => ({ ...c, powerModifier: c.powerModifier + 2,
            lastEffectNote: 'Stakeout canceled an entrance: +2 Hands.' }));
        }
      }
      m = addEvent(beforeTrap, m, { type: 'ability', sourceId: trap.source.instanceId, owner: trap.owner,
        targetIds: [instanceId, ...rewardedIds], note: 'Stakeout canceled ' + revealed.name + '’s entrance.'
          + (rewardedIds.length ? ` ${rewardedIds.length === 2 ? 'Sherlock and the weakest other friendly character gained' : 'Sherlock gained'} +2 Hands.` : '') });
    } else if (survivingReveal) {
      const queued = creativeBeforeEntrance(m, survivingReveal, creativeTools());
      m = queued.match;
      entranceOutcome = queued.delayed ? 'delayed' : 'resolved';
      const live = findCard(m, survivingReveal.instanceId);
      if (!queued.delayed && live) {
        m = resolveAbility(m, live);
        if (live.cardId === 'sideofhands' && findCard(m, live.instanceId)) {
          const beforeCleanup = m;
          const cleaned = {
            ...m,
            boards: m.boards.map(items => items.filter(card => card.instanceId !== live.instanceId)) as Match['boards'],
            timedEffects: m.timedEffects.filter(effect => effect.sourceInstanceId !== live.instanceId
              && effect.targetInstanceId !== live.instanceId),
          };
          m = addEvent(beforeCleanup, cleaned, { type: 'ability', sourceId: live.instanceId, owner,
            lane: targetLane, targetIds: [live.instanceId], note: 'A Side of Hands resolved and left the district.' });
        }
      }
    }
  }
  m = squabblehouseStaffWasPlayed(m, instanceId);
  m = undercovaReaction(m, match, instanceId, targetLane, owner);
  m = applyDistrictDeparture(m, owner, instanceId, targetLane);
  m = settleLeaderReactions(m);
  const opponent = owner === "player" ? "cpu" : "player";
  // Sneaker moved from reactive trigger (Flip Season on 4+ cost plays) to proactive On Reveal Steal.
  // The reactive logic was removed; resolveAbility now handles Sneaker's branch directly.
  m = creativeAfterPlay(match, m, instanceId, creativeTools(), placed);
  m = settleLeaderReactions(homecomingAfterPlay(m, placed, homecomingTools()));
  m = musicAfterPlay(match, m, instanceId, waveTools(), placed, entranceOutcome);
  const entranceSucceeded = entranceOutcome === 'resolved' && !!findCard(m, instanceId)?.creativeEntranceSucceeded;
  m = streetLegendsAfterPlay(match, m, instanceId, waveTools(), entranceSucceeded);
  m = musicAfterAction(match, m, waveTools());
  const finalized: Match = { ...m, phase: endTurn ? owner === 'player' ? 'cpu-reveal' : 'resolved' : match.phase };
  const lastEventIndex = finalized.effectLog.length - 1;
  return applyStoryEffects({
    ...finalized,
    effectLog: finalized.effectLog.map((event, index) => index === lastEventIndex
      ? { ...event, state: { ...event.state, after: roundState(finalized) }, replay: { ...event.replay, after: { ...event.replay.after, phase: finalized.phase } } }
      : event),
  });
}
export function pass(match: Match, owner: Owner): Match {
  if ((owner === 'player' && match.phase !== 'player') || (owner === 'cpu' && match.phase !== 'cpu-reveal')) throw new Error('Owner cannot pass in this phase');
  const after = { ...match, phase: owner === 'player' ? 'cpu-reveal' as const : 'resolved' as const };
  return addEvent(match, after, { type: 'pass', owner, note: `${owner} passed.` });
}
export type RivalIntent = {
  style: string;
  tell: string;
  likelyLane: Lane | null;
};
const rivalStyle = (deckId: string) => decks.find((deck) => deck.id === deckId)?.archetype ?? "Adaptive";
export function getRivalIntent(match: Match): RivalIntent {
  const legal = match.cpuHand.flatMap((card) => ([0, 1, 2] as Lane[])
    .filter((target) => canAffordSelection(match, "cpu", card.instanceId, target))
    .map((target) => ({ card, lane: target })));
  if (!legal.length) return { style: rivalStyle(match.cpuDeck), tell: "Short on Motion — likely to pass and preserve a card.", likelyLane: null };
  const results = getDistrictResults(match);
  const style = rivalStyle(match.cpuDeck);
  const laneScores = ([0, 1, 2] as Lane[]).map((target) => {
    const result = results[target];
    const districtFit = Math.max(...legal.filter((option) => option.lane === target).map((option) => getDistrictCardBonusForMatch(match, option.card, target, [...inLane(match, "cpu", target), option.card])));
    const pressure = result.winner === "player" ? 3 : result.winner === "draw" ? 2 : 0;
    const styleBias = style.includes("Movement") && target === (match.round % 3) ? 2
      : style.includes("Comeback") && result.winner === "player" ? 2
      : style.includes("Control") && result.winner !== "cpu" ? 1
      : 0;
    return { lane: target, score: pressure + districtFit + styleBias };
  }).sort((a, b) => b.score - a.score || ((a.lane + match.round) % 3) - ((b.lane + match.round) % 3));
  const likelyLane = laneScores[0].lane;
  const laneName = getMatchDistricts(match)[likelyLane].name;
  const tell = style.includes("Comeback") ? `Likes trailing districts; pressure points toward ${laneName}.`
    : style.includes("Movement") ? `Spreads early, then shifts Hands; activity points toward ${laneName}.`
    : style.includes("Disruption") || style.includes("Control") ? `Targets contested engines; watch ${laneName}.`
    : style.includes("Combo") || style.includes("Growth") ? `Builds cheap chains before a late spike; setup points toward ${laneName}.`
    : `Balances district bonuses and open lanes; watch ${laneName}.`;
  return { style, tell, likelyLane };
}
export function chooseCpuPlay(match: Match, lookAhead = true): { instanceId: string; lane: Lane; investment: number; squabble: boolean } | null {
  if (match.phase !== "cpu-reveal") return null;
  // Current own hand is known; opposing cards and either unseen draw order are not.
  match = suppressMatchPresentationEvents({ ...match, playerHand: [], playerCardIds: [], playerDrawIndex: 0, cpuCardIds: [], cpuDrawIndex: 0 });
  const hand = new Map(match.cpuHand.map(card => [card.instanceId, card]));
  const options = listLegalPlayIntents(match, 'cpu').map(option => ({ ...option, card: hand.get(option.instanceId)! }));
  if (!options.length) return null;
  // Resolve each candidate through the real rules, including movement, cleansing,
  // protection, upgrades and story effects. Never reward an existing stack itself.
  const value = (resolved: Match) => {
    const board = match.round === getMatchRoundLimit(match) ? nextRound(resolved) : resolved;
    const results = getDistrictResults(board);
    const control = results.reduce((sum, r) => sum + (r.winner === "cpu" ? 1 : r.winner === "player" ? -1 : 0), 0);
    const margins = results.reduce((sum, r) => {
      const lead = r.cpu - r.player;
      // Diminishing returns: contestable districts matter more than overkill.
      return sum + 12 * lead / (4 + Math.abs(lead));
    }, 0);
    const winner = getMatchWinner(board);
    const finish = board.phase === "complete" ? (winner === "cpu" ? 1000 : winner === "player" ? -1000 : 0) : 0;
    const style = match.storyEncounter?.enemy.behaviorProfile ?? rivalStyle(match.cpuDeck);
    const active = board.boards.flat().filter(c => !c.hazard && c.owner === 'cpu' && !c.statuses.frozen && !c.statuses.silenced);
    const cheap = board.cpuHand.filter(c => c.cost <= 2).length;
    const setup = board.round < getMatchRoundLimit(board) ? active.reduce((sum, c) => sum
      + (abilityCardId(c) === 'streamer' ? Math.min(Math.max(0, 2 - board.cheapBuffsUsed.cpu), cheap) : abilityCardId(c) === 'bossbabe' ? Math.max(0, 2 - (c.networkBoosts ?? 0)) : 0)
      + (c.statuses.protected ? 0.7 : 0), 0) + Math.min(2, board.discountTokens.filter(t => t.owner === 'cpu').length) : 0;
    const styleValue = /movement|Movement/.test(style) ? board.boards.filter(items => items.some(c => c.owner === 'cpu')).length * 0.7
      : /support|Growth|combo/.test(style) ? setup * 0.7
      : /control|Control|reactive/.test(style) ? board.boards.flat().filter(c => !c.hazard && c.owner === 'player' && (c.statuses.frozen || c.statuses.silenced)).length * 0.7
      : /pressure|aggressive/.test(style) ? results.filter(r => r.winner === 'cpu').length * 0.7 : 0;
    return finish + control * 15 + margins + setup + styleValue;
  };
  const ranked = options.map(option => {
    const resolved = playCard(match, 'cpu', option.card.instanceId, option.lane, option.squabble, option.investment);
    return { ...option, resolved, score: value(resolved) };
  });
  const passed = pass(match, 'cpu');
  const candidates = [...ranked, { card: null, lane: 0 as Lane, cost: 0, investment: 0, squabble: false, resolved: passed, score: value(passed) }];
  candidates.sort((a, b) => b.score - a.score);
  // A bounded second turn values setup and saving removal. The opponent's private
  // hand is never read: this is an optimistic own-turn plan, weighted below now.
  if (lookAhead && match.round < getMatchRoundLimit(match)) for (const candidate of candidates.slice(0, 4)) {
    const future = pass(nextRound(candidate.resolved), 'player');
    const choice = chooseCpuPlay(future, false);
    const after = choice ? playCard(future, 'cpu', choice.instanceId, choice.lane, choice.squabble, choice.investment) : pass(future, 'cpu');
    candidate.score += 0.35 * (value(after) - value(candidate.resolved));
  }
  candidates.sort((a, b) => b.score - a.score || a.cost - b.cost || Number(a.squabble) - Number(b.squabble)
    || (a.card?.instanceId ?? '').localeCompare(b.card?.instanceId ?? '')
    || ((a.lane + match.round) % 3) - ((b.lane + match.round) % 3));
  const best = candidates[0];
  return best.card ? { instanceId: best.card.instanceId, lane: best.lane, investment: best.investment, squabble: best.squabble } : null;
}
export function revealCpu(match: Match): Match { const choice = chooseCpuPlay(match); return choice ? playCard(match, 'cpu', choice.instanceId, choice.lane, choice.squabble, choice.investment) : pass(match, 'cpu'); }
/** Resolve the rival's whole turn with the same per-card Motion budget. */
export function revealCpuTurn(match: Match): Match {
  if (match.phase !== 'cpu-reveal') throw new Error('It is not The Opps’ turn');
  let next = match;
  while (true) {
    const choice = chooseCpuPlay(next);
    if (!choice) return pass(next, 'cpu');
    next = playTurnCard(next, 'cpu', choice.instanceId, choice.lane, choice.squabble, choice.investment);
  }
}
function applyDistrictRoundStart(match: Match): Match {
  let m = match;
  for (const [index, district] of (match.districtSnapshot?.locations ?? []).entries()) {
    const effect = district.effect, targetLane = index as Lane;
    if (effect.kind !== 'round-growth' && !(effect.kind === 'flood' && match.round === effect.atRound)) continue;
    const before = m, targetIds = m.boards[targetLane].map(c => c.instanceId);
    let note = '';
    if (effect.kind === 'round-growth') {
      note = district.name + ': every card here gained +' + effect.amount + ' permanent Hands.';
      for (const id of targetIds) m = modify(m, id, c => ({ ...c, powerModifier: c.powerModifier + effect.amount, lastEffectNote: note }));
    } else {
      const destination = lane((targetLane + 1) % 3);
      for (const id of targetIds) {
        const traveler = m.boards[targetLane].find(c => c.instanceId === id);
        if (traveler) m = move(m, traveler, destination, district.name + ': the flood carried this card right.');
      }
      const moved = targetIds.filter(id => findCard(m, id)?.lane === destination).length;
      note = district.name + ': flood moved ' + moved + ' cards right; ' + (targetIds.length - moved) + ' held in place.';
    }
    m = addEvent(before, m, { type: 'ability', owner: 'player', lane: targetLane, targetIds,
      kind: effect.kind === 'flood' ? 'move' : 'story', note });
  }
  return m;
}

/** Stable random draws let solo verification and persisted multiplayer rooms replay identically. */
const seededIndex = (seed: string, count: number): number => {
  let hash = 2166136261;
  for (let i = 0; i < seed.length; i++) hash = Math.imul(hash ^ seed.charCodeAt(i), 16777619);
  hash = Math.imul(hash ^ (hash >>> 16), 0x85ebca6b);
  hash = Math.imul(hash ^ (hash >>> 13), 0xc2b2ae35);
  return ((hash ^ (hash >>> 16)) >>> 0) % count;
};
function plantDemarioMushroom(m: Match, source: CardInstance, draw: number, log: boolean): { match: Match; token?: CardInstance } {
  const lanes = ([0, 1, 2] as Lane[]).filter(lane =>
    inLane(m, source.owner, lane).length < 4 && !getStoryLockedLanes(m, source.owner).includes(lane));
  if (!lanes.length) return { match: m };
  const seed = JSON.stringify(['demario-mushroom', source.instanceId, source.owner, m.round, draw,
    m.nextEventSequence, m.boards.map(items => items.map(card => card.instanceId)), m.districtSnapshot]);
  const lane = lanes[seededIndex(seed, lanes.length)];
  const before = m;
  m = summonCard(m, source.owner, lane, DEMARIO_MUSHROOM, 'demario-mushroom', source);
  const token = m.boards[lane].at(-1)!;
  if (log) m = addEvent(before, m, { type: 'ability', sourceId: source.instanceId, owner: source.owner,
    lane, targetIds: [token.instanceId], note: `Special Delivery: Mushroom sprouted in district ${lane + 1} while Demario was in hand.` });
  m = fairytaleArrival(m, token.instanceId);
  m = applyScentEntry(m, token.instanceId);
  return { match: m, token };
}
function spawnHandDemarioMushrooms(match: Match, log: boolean): Match {
  let m = match;
  for (const owner of ['player', 'cpu'] as Owner[]) {
    const source = (owner === 'player' ? m.playerHand : m.cpuHand)
      .find(card => card.cardId === 'demario' && activeAbility(card));
    if (source) m = plantDemarioMushroom(m, source, 0, log).match;
  }
  return m;
}
const smileBombSeed = (match: Match, id: string, draw: number) =>
  JSON.stringify([id, draw, match.round, match.nextEventSequence, match.districtSnapshot,
    match.boards.map(lane => lane.map(card => [card.instanceId, rawCombatPower(card)]))]);

const buddySeed = (match: Match, source: CardInstance) => JSON.stringify([
  'buddy-buds', source.instanceId, match.round,
  match.boards.map(lane => lane.map(card => card.instanceId).sort()),
  match.districtSnapshot,
]);

const buddyTimedEffect = (match: Match, source: CardInstance, target: CardInstance, amount: number): Match => {
  const expiresAtRound = source.buddyEarthExpiresAtRound ?? match.round + 2;
  const effect: TimedEffect = {
    id: `buddy-earth:${source.instanceId}:${target.instanceId}:${match.round}:${amount}`,
    kind: amount > 0 ? 'buddy-earth-buff' : 'buddy-earth-debuff',
    sourceInstanceId: source.instanceId,
    targetInstanceId: target.instanceId,
    owner: source.owner,
    lane: target.lane ?? source.lane!,
    startsAtRound: match.round,
    expiresAtRound,
    expiration: 'round-start',
    amount,
  };
  return { ...match, timedEffects: [...match.timedEffects.filter(item => item.id !== effect.id), effect] };
};

const applyBuddyEarthToTarget = (match: Match, source: CardInstance, target: CardInstance): Match => {
  if (target.hazard || target.owner === source.owner && canonicalElement(target.type) !== 'Earth') return match;
  if (target.owner === source.owner) {
    const before = findCard(match, target.instanceId);
    if (!before) return match;
    const after = modify(match, target.instanceId, card => ({
      ...card, powerModifier: card.powerModifier + 2, lastEffectNote: 'Earth Squabble: +2 Hands for two rounds.',
    }));
    return buddyTimedEffect(after, source, findCard(after, target.instanceId)!, 2);
  }
  const before = findCard(match, target.instanceId);
  if (!before) return match;
  const after = targetEnemyPowerReduction(match, source, before, -1, 'Earth Squabble: -1 Hand for two rounds.');
  const changed = findCard(after, target.instanceId);
  if (!changed || directDamageAmount(match, after, before) <= 0) return after;
  return buddyTimedEffect(after, source, changed, -1);
};

const applyBuddyEarthToBoard = (match: Match, source: CardInstance): Match => {
  let result = match;
  const targets = result.boards.flat().sort((a, b) => a.instanceId.localeCompare(b.instanceId));
  for (const target of targets) {
    const currentSource = findCard(result, source.instanceId);
    const currentTarget = findCard(result, target.instanceId);
    if (currentSource && currentTarget) result = applyBuddyEarthToTarget(result, currentSource, currentTarget);
  }
  return result;
};

const plantBuddyBuds = (match: Match, source: CardInstance): Match => {
  const sproutsAtRound = match.round + 2;
  const seed = buddySeed(match, source);
  let result = modify(match, source.instanceId, card => ({
    ...card, buddyForm: 'earth', buddyGrowthAtRound: sproutsAtRound,
    lastEffectNote: `Buddy Buds: +3 Hands and Buds sprout after two rounds (Round ${sproutsAtRound}).`,
  }));
  // A Bud can sprout on the final round's start and reward cards already there,
  // but one scheduled beyond the match limit would never have a payoff.
  if (sproutsAtRound > getMatchRoundLimit(match)) return modify(result, source.instanceId, card => ({
    ...card, lastEffectNote: `Buddy Bud planting skipped: they would sprout after the match ends (delayed +3 Hands in Round ${sproutsAtRound}).`,
  }));
  const eligible = ([0, 1, 2] as Lane[]).filter(laneIndex =>
    !getStoryLockedLanes(result, source.owner).includes(laneIndex) && inLane(result, source.owner, laneIndex).length < 4);
  if (!eligible.length) return modify(result, source.instanceId, card => ({
    ...card, lastEffectNote: `Buddy Bud planting skipped: all districts are full or locked (delayed +3 Hands in Round ${sproutsAtRound}).`,
  }));
  const wanted = Math.min(eligible.length, 2 + seededIndex(`${seed}:count`, 2));
  const selected: Lane[] = [];
  let remaining = [...eligible];
  while (selected.length < wanted) {
    const index = seededIndex(`${seed}:lane:${selected.length}`, remaining.length);
    selected.push(remaining[index]);
    remaining = remaining.filter((_, candidate) => candidate !== index);
  }
  for (const laneIndex of selected) {
    const template = createCardInstance('rastamon', source.owner, 'buddy-bud', 0);
    const arrivalOrder = nextArrivalOrder(result);
    const bud: CardInstance = {
      ...template, id: 'buddy-bud', cardId: 'buddy-bud', name: 'Buddy Bud', type: 'Plant',
      cost: 0, power: 0, basePower: 0, powerModifier: 0, ability: 'Buddy Bud',
      effect: `Sprouts in Round ${sproutsAtRound}; the last eligible friendly character here gains +3 Hands.`,
      abilityUpgrades: [], kind: 'token', hazard: true, lane: laneIndex, playedRound: match.round, arrivalOrder,
      instanceId: `${source.instanceId}:bud:${match.round}:${laneIndex}`,
      buddyBud: { sourceInstanceId: source.instanceId, sproutsAtRound, sprouted: false },
      lastEffectNote: `Dormant Buddy Bud · sprouts in Round ${sproutsAtRound}.`,
    };
    result = { ...result, nextArrivalOrder: arrivalOrder + 1, boards: result.boards.map((cardsInLane, index) =>
      index === laneIndex ? [...cardsInLane, bud] : cardsInLane) as Match['boards'] };
  }
  return modify(result, source.instanceId, card => ({
    ...card, lastEffectNote: `Buddy Buds: planted ${selected.length} Bud${selected.length === 1 ? '' : 's'}; they sprout in Round ${sproutsAtRound}.`,
  }));
};

const sproutBuddyBuds = (match: Match): Match => {
  let result = match;
  for (const bud of match.boards.flat().filter(card => card.buddyBud && !card.buddyBud.sprouted
    && card.buddyBud.sproutsAtRound <= match.round)) {
    const currentBud = findCard(result, bud.instanceId);
    if (!currentBud || currentBud.lane === null) continue;
    const eligibleRecipients = result.boards[currentBud.lane].filter(card =>
      card.owner === currentBud.owner && !card.hazard && card.instanceId !== currentBud.instanceId
      && (card.kind ?? 'character') !== 'support');
    const recipient = eligibleRecipients.reduce<CardInstance | undefined>((last, card) =>
      !last || (card.arrivalOrder ?? -1) >= (last.arrivalOrder ?? -1) ? card : last, undefined);
    const beforeSprout = result;
    result = modify(result, bud.instanceId, card => ({
      ...card,
      buddyBud: { ...card.buddyBud!, sprouted: true },
      effect: 'Sprouted Buddy Bud: the last eligible friendly character in this district gains +3 Hands.',
      lastEffectNote: recipient
        ? `Buddy Bud sprouted · ${recipient.name} is the last eligible recipient.`
        : 'Buddy Bud sprouted without an eligible friendly recipient.',
    }));
    if (recipient) {
      result = modify(result, recipient.instanceId, card => ({
        ...card, powerModifier: card.powerModifier + 3,
        lastEffectNote: 'Buddy Bud sprouted: +3 Hands as the last eligible character in this district.',
      }));
      result = { ...result, boards: result.boards.map(cardsInLane =>
        cardsInLane.filter(card => card.instanceId !== bud.instanceId)) as Match['boards'] };
      result = addEvent(beforeSprout, result, { type: 'ability', sourceId: bud.buddyBud!.sourceInstanceId,
        owner: bud.owner, lane: bud.lane!, targetIds: [recipient.instanceId, bud.instanceId],
        note: `Buddy Bud sprouted and gave ${recipient.name} +3 Hands as the last eligible character in the district.` });
    }
  }
  return result;
};

const resolveBuddyGrowthAtRoundStart = (match: Match): Match => {
  let result = match;
  for (const buddy of match.boards.flat().filter(card => card.cardId === 'buddy'
    && card.buddyForm === 'earth' && card.buddyGrowthAtRound !== undefined
    && card.buddyGrowthAtRound <= match.round)) {
    const beforeGrowth = result;
    result = modify(result, buddy.instanceId, card => ({
      ...card, powerModifier: card.powerModifier + 3, buddyGrowthAtRound: undefined,
      lastEffectNote: 'Buddy Buds: delayed growth +3 Hands at the start of this round.',
    }));
    result = addEvent(beforeGrowth, result, { type: 'ability', sourceId: buddy.instanceId, owner: buddy.owner,
      lane: buddy.lane ?? undefined, targetIds: [buddy.instanceId],
      note: `Buddy Buds: BUDDY gained +3 Hands at the start of Round ${match.round}, after two rounds.` });
  }
  return result;
};

function detonateSmileBombs(match: Match): Match {
  let m = match;
  // A stable order also gives multiple KYLEs independent, reproducible kill credit.
  const due = m.boards.flat().filter(card => card.smileBomb && card.smileBomb.detonatesAtRound <= m.round)
    .sort((a, b) => a.instanceId.localeCompare(b.instanceId));
  for (const scheduled of due) {
    const bomb = findCard(m, scheduled.instanceId);
    if (!bomb?.smileBomb || bomb.lane === null) continue;
    const before = m, payload = bomb.smileBomb;
    const enemies = inLane(m, payload.sourceOwner === 'player' ? 'cpu' : 'player', bomb.lane)
      .filter(card => card.kind !== 'support').sort((a, b) => a.instanceId.localeCompare(b.instanceId));
    const target = enemies.length ? enemies[seededIndex(smileBombSeed(m, bomb.instanceId, 0), enemies.length)] : undefined;
    const source = findCard(m, payload.sourceInstanceId);
    // Always consume the fuse, even if the lane emptied or KYLE left the board.
    m = { ...m, boards: m.boards.map(lane => lane.filter(card => card.instanceId !== bomb.instanceId)) as Match['boards'] };
    let killed = false;
    let damaged = false;
    let reward = 0;
    if (target) {
      m = targetEnemyPowerReduction(m, source ?? { ...bomb, owner: payload.sourceOwner }, target, -2, 'Smile Bomb: -2 Hands.');
      killed = !findCard(m, target.instanceId);
      damaged = directDamageAmount(before, m, target) > 0;
      if (damaged && source && source.owner === payload.sourceOwner && source.lane !== null) {
        reward = killed ? 2 : 1;
        m = modify(m, source.instanceId, card => ({ ...card, powerModifier: card.powerModifier + reward,
          lastEffectNote: killed ? 'Smile Bomb knockout: +2 Hands.' : 'Smile Bomb hit: +1 Hands.' }));
      }
    }
    m = addEvent(before, m, { type: 'ability', sourceId: source?.instanceId, owner: payload.sourceOwner,
      lane: bomb.lane, kind: damaged ? 'fire' : 'blocked', targetIds: [bomb.instanceId, ...(target ? [target.instanceId] : [])],
      note: target ? damaged
        ? 'Smile Bomb hit ' + target.name + ' for -2 Hands.' + (reward ? ' KYLE gained +' + reward + ' Hands' + (killed ? ' for the knockout.' : '.') : '')
        : target.name + ' blocked the Smile Bomb.'
        : 'Smile Bomb fizzled: no enemy in its district.',
    });
    m = settleLeaderReactions(m);
  }
  return m;
}

/** A bounded policy forecast of existing public fuses, not a predicted future turn.
 * Keeps the current board/shields and resolves only bombs due at the next round;
 * callers discount this estimate because opponents may move or remove targets. */
export function previewPendingSmileBombs(match: Match): Match {
  const next = match.round + 1;
  if (match.phase === 'complete' || next > getMatchRoundLimit(match)
    || !match.boards.some(lane => lane.some(card => card.smileBomb && card.smileBomb.detonatesAtRound <= next))) return match;
  return detonateSmileBombs(suppressMatchPresentationEvents({ ...match, round: next,
    playerHand: [], cpuHand: [], playerCardIds: [], cpuCardIds: [], playerDrawIndex: 0, cpuDrawIndex: 0 }));
}

export function nextRound(match: Match, onRoundSettled?: (settled: Match) => Match | void): Match {
  const settled = settleNextRound(match, onRoundSettled);
  return clearResolvedHandsAccounting(settled.phase === 'complete' ? settled
    : resolveSwookieRecruitment(resolveRainmakerIncome(settled)));
}

function settleNextRound(match: Match, onRoundSettled?: (settled: Match) => Match | void): Match {
  if (match.phase !== 'resolved') throw new Error('Round is not resolved');
  // Resolve persistent statuses and hand bonds before either advancing or scoring.
  const trainedRoundEnd = musicRoundEnd(match, waveTools());
  const ordinaryRoundEnd = settleLeaderReactions(returnAliceAtRoundEnd(applyOngoingRoundEndHandEffects(applyOngoingRoundEndEffects(creativeRoundEnd(homecomingRoundEnd(applyBurntPlates(trainedRoundEnd), homecomingTools()), creativeTools())))));
  let roundEnded = maryMackRoundEnd(settleLeaderReactions(musicAfterAction(match, creativeAfterAction(match,ordinaryRoundEnd,creativeTools()), waveTools())), waveTools());
  const boundaryUpdate = onRoundSettled?.(roundEnded);
  if (boundaryUpdate) roundEnded = boundaryUpdate;
  if (match.round >= getMatchRoundLimit(match)) {
    const complete = applyStoryEffects({ ...roundEnded, phase: 'complete' as const });
    return addEvent(match, complete, { type: 'match-complete', owner: 'player', note: 'The match is complete.' });
  }
  const next = match.round + 1;
  const expiring = roundEnded.timedEffects.filter((effect) => effect.expiresAtRound === next);
  let m: Match = {
    ...roundEnded,
    districtTraps: (roundEnded.districtTraps ?? []).filter(trap =>
      trap.kind !== 'open-tab' || trap.expiresAfterRound >= next),
    lastRevealedCardId: null,
    laneDamage: [],
    roundMovedIds: { player: [], cpu: [] },
    round: next,
    phase: 'player',
    // One unspent Motion carries forward. Passing can set up a stronger next
    // round, but the cap prevents late turns from becoming automatic.
    playerMotion: Math.min(MAX_MOTION, next + Math.min(1, roundEnded.playerMotion)),
    cpuMotion: Math.min(MAX_MOTION, next + Math.min(1, roundEnded.cpuMotion)),
    landlordTaxUsed: { player: { 0: false, 1: false, 2: false }, cpu: { 0: false, 1: false, 2: false } },
    boards: roundEnded.boards.map((items) => items.map((card) => ({
      ...card,
      statuses: { ...card.statuses, blocked: false },
    }))) as Match['boards'],
  };
  for (const effect of expiring) {
    const beforeExpiration = m.nextEventSequence === match.nextEventSequence ? match : m;
    let afterExpiration = m;
    if (effect.kind === 'buddy-earth-buff' || effect.kind === 'buddy-earth-debuff') {
      const target = effect.targetInstanceId ? findCard(m, effect.targetInstanceId) : undefined;
      if (target) afterExpiration = modify(m, target.instanceId, card => ({
        ...card, powerModifier: card.powerModifier - (effect.amount ?? 0),
        lastEffectNote: 'Earth Squabble expired after two rounds.',
      }));
      // Expiring a temporary buff is not damage for Block Spin.
      afterExpiration = { ...afterExpiration, laneDamage: m.laneDamage };
    } else {
      afterExpiration = modify(m, effect.sourceInstanceId, (card) => ({
        ...card,
        statuses: { ...card.statuses, protected: m.timedEffects.some(active => active.kind === 'salon-protection' && active.targetInstanceId === card.instanceId), blocked: false },
      }));
    }
    afterExpiration = {
      ...afterExpiration,
      timedEffects: afterExpiration.timedEffects.filter((active) => active.id !== effect.id),
    };
    m = addEvent(beforeExpiration, afterExpiration, {
      type: 'expiration', sourceId: effect.sourceInstanceId, owner: effect.owner, targetIds: [effect.sourceInstanceId],
      note: effect.kind === 'buddy-earth-buff' || effect.kind === 'buddy-earth-debuff'
        ? 'Earth Squabble Hands modifier expired after two rounds.'
        : 'Side Eye protection expired at the round boundary.',
      kind: effect.kind === 'buddy-earth-buff' || effect.kind === 'buddy-earth-debuff' ? 'ability' : 'blocked',
    });
  }
  const beforeRoundStart = expiring.length ? m : match;
  const playerDraw = drawDeckCard(m, 'player');
  const cpuDraw = drawDeckCard(playerDraw.match, 'cpu');
  const p = playerDraw.card, c = cpuDraw.card;
  m = cpuDraw.match;
  m = musicRoundStart(streetLegendsRoundStart(creativeRoundStart(m, creativeTools()), waveTools()), waveTools());
  m = resolveBuddyGrowthAtRoundStart(m);
  m = sproutBuddyBuds(m);
  m = resolveSquabblehouseRoundStart(m);
  m = maryMackRoundStart(m, waveTools());
  for (const lookout of m.boards.flat().filter(card => card.cardId === 'look-out' && activeAbility(card)
    && (card.lookoutCalls ?? 0) < 3 && card.lookoutCallRound !== m.round)) {
    const hasCrew = m.boards.flat().some(card => !card.hazard && card.owner === lookout.owner
      && card.instanceId !== lookout.instanceId && (card.gangTag ?? GANG_BY_CARD_ID[card.cardId]) === 'blue');
    if (hasCrew) m = modify(m, lookout.instanceId, card => ({ ...card, lookoutReady: true,
      lastEffectNote: 'On Point: Blue Set is posted; watching again this round.' }));
  }
  const guards = m.boards.flat().filter((card) => abilityCardId(card) === 'wifey' && activeAbility(card));
  for (const guard of guards) {
    m = modify(m, guard.instanceId, (card) => ({ ...card, statuses: { ...card.statuses, protected: true, blocked: false }, lastEffectNote: 'Side Eye refreshed for this round.' }));
    m = { ...m, timedEffects: [...m.timedEffects, {
      id: `wifey:${guard.instanceId}:${next}`, kind: 'wifey-protection', sourceInstanceId: guard.instanceId,
      owner: guard.owner, lane: guard.lane!, startsAtRound: next, expiresAtRound: next + 1, expiration: 'round-start',
    }] };
  }
  m = addEvent(beforeRoundStart, m, {
    type: 'round-start', owner: 'player',
    targetIds: [...guards.map((guard) => guard.instanceId), ...(p ? [p.instanceId] : []), ...(c ? [c.instanceId] : [])],
    timing: guards.length ? 'timed' : 'instant',
    duration: guards.length ? { unit: 'round', startsAtRound: next, expiresAtRound: next + 1, expiration: 'round-start' } : null,
    note: `Round ${next} started.`,
  });
  if (m.boards.flat().some(card => (card.cardId === 'squabblehouse-bus-boy' || abilityCardId(card) === 'icecream')
    && card.lane !== null && activeAbility(card))) {
    // Settle new-round story locks before either character chooses an automatic route.
    m = applyStoryEffects(m, true);
    m = creativeAutomaticRoutes(m, creativeTools());
    m = resolveSquabblehouseBusBoyPatrols(m);
  }
  m = detonateSmileBombs(m);
  m = applyStoryEffects(m);
  m = spawnHandDemarioMushrooms(m, true);
  m = applyStoryEffects(m);
  for (const candidate of m.boards.flat().filter(card => card.cardId === 'redside2')) {
    const red = findCard(m, candidate.instanceId);
    if (!red || red.lane === null || !activeAbility(red) || red.redNightStartRound === undefined) continue;
    const beforeSteal = m;
    const steal = resolveRedNightSteal(m, red);
    if (steal.match === m) continue;
    m = steal.match;
    if (steal.succeeded) m = trainWaveAbility(m, red.instanceId);
    m = addEvent(beforeSteal, m, { type: 'ability', sourceId: red.instanceId, owner: red.owner,
      lane: red.lane, targetIds: steal.targetIds, note: steal.note });
  }
  for (const candidate of m.boards.flat().filter(card => card.cardId === 'blueside3')) {
    const scarf = findCard(m, candidate.instanceId);
    if (!scarf || !activeAbility(scarf) || scarf.lane === null) continue;
    const beforeScarf = m;
    const routed = clearBlueScarfRoute(m, scarf);
    m = routed.match;
    if (routed.moved) m = trainWaveAbility(m, scarf.instanceId);
    m = addEvent(beforeScarf, m, { type: 'ability', sourceId: scarf.instanceId, owner: scarf.owner,
      lane: scarf.lane, targetIds: routed.targetIds, note: routed.note });
  }
  if (!m.districtRuntime) return m;
  m = settleLeaderReactions(applyDistrictRoundStart(m));
  const refreshed = refreshDistrictRound(m);
  const party = m.districtSnapshot!.locations.find(d => d.effect.kind === 'penthouse' && d.effect.changesAtRound === next);
  return addEvent(m, refreshed, { type: 'ability', owner: 'player', kind: 'story',
    note: party ? 'PENTHOUSE: the party starts. Each card here now has +1 Hands instead of the solo bonus.' : `District bonuses refreshed for round ${next}.`,
    lane: party ? m.districtSnapshot!.locations.indexOf(party) as Lane : 0,
  });
}
/**
 * The replay payload accepted by the reward service.  Keep this alongside the
 * structured event stream so the same deterministic rules author both the
 * presentation and the server-verifiable transcript.
 */
export type PlayerMove = {
  cardInstanceId: string | null;
  lane: Lane | null;
  squabble: boolean;
  /** Explicit on new matches; absent only on legacy one-card turns. */
  endTurn?: boolean;
  /** Numeric card choice: Homeless Guy investment, Dice Game wager, or Concert mode. */
  investment?: number;
};
export type TranscriptMove = Omit<PlayerMove, 'lane'> & { lane: number | null };
export const MAX_MATCH_MOVES = 64;

/** Pick a legal teaching move. Spread winning Hands across the districts. */
export function getTutorialPlay(match: Match): { instanceId: string; lane: Lane } | null {
  if (match.phase !== "player") return null;
  let best: { instanceId: string; lane: Lane; value: number } | null = null;
  for (const card of match.playerHand) for (const lane of [0, 1, 2] as const) {
    if (!canAffordSelection(match, "player", card.instanceId, lane)) continue;
    // Keep the mentor for the lesson's final SQUABBLE. Older saved crews
    // without him continue to use the normal legal-move guidance.
    const mentorLesson = match.storyEncounter?.id === 'rookie-road-v2'
      && match.playerHand.some(c => c.cardId === 'drfade');
    if (mentorLesson && ((match.round < 4 && card.cardId === 'drfade')
      || (match.round === 4 && card.cardId !== 'drfade'))) continue;
    const played = playTurnCard(match, "player", card.instanceId, lane, match.round === 4 && !match.squabbleUsed);
    const results = getDistrictResults(revealCpuTurn(pass(played, "player")));
    const value = results.reduce((sum, d) => sum + (d.winner === "player" ? 1000 : 0) + Math.max(-12, Math.min(12, d.player - d.cpu)), 0);
    if (!best || value > best.value) best = { instanceId: card.instanceId, lane, value };
  }
  return best ? { instanceId: best.instanceId, lane: best.lane } : null;
}
/** Build the exact legal transcript taught by the guided tutorial. */
export function createGuidedTutorialTranscript(
  abilityUpgradeSnapshot?: AbilityUpgradeSnapshot,
  districtSnapshot?: DistrictSnapshot,
  encounter?: StoryEncounterSnapshot,
  playerCardIds?: string[],
  playerDeckId = "vibes",
): PlayerMove[] {
  let match = encounter ? createStoryMatch(encounter, playerCardIds ?? deckById(playerDeckId).cards, playerDeckId, abilityUpgradeSnapshot, districtSnapshot) : createMatch(
    "vibes",
    "combo",
    undefined,
    abilityUpgradeSnapshot,
    districtSnapshot,
  );
  const moves: PlayerMove[] = [];
  const roundLimit = getMatchRoundLimit(match);

  for (let round = 1; round <= roundLimit; round += 1) {
    if (round === 1 || round === 2 || round === 4) {
      const candidates = match.playerHand.flatMap((card) =>
        ([0, 1, 2] as const)
          .filter((lane) => canAffordSelection(match, "player", card.instanceId, lane))
          .map((lane) => ({ card, lane })),
      );
      candidates.sort((left, right) =>
        round === 4
          ? right.card.basePower - left.card.basePower || left.lane - right.lane
          : left.card.cost - right.card.cost || left.lane - right.lane,
      );
      const teaching = encounter ? getTutorialPlay(match) : null;
      const selected = teaching ? candidates.find(c => c.card.instanceId === teaching.instanceId && c.lane === teaching.lane) : candidates[0];
      if (!selected) {
        throw new Error(`Tutorial round ${round} needs an affordable play`);
      }
      const squabble = round === 4;
      moves.push({
        cardInstanceId: selected.card.instanceId,
        lane: selected.lane,
        squabble,
        endTurn: false,
      });
      match = playTurnCard(
        match,
        "player",
        selected.card.instanceId,
        selected.lane,
        squabble,
      );
    }

    moves.push({
      cardInstanceId: null,
      lane: null,
      squabble: false,
      endTurn: true,
    });
    match = nextRound(revealCpuTurn(pass(match, "player")));
  }

  if (match.phase !== "complete") {
    throw new Error("Guided tutorial transcript did not complete the match");
  }
  return moves;
}

export function validateTurnRules(moves: readonly TranscriptMove[], version: 1 | 2) {
  if (moves.some(move => version === 2 ? typeof move.endTurn !== 'boolean' : move.endTurn !== undefined)) {
    throw new Error('Transcript does not follow this fade’s turn rules');
  }
}

/** Replay a committed transcript prefix without requiring the match to be complete.
 * This is the only safe way to reconstruct an interrupted online encounter: the
 * serialized client Match is never authoritative. */
export function replayMatchPrefix(initial: Match, moves: readonly TranscriptMove[]): Match {
  const roundLimit = getMatchRoundLimit(initial);
  if (moves.length > MAX_MATCH_MOVES) throw new Error("A transcript may contain at most 64 actions");
  const multiCardTurns = moves.some(move => move.endTurn !== undefined);
  validateTurnRules(moves, multiCardTurns ? 2 : 1);
  let match = initial;
  for (const move of moves) {
    if (match.phase !== 'player') throw new Error('Transcript contains actions after the fade ended');
    if (move.cardInstanceId === null) {
      if (move.lane !== null || move.squabble || move.endTurn === false || (move.investment ?? 0) !== 0) throw new Error('Invalid end turn');
      match = pass(match, 'player');
    } else {
      if (move.lane === null || ![0, 1, 2].includes(move.lane)) throw new Error('Played cards need a valid lane');
      match = multiCardTurns
        ? playTurnCard(match, 'player', move.cardInstanceId, move.lane as Lane, move.squabble, move.investment)
        : playCard(match, 'player', move.cardInstanceId, move.lane as Lane, move.squabble, move.investment);
      if (move.endTurn === true) match = pass(match, 'player');
    }
    if (match.phase === 'cpu-reveal') {
      match = multiCardTurns ? revealCpuTurn(match) : revealCpu(match);
      match = nextRound(match);
    }
  }
  return match;
}
function replayPlayerMoves(initial: Match, moves: readonly TranscriptMove[]): Match {
  const roundLimit = getMatchRoundLimit(initial);
  const roundLabel = roundLimit === DEFAULT_MATCH_ROUND_LIMIT ? "six" : String(roundLimit);
  if (moves.length < roundLimit) throw new Error(`A match needs ${roundLabel} round endings`);
  const match = replayMatchPrefix(initial, moves);
  if (match.phase !== 'complete') throw new Error(`Transcript did not complete ${roundLabel} rounds`);
  return match;
}
export function verifyMatchTranscript(
  playerDeck: string,
  cpuDeck: string,
  moves: TranscriptMove[],
  abilityUpgradeSnapshot?: AbilityUpgradeSnapshot,
  playerCardIds?: readonly string[],
  districtSnapshot?: DistrictSnapshot,
): Match {
  const match = playerCardIds
    ? createMatchFromEngineCards(playerDeck, [...playerCardIds], cpuDeck, [...deckById(cpuDeck).cards], undefined, undefined, abilityUpgradeSnapshot, districtSnapshot)
    : createMatch(playerDeck, cpuDeck, undefined, abilityUpgradeSnapshot, districtSnapshot);
  return replayPlayerMoves(match, moves);
}

export function createStoryMatch(
  snapshot: StoryEncounterSnapshot,
  playerDeck: string | readonly string[],
  playerCardsOrId: readonly string[] | string = "story-player",
  abilityUpgradeSnapshot?: AbilityUpgradeSnapshot,
  districtSnapshot?: DistrictSnapshot,
): Match {
  if (snapshot.enemy.cardIds.length !== DECK_SIZE || new Set(snapshot.enemy.cardIds).size !== DECK_SIZE) {
    throw new Error("Story enemy deck must contain ten unique cards");
  }
  const player = typeof playerDeck === "string"
    ? Array.isArray(playerCardsOrId)
      ? { id: playerDeck, cards: [...playerCardsOrId] }
      : deckById(playerDeck)
    : { id: typeof playerCardsOrId === "string" ? playerCardsOrId : "story-player", cards: [...playerDeck] };
  return createMatchFromEngineCards(
    player.id,
    [...player.cards],
    snapshot.enemy.deckId,
    [...snapshot.enemy.cardIds],
    snapshot,
    undefined,
    abilityUpgradeSnapshot,
    districtSnapshot,
  );
}

export function verifyStoryMatchTranscript(
  snapshot: StoryEncounterSnapshot,
  playerDeck: string | readonly string[],
  playerCardsOrMoves: readonly string[] | TranscriptMove[],
  movesOrDeckId?: TranscriptMove[] | string,
  abilityUpgradeSnapshot?: AbilityUpgradeSnapshot,
  districtSnapshot?: DistrictSnapshot,
): Match {
  const suppliedCards = playerCardsOrMoves.length > 0 && typeof playerCardsOrMoves[0] === "string";
  const moves = (suppliedCards ? movesOrDeckId : playerCardsOrMoves) as TranscriptMove[];
  if (!Array.isArray(moves)) throw new Error("Story fade transcript moves are required");
  const matchCardsOrId = suppliedCards
    ? playerCardsOrMoves as readonly string[]
    : typeof movesOrDeckId === "string" ? movesOrDeckId : "story-player";
  return replayPlayerMoves(createStoryMatch(snapshot, playerDeck, matchCardsOrId, abilityUpgradeSnapshot, districtSnapshot), moves);
}

export type RoundState = {
  round: number; phase: Phase; playerDrawIndex: number; cpuDrawIndex: number;
  squabbleUsed: boolean; plugDiscountLane: Record<Owner, Lane | null>; cheapBuffsUsed: Record<Owner, number>;
  discountTokens: DiscountToken[]; nextDiscountOrder: number; landlordTaxUsed: Record<Owner, Record<Lane, boolean>>;
  sneakerTriggered: Record<Owner, boolean>;
};

export type EventType = 'play' | 'reveal' | 'ability' | 'pass' | 'round-start' | 'expiration' | 'match-complete';

export type EventParticipant = {
  cardInstanceId: string; cardId: string; owner: Owner;
  before: CardEventState | null; after: CardEventState | null;
  departureCause?: 'aura-loss' | 'transformation';
};

const roundState = (m: Match): RoundState => ({
  round: m.round,
  phase: m.phase,
  playerDrawIndex: m.playerDrawIndex,
  cpuDrawIndex: m.cpuDrawIndex,
  squabbleUsed: m.squabbleUsed,
  plugDiscountLane: { ...m.plugDiscountLane },
  cheapBuffsUsed: { ...m.cheapBuffsUsed },
  discountTokens: [...(m.discountTokens ?? [])],
  nextDiscountOrder: m.nextDiscountOrder ?? 1,
  landlordTaxUsed: m.landlordTaxUsed ?? { player: { 0: false, 1: false, 2: false }, cpu: { 0: false, 1: false, 2: false } },
  sneakerTriggered: m.sneakerTriggered ?? { player: false, cpu: false },
});

export type EventDuration = { unit: 'round'; startsAtRound: number; expiresAtRound: number; expiration: 'round-start' | 'match-complete' };

const participant = (before: Match, after: Match, id: string): EventParticipant | null => {
  const b = findCard(before, id), a = findCard(after, id);
  const card = a ?? b;
  return card ? { cardInstanceId: card.instanceId, cardId: card.cardId, owner: card.owner, before: cardState(b), after: cardState(a) } : null;
};

const cardState = (card: CardInstance | undefined): CardEventState | null => card ? ({
  cardInstanceId: card.instanceId, cardId: card.cardId, owner: card.owner, lane: card.lane,
  power: getEffectiveCardPower(card), basePower: card.basePower, powerModifier: card.powerModifier,
  ...(card.continuousPower ? { continuousPower: card.continuousPower } : {}),
  moved: card.moved, statuses: { ...card.statuses }, lastEffectNote: card.lastEffectNote,
  ...(card.goldenGlow ? { goldenGlow: true } : {}),
  ...(card.maryCents !== undefined ? { maryCents: card.maryCents } : {}),
  ...(card.maryElephant ? { maryElephant: true } : {}),
  ...(card.buddyForm ? { buddyForm: card.buddyForm } : {}),
  ...(card.buddyGrowthAtRound !== undefined ? { buddyGrowthAtRound: card.buddyGrowthAtRound } : {}),
  ...(card.buddyEarthExpiresAtRound !== undefined ? { buddyEarthExpiresAtRound: card.buddyEarthExpiresAtRound } : {}),
  ...(card.buddyBud ? { buddyBud: { ...card.buddyBud } } : {}),
}) : null;

type EventInput = {
  type: EventType; sourceId?: string; owner: Owner; targetIds?: string[]; note: string;
  kind?: EffectKind; timing?: 'instant' | 'timed'; duration?: EventDuration | null; lane?: Lane;
  abilityMetadata?: EffectLogEntry["abilityMetadata"];
};

export type ResourceState = { playerMotion: number; cpuMotion: number };

const resources = (m: Match): ResourceState => ({ playerMotion: m.playerMotion, cpuMotion: m.cpuMotion });

const replayState = (m: Match): ReplayState => JSON.parse(JSON.stringify({
  afterParty: m.afterParty,
  laneDamage: m.laneDamage ?? [],
  undercovaPayouts: m.undercovaPayouts ?? {},
  swookieRecruitment: m.swookieRecruitment ?? {},
  rainmakerPayouts: m.rainmakerPayouts ?? {},
  foodzCommunityServed: m.foodzCommunityServed ?? {},
  diceResult: m.diceResult,
  districtSnapshot: m.districtSnapshot,
  districtRuntime: m.districtRuntime,
  leaderRounds: m.leaderRounds,
  electricPlays: m.electricPlays,
  pendingLeaderReactions: m.pendingLeaderReactions,
  lingeringScents: m.lingeringScents ?? [],
  creativeMarks: m.creativeMarks ?? [],
  districtTraps: m.districtTraps ?? [],
  janitorReversals: m.janitorReversals ?? [],
  lastMovedAlly: m.lastMovedAlly ?? {},
  roundMovedIds: m.roundMovedIds ?? { player: [], cpu: [] },
  cheshireRounds: m.cheshireRounds ?? {},
  squabbleByOwner: m.squabbleByOwner,
  round: m.round,
  phase: m.phase,
  playerHand: m.playerHand,
  cpuHand: m.cpuHand,
  boards: m.boards,
  playerMotion: m.playerMotion,
  cpuMotion: m.cpuMotion,
  nextArrivalOrder: m.nextArrivalOrder ?? nextArrivalOrder(m),
  playerDrawIndex: m.playerDrawIndex,
  cpuDrawIndex: m.cpuDrawIndex,
  squabbleUsed: m.squabbleUsed,
  plugDiscountLane: m.plugDiscountLane,
  cheapBuffsUsed: m.cheapBuffsUsed,
  discountTokens: m.discountTokens ?? [],
  blueNextBonus: m.blueNextBonus ?? {},
  nextDiscountOrder: m.nextDiscountOrder ?? 1,
  landlordTaxUsed: m.landlordTaxUsed ?? { player: { 0: false, 1: false, 2: false }, cpu: { 0: false, 1: false, 2: false } },
  sneakerTriggered: m.sneakerTriggered ?? { player: false, cpu: false },
  timedEffects: m.timedEffects,
  storyRuntime: m.storyRuntime,
  abilityUpgradeSnapshot: m.abilityUpgradeSnapshot,
  squabblehouseRevealHistory: m.squabblehouseRevealHistory ?? [],
})) as ReplayState;

export type ScoreState = { lane: Lane; player: number; cpu: number };

const addEvent = (before: Match, after: Match, input: EventInput): Match => {
  after = reconcileContinuousPower(after);
  const neutralDepartures = after[CONTINUOUS_POWER_DEPARTURES] ?? [];
  after = clearContinuousPowerDepartures(after);
  if (
    before[SUPPRESS_PRESENTATION_EVENTS] ||
    after[SUPPRESS_PRESENTATION_EVENTS]
  ) {
    return {
      ...after,
      [SUPPRESS_PRESENTATION_EVENTS]: true,
      nextEventSequence: after.nextEventSequence + 1,
      effectLog: [],
    };
  }
  const neutralById = new Map(neutralDepartures.map(card => [card.instanceId, card]));
  const eventParticipant = (id: string): EventParticipant | null => {
    const departure = neutralById.get(id);
    return departure
      ? { cardInstanceId: departure.instanceId, cardId: departure.cardId, owner: departure.owner,
        before: cardState(departure), after: null, departureCause: 'aura-loss' }
      : (() => {
        const value = participant(before, after, id);
        return value?.before && !value.after && (after.creativeMarks ?? []).some(mark => mark.kind === 'sl-mary-return' && mark.source.instanceId === id)
          ? { ...value, departureCause: 'transformation' as const } : value;
      })();
  };
  const source = input.sourceId ? eventParticipant(input.sourceId) : null;
  const targetIds = [...new Set([...(input.targetIds ?? []), ...neutralDepartures.map(card => card.instanceId)])]
    .filter((id) => id !== input.sourceId);
  const sourceCard = input.sourceId ? findCard(after, input.sourceId) ?? findCard(before, input.sourceId) : undefined;
  const neutralIds = new Set(neutralDepartures.map(card => card.instanceId));
  const event: EffectLogEntry = {
    sequence: after.nextEventSequence,
    round: after.round,
    type: input.type,
    timing: input.timing ?? 'instant',
    duration: input.duration ?? null,
    source,
    targets: targetIds.map(eventParticipant).filter((x): x is EventParticipant => x !== null),
    scores: { before: scores(before), after: scores(after) },
    resources: { before: resources(before), after: resources(after) },
    state: { before: roundState(before), after: roundState(after) },
    replay: { before: replayState(before), after: replayState(after) },
    cardInstanceId: sourceCard?.instanceId ?? input.type,
    cardId: sourceCard?.cardId ?? input.type,
    owner: sourceCard?.owner ?? input.owner,
    lane: input.lane ?? sourceCard?.lane ?? 0,
    kind: input.kind ?? 'ability',
    note: input.note
      + targetIds.filter(id => findCard(before, id) && !findCard(after, id) && !neutralIds.has(id) && eventParticipant(id)?.departureCause !== 'transformation')
        .map(id => ` ${findCard(before, id)!.name} was destroyed.`).join('')
      + neutralDepartures.map(card => ` ${card.name} was destroyed when its Manager aura expired.`).join(''),
    ...(input.abilityMetadata ? { abilityMetadata: input.abilityMetadata } : {}),
  };
  return { ...after, nextEventSequence: after.nextEventSequence + 1, effectLog: [...after.effectLog, event] };
};

export type CardEventState = {
  cardInstanceId: string; cardId: string; owner: Owner; lane: Lane | null;
  power: number; basePower: number; powerModifier: number; moved: boolean;
  continuousPower?: number;
  statuses: Statuses; lastEffectNote: string;
  goldenGlow?: boolean;
  maryCents?: number;
  maryElephant?: boolean;
  buddyForm?: 'earth' | 'squabble-earth';
  buddyGrowthAtRound?: number;
  buddyEarthExpiresAtRound?: number;
  buddyBud?: { readonly sourceInstanceId: string; readonly sproutsAtRound: number; readonly sprouted: boolean };
};

const scores = (m: Match): ScoreState[] => getDistrictResults(m).map(({ lane: district, player, cpu }) => ({ lane: district, player, cpu }));

function blockbusterTools(): BlockbusterTools {
  return { modify, protect: grantProtection, enemyMove: forceEnemyMove, hit: targetEnemyPowerReduction, reduce: reduceHands, move, cleanse: cleanseAlly,
    status: (m, source, target, status, note) => hostileEffect(m, source, target, (state, actual) => modify(state, actual.instanceId,
      c => ({ ...c, statuses: { ...c.statuses, [status]: true }, lastEffectNote: note })), false, false, true),
    burn: (m, source, target) => targetEnemyBurnAndPowerReduction(m, source, target, 1, 2, 'Chain Reaction: -2 Hands and 1 Burn.'),
    create: createCardInstance, locked: getStoryLockedLanes, power: getEffectiveCardPower, rawPower: rawCombatPower,
    sync: syncContinuousPower, random: seededIndex };
}
function applyBurntPlates(match: Match): Match {
  let m = match;
  for (const plate of match.boards.flat().filter(c => c.cardId === 'burnt-plate')) {
    const crew = m.boards[plate.lane!].filter(c => !c.hazard && (c.kind ?? 'character') === 'character' && c.owner === plate.owner);
    m = { ...m, boards: m.boards.map(cs => cs.filter(c => c.instanceId !== plate.instanceId)) as Match['boards'] };
    if (!crew.length) continue;
    const target = crew[seededIndex(`${plate.instanceId}:${m.round}:burn`,crew.length)];
    const before = m;
    if (!target.statuses.uncounterable) m = modify(m,target.instanceId,c => ({ ...c,statuses:{...c.statuses,burnStacks:c.statuses.burnStacks+1},lastEffectNote:'Burnt Plate: +1 Burn.' }));
    m = addEvent(before,m,{type:'ability',sourceId:plate.instanceId,owner:plate.owner,lane:plate.lane!,targetIds:[target.instanceId],kind:'fire',note:'Burnt Plate: one 1-Burn penalty; plate cleared.'});
  }
  return m;
}

function creativeTools(): CreativeTools {
  return {
    trim: (m, source, target, amount) =>
      trimEnemyBonusHands(m, source, target, amount).match,
    power: getEffectiveCardPower,
    modify,
    protect: grantProtection,
    hit: targetEnemyPowerReduction,
    status: (m, source, target, key, note) =>
      hostileEffect(
        m,
        source,
        target,
        (state, actual) =>
          queueDisruptionReactions(
            state,
            modify(state, actual.instanceId, (c) => ({
              ...c,
              statuses: { ...c.statuses, [key]: true },
              lastEffectNote: note,
            })),
            source,
            actual.instanceId,
          ),
        false,
        false,
        true,
      ),
    burn: applyBurn,
    cleanse: (m, id) =>
      cleanseAlly(m, id, (c) => ({
        ...c,
        statuses: cleanseStatuses(c.statuses),
      })),
    move,
    movePair: creativeMovePair,
    enemyMove: forceEnemyMove,
    canMove: canMoveTo,
    score: (m, owner, lane) =>
      getLaneScoreForMatch(m, inLane(m, owner, lane), lane, owner),
    reveal: (m, source) => resolveAbility(m, source),
    train: trainCreativeAbility,
    refund: refundMotion,
    roundLimit: getMatchRoundLimit,
    disruption: queueDisruptionReactions,
    event: (before, after, source, targets, note) =>
      addEvent(
        after.effectLog.length > before.effectLog.length ? after : before,
        after,
        {
          type: "ability",
          // Route bookkeeping can own the actual movement frame. Classify the
          // recorded positional change before falling back to elemental styling.
          kind:
            after.effectLog.length === before.effectLog.length
              && [source.instanceId, ...targets].some(id => {
                const old = findCard(before, id), current = findCard(after, id);
                return old?.lane != null && current?.lane != null && old.lane !== current.lane;
              }) ? "move"
              : source.type === "Fire"
              ? "fire"
              : source.type === "Water"
                ? "water"
                : "ability",
          sourceId: source.instanceId,
          owner: source.owner,
          lane: source.lane ?? 0,
          targetIds: targets,
          note,
        },
      ),
  };
}
function trainCreativeAbility(m: Match, id: string): Match {
  const source = findCard(m, id);
  if (
    !source ||
    !CREATIVE_KITS[source.cardId] ||
    source.lane === null ||
    source.creativeUsed?.training
  )
    return m;
  m = modify(m, id, (c) => ({
    ...c,
    creativeUsed: { ...c.creativeUsed, training: true },
  }));
  for (const upgrade of snapshotUpgradesForCard(
    m.abilityUpgradeSnapshot,
    source.owner,
    source.cardId,
  )) {
    const e = upgrade.effect;
    const target =
      e.kind === "self-power"
        ? findCard(m, id)
        : lowest(
            m.boards
              .flat()
              .filter(
                (c) =>
                  !c.hazard &&
                  c.instanceId !== id &&
                  c.owner ===
                    (e.target === "friendly"
                      ? source.owner
                      : source.owner === "player"
                        ? "cpu"
                        : "player") &&
                  c.lane === source.lane,
              ),
          );
    if (!target) continue;
    const before = m;
    m =
      e.amount < 0
        ? targetEnemyPowerReduction(m, source, target, e.amount, upgrade.name)
        : modify(m, target.instanceId, (c) => ({
            ...c,
            powerModifier: c.powerModifier + e.amount,
          }));
    m = addEvent(before, m, {
      type: "ability",
      sourceId: id,
      owner: source.owner,
      targetIds: [target.instanceId],
      note: upgrade.name + ": once-per-match training.",
      abilityMetadata: {
        upgradeId: upgrade.id,
        upgradeName: upgrade.name,
        sourceCardId: source.cardId,
        sourceInstanceId: id,
        targetInstanceIds: [target.instanceId],
        result: "applied",
      },
    });
  }
  return m;
}

function creativeMovePair(
  m: Match,
  first: CardInstance,
  second: CardInstance,
  destination: Lane,
  note: string,
): Match {
  if (
    first.instanceId === second.instanceId ||
    first.owner !== second.owner ||
    !moveRouteLegal(m, first, destination) ||
    !moveRouteLegal(m, second, destination) ||
    m.boards[destination].filter((c) => c.owner === first.owner).length > 2
  )
    return m;
  const before = m;
  const firstDeparture = openTabDeparture(m, first);
  if (firstDeparture.stopped) return firstDeparture.match;
  const liveSecond = findCard(firstDeparture.match, second.instanceId);
  if (!liveSecond) return firstDeparture.match;
  const secondDeparture = openTabDeparture(firstDeparture.match, liveSecond);
  if (secondDeparture.stopped) return secondDeparture.match;
  m = move(secondDeparture.match, first, destination, note, true, false, true);
  const passenger = findCard(m, second.instanceId);
  if (passenger) m = move(m, passenger, destination, note, true, false, true);
  for (const original of [first, second]) {
    m = fairytaleDeparture(m, original);
    m = fairytaleArrival(m, original.instanceId, findCard(m, original.instanceId)?.lane === destination);
    m = applyScentEntry(m, original.instanceId);
    m = homecomingArrival(creativeMoved(before, m, original.instanceId, creativeTools()), original.instanceId, homecomingTools());
    m = selectedMoved(before, musicMoved(before, streetLegendsMoved(before, m, original.instanceId, waveTools()), original.instanceId, waveTools()), original.instanceId, waveTools());
  }
  return m;
}


function homecomingTools(): HomecomingTools {
  return { ...creativeTools(), train: trainWaveAbility,
    returnAlly: (m, source, target) => returnToHand(m, source, target, true),
    tow: (m, source, target) => hostileEffect(m, source, target, (state, actual) => {
      if (source.lane === null || !canMoveTo(state, actual, source.lane)
        || state.boards[source.lane].filter(c => !c.hazard && c.owner === actual.owner).length >= 4) return state;
      let result = forceMoveUnshielded(state, actual, source.lane);
      const arrived = findCard(result, actual.instanceId);
      if (!arrived || arrived.lane !== source.lane) return result;
      const amount = Math.min(3, Math.max(0, arrived.powerModifier));
      const recipient = lowest(inLane(result, source.owner, source.lane).filter(c => c.kind !== 'support'));
      if (!amount || !recipient) return result;
      result = modifyWithoutDamage(result, arrived, c => ({ ...c, powerModifier: c.powerModifier - amount,
        lastEffectNote: `Tow & Collect: repossessed ${amount} bonus Hands.` }));
      return modify(result, recipient.instanceId, c => ({ ...c, powerModifier: c.powerModifier + amount,
        lastEffectNote: `Tow & Collect: received ${amount} repossessed Hands.` }));
    }, false, false, true),
  };
}


/** These stateless adapters are shared; every operation receives its match. */
let sharedWaveTools: (StreetLegendsTools & MusicTools & SelectedTools) | undefined;
function waveTools(): StreetLegendsTools & MusicTools & SelectedTools {
  return sharedWaveTools ??= { ...creativeTools(), train: trainWaveAbility,
    trimBonus: trimEnemyBonusHands,
    marriage: (m, s) => summonCard(m,s.owner,s.lane!,fakeMarriage,'fake-marriage',s),
    buff: (m, id, amount, copiedGain = false) => modify(m, id, c => ({ ...c, powerModifier: c.powerModifier + amount }), copiedGain),
    hostile: (m, source, target, apply) => hostileEffect(m, source, target, apply, false, false, true),
    damage: (m, target, amount, note) => reduceHands(m, target, amount, note),
    maryEvent: (before, after, source, targetIds, note, landing = false) => addEvent(before, after, {
      type: landing ? 'ability' : 'expiration', sourceId: source.instanceId, owner: source.owner,
      lane: source.lane ?? 0, targetIds, note, kind: 'ability',
    }),
    maryLand: (m, card, lane) => {
      const arrivalOrder = nextArrivalOrder(m);
      const landed: Match = { ...m, nextArrivalOrder: arrivalOrder + 1,
        boards: m.boards.map((cs, index) => index === lane ? [...cs, { ...card, lane, arrivalOrder }] : cs) as Match['boards'] };
      return streetLegendsArrival(homecomingArrival(applyScentEntry(landed, card.instanceId), card.instanceId, homecomingTools()), card.instanceId, waveTools());
    },
    unlock: (m, id) => musicCleansed(streetLegendsCleansed(modify(m, id, c => ({ ...c, squabblehouseCannotMoveThroughRound: undefined })), id), id),
    returnAlly: (m, source, target) => returnToHand(m, source, target, true),
    removeBonus: (m, target, amount) => trimBonusHandsUnshielded(m, target, amount, 'Transferred removable bonus Hands.').match,
    echo: (m, source) => resolveAbility(m, source, { echoed: true }),
    laneOpen: (m, owner, targetLane) => !getStoryLockedLanes(m, owner).includes(targetLane),
  };
}

/** Public inspector status uses the same active marks as movement legality. */
export function getCharacterMovementLockThroughRound(m: Match, card: CardInstance): number | undefined {
  const values = [card.squabblehouseCannotMoveThroughRound ?? 0, ...(m.creativeMarks ?? []).filter(x => (x.kind === 'sl-curfew' || x.kind === 'mi-contract') && x.targets.includes(card.instanceId)).map(x => x.expires)].filter(round => round >= m.round);
  return values.length ? Math.max(...values) : undefined;
}
