import type { AbilityUpgradeEffect, Card, CardRarity } from './data';

/** First draftable identity wave for Water, Electric, Plant, and Air. */
export const ELEMENTAL_BOND_WAVE = [
  ["riptidebruiser", "riptide-bruiser", "Gator Boy", "Common", "Water", 1, 2, "Emotional Support Gator", "On Reveal: Give the highest-Hands enemy here -1 Hands. If its Hands fall, gain +1 Hand.", "Pressure"],
  ["stillwatermedic", "stillwater-medic", "Hot Tub Hottie", "Uncommon", "Water", 2, 3, "Soak Your Problems", "On Reveal: Cleanse your lowest-Hands frozen or silenced ally here and give it +1 Hand. If cleansed, gain +1 Hand.", "Support"],
  ["monsoonanchor", "monsoon-anchor", "Gas Station Sushi Chef", "Rare", "Water", 3, 2, "Trust the Cooler", "Ongoing: While in your hand, your other Water characters gain +1 Hand at round end. On Reveal: Weaken the strongest enemy here.", "Disruption", "Water"],
  ["rainmaker", "rainmaker", "Energy Drink Freak", "Epic", "Water", 3, 4, "Fourth Can, No Plan", "On Reveal: Restore 2 Motion, up to 9, once per card per match. Echoes cannot refund. In Hand: From round 2, at round start gain 1 Motion, up to 9, and lose 1 base Hand, minimum 1. One successful hand payout per side per round, at most three per side per match; copies share both limits. Returning never resets its lost base Hands or entrance refund.", "Tempo"],
  ["batteryback", "battery-back", "Game Developer", "Common", "Electric", 1, 2, "Works on My Machine", "On Reveal: Repair your lowest-Hands ally in another district with a negative Hands modifier: give it +1 Hand and restore 1 Motion, up to 9.", "Support"],
  ["circuitcaptain", "circuit-captain", "Electrician Foreman", "Epic", "Electric", 4, 4, "Everybody on the Clock", "Ongoing: While in your hand, your other Electric characters gain +1 Hand at round end.", "Tempo", "Electric"],
  ["wiretap", "wiretap", "E.V. Enthusiast", "Rare", "Electric", 2, 2, "Actually, It Charges Free", "On Reveal: Your next card in another district costs 1 less Motion.", "Tempo"],
  ["livewire", "livewire", "Dominican Phone Salesman", "Uncommon", "Electric", 3, 2, "Switch Carriers", "On Reveal: Move to your weakest other district. If you move, gain +1 Hand and your next card in a different district from your new location costs 1 less Motion. If the discounted card is a character, it gains +1 Hand when played.", "Movement"],
  ["sprout", "sprout", "OG Vegan", "Common", "Plant", 1, 1, "I Brought My Own Plate", "On Reveal: Give your lowest-Hands other Plant ally here +2 Hands. If one is here, also gain +1 Hand.", "Growth"],
  ["rootnurse", "root-nurse", "Matcha Freak", "Uncommon", "Plant", 2, 3, "Ceremonial Grade Crashout", "On Reveal: If you have at least 4 Motion left after playing this card, gain +2 Hands. Otherwise, cleanse your lowest-Hands frozen or silenced ally anywhere and give it +3 Hands. If nobody needs cleansing, give your weakest other Plant ally anywhere +3 Hands; if none exists, gain +2 Hands.", "Growth"],
  ["canopykeeper", "canopy-keeper", "Performative Male", "Rare", "Plant", 3, 4, "Feminist Literature, Unopened", "Ongoing: While in your hand, your other Plant characters gain +1 Hand at round end.", "Growth", "Plant"],
  ["gardenwall", "garden-wall", "A Spare Gus", "Epic", "Plant", 4, 4, "Personal Space Is Seasonal", "On Reveal: Give the strongest enemy in another district -2 Hands, then give your weakest other ally here +1 Hand and your weakest Plant ally in another district +1 Hand.", "Pressure"],
  ["gust", "gust", "Big City Pigeon", "Common", "Air", 1, 2, "Run Your Breadcrumbs", "On Reveal: Move to your weakest other district. If you move, give the weakest enemy there -1 Hand.", "Movement"],
  ["crosswind", "crosswind", "Baby Crying on an Airplane", "Uncommon", "Air", 2, 2, "No Quiet Section", "On Reveal: Weaken the strongest enemy here. Move your weakest other ally here to your weakest other district. If it moves, it gains +2 Hands.", "Disruption"],
  ["slipstream", "slipstream", "The Flight Plug", "Rare", "Air", 3, 3, "Cousin at the Gate", "Ongoing: While in your hand, your other Air characters gain +1 Hand at round end.", "Movement", "Air"],
  ["cloudbreak", "cloudbreak", "Airheaded Model", "Epic", "Air", 4, 4, "Wrong Gate, Great Lighting", "On Reveal: Move to your weakest other district. If you move, gain +1 Hand and give your weakest ally left in the original district +2 Hands (+3 if Air) and Protection.", "Movement"],
] as const;

export const elementalBondWaveUpgradeEffects: Record<string, readonly AbilityUpgradeEffect[]> = Object.fromEntries(
  ELEMENTAL_BOND_WAVE.map(([id]) => [id, [0, 1, 2].map(() => ({ kind: 'self-power' as const, amount: 1 as const, trigger: 'base-success' as const }))]),
);
export const elementalBondWaveRarities: Record<string, CardRarity> = Object.fromEntries(
  ELEMENTAL_BOND_WAVE.map(([id, , , rarity]) => [id, rarity]),
);
const ELEMENT_ACCENTS: Record<string, string> = {
  Water: '#60a5fa',
  Electric: '#22d3ee',
  Plant: '#4ade80',
  Air: '#a78bfa',
};
export const elementalBondWaveCards: Record<string, Card> = Object.fromEntries(
  ELEMENTAL_BOND_WAVE.map(([id, catalogId, name, , type, cost, power, ability, effect, role, elementalBond]) => {
    const accent = ELEMENT_ACCENTS[type];
    return [id, {
      id: catalogId, name, type, cost, power, ability, effect, kind: 'character', roles: [role],
      artworkLayout: 'portrait', ...(elementalBond ? { elementalBond } : {}),
      entryVfx: { accent }, portraitAccent: accent,
      abilityUpgrades: [2, 5, 8].map((unlockLevel, index) => ({
        id: `${id}:upgrade:${index + 1}`,
        name: `${ability} ${['Practice', 'Confidence', 'Mastery'][index]}`,
        description: elementalBond
          ? 'While this card is in your hand, one bonded ally gains an additional +1 Hand at round end.'
          : id === 'rainmaker'
            ? 'Once per match, after its entrance actually refunds Motion, this card gains +1 Hand. Hand income does not train.'
            : `After ${ability} succeeds, this card gains +1 Hand.`,
        unlockLevel,
        effect: elementalBondWaveUpgradeEffects[id][index],
      })),
    }];
  }),
);