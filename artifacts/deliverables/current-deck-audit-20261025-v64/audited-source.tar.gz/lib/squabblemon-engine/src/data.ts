import { applyBasePvpBalance } from './basePvpBalance';
import { applyCrewMatchupBalance } from './crewMatchupBalance';
import { selectedCards, selectedRarities, selectedFactions, selectedUpgradeEffects } from './selectedWave';
import { streetLegendsCards, streetLegendsRarities, streetLegendsUpgradeEffects, streetLegendsFactions } from './streetLegendsWave';
import { musicIndustryWaveCards, musicIndustryRarities, musicIndustryUpgradeEffects, musicIndustryFactions, MUSIC_INDUSTRY_IDS, FITNESS_WAVE_IDS, MUSIC_CHARACTER_IDS, FITNESS_CHARACTER_IDS } from './musicIndustryWave';
import { homecomingCards, homecomingRarities, homecomingUpgradeEffects } from './homecomingWave';
import { applyRosterBalance } from './rosterBalance';
import { applyFullRosterBuffs } from './fullRosterBuffs';
import { applyCreativeCardKits } from './creativeReworks';
import { applyElementalHandBonuses } from './elementalHandBonuses';
export { ELEMENTAL_HAND_BONUS_CARDS } from './elementalHandBonuses';
import { blockbusterWaveCards, blockbusterWaveRarities, blockbusterWaveUpgradeEffects } from './blockbusterWave';
import { commonUpgradeEffects, neighborhoodCommons } from './commonCards';
import { superCommonCards, superCommonUpgradeEffects } from './superCommonCards';
import { expansionCards, expansionRarities, expansionUpgradeEffects } from './blockExpansion';
import { supportCards, supportRarities, supportUpgradeEffects } from './supportCards';
import { streetWaveCards, streetWaveRarities, streetWaveUpgradeEffects } from './streetWave';
import { mythicLegendCards, mythicLegendRarities, mythicLegendUpgradeEffects } from './mythicLegends';
import { characterWaveCards, characterWaveRarities, characterWaveUpgradeEffects } from './characterWave';
import { neighborhoodWaveCards, neighborhoodWaveRarities, neighborhoodWaveUpgradeEffects } from './neighborhoodWave';
import { cellblockWaveCards, cellblockWaveRarities, cellblockWaveUpgradeEffects } from './cellblockWave';
import { fairytaleCards, fairytaleRarities, fairytaleUpgradeEffects, FAIRYTALE_ALTERNATE_ART } from './fairytaleWave';
import { afterHoursWaveCards, afterHoursWaveRarities, afterHoursWaveUpgradeEffects } from './afterHoursWave';
import { elementalBondWaveCards, elementalBondWaveRarities, elementalBondWaveUpgradeEffects } from './elementalBondWave';
import { kumiteCards, kumiteCardRarities, kumiteCardUpgradeEffects, isKumiteExclusiveCard } from './kumiteCards';
export { KUMITE_EXCLUSIVE_CARD_IDS, KUMITE_CARD_REWARDS, KUMITE_LINEUP_REWARDS, isKumiteExclusiveCard } from './kumiteCards';
import { sideOzWaveCards, sideOzWaveRarities, sideOzWaveUpgradeEffects, sideOzWaveFactions } from './sideOzWave';
import { storyCharacterWaveCards, storyCharacterWaveRarities, storyCharacterWaveUpgradeEffects } from './storyCharacterWave';
import { tripleOgCards, tripleOgRarities, tripleOgUpgradeEffects } from './tripleOgs';
import { squabblehouseWaveCards, squabblehouseRarityById, squabblehouseFactionById, squabblehouseUpgradeEffects, squabblehouseStaffCardIds } from './squabblehouseWave';

export const DECK_SIZE = 10;
export const MAX_MOTION = 9;
/** Cards acquired only through their authored story rewards; excluded from random packs. */
export const STORY_ONLY_CARD_IDS = ['ganger-blue', 'ganger-red', 'snitch', 'cracked-head'] as const;

/** Rock was merged into Earth; older battle snapshots can still carry its former name. */
export const canonicalElement = (type: string): string => type === 'Rock' ? 'Earth' : type;

export type Card = {
  id: string;
  name: string;
  type: string;
  cost: number;
  power: number;
  ability: string;
  effect: string;
  roles?: string[];
  kind?: 'character' | 'support' | 'token' | 'blockbuster';
  /** Planted hazards occupy the board visually, but do not score or join a crew. */
  hazard?: true;
  /** Supplied full portrait art may intentionally retain its original backdrop. */
  artworkLayout?: 'portrait';
  deck?: string;
  owner?: "player" | "cpu";
  abilityUpgrades: readonly AbilityUpgrade[];
  /** When set, while this card is in its owner's hand every other friendly character of the
   *  same type gains +1 Hand at round end. The elemental-bond system uses GUAP's hand effect
   *  as the template for all ten types, including Normal. These are permanent round-end
   *  gains, not a board aura. Engine reads this in applyOngoingRoundEndHandEffects. */
  elementalBond?: string;
  /** Per-card entry vfx descriptor. The UI uses this to color/scale the staged card on play. */
  entryVfx?: {
    readonly accent: string;
    readonly keyframeId?: string;
  };
  /** When set, the inspector renders a 3-layer parallax scene for the "looking at it" loop. */
  immersiveAssetId?: {
    readonly backgroundAssetId: string;
    readonly midgroundAssetId?: string;
    readonly foregroundAssetId: string;
  };
  /** Per-card portrait pop color used on hand draw. Falls back to the card type's accent. */
  portraitAccent?: string;
};

/** Resolve the per-card entry accent, falling back to a card-type-derived color. */
export const cardEntryAccent = (card: Card): string =>
  card.entryVfx?.accent ?? card.portraitAccent ?? defaultEntryAccent(canonicalElement(card.type));

const defaultEntryAccent = (type: string): string => {
  const t = type.toLowerCase();
  if (t === "fire" || t === "dark") return "#fb923c";
  if (t === "electric") return "#22d3ee";
  if (t === "water") return "#60a5fa";
  if (t === "plant") return "#4ade80";
  if (t === "air") return "#a78bfa";
  if (t === "earth") return "#d4a373";
  if (t === "shadow") return "#a3a3a3";
  if (t === "light") return "#fde68a";
  return "#facc15";
};

/** A deliberately small, additive effect budget for the fixed card-growth path. */
export type AbilityUpgrade = {
  readonly id: string;
  readonly name: string;
  readonly description: string;
  readonly unlockLevel: number;
  readonly effect: AbilityUpgradeEffect;
};
export type AbilityUpgradeEffect =
  | { readonly kind: "self-power"; readonly amount: 1; readonly trigger: "base-success" }
  | { readonly kind: "target-power"; readonly amount: -1 | 1; readonly target: "friendly" | "enemy"; readonly trigger: "base-success" };

export const ABILITY_UPGRADE_UNLOCK_LEVELS = [2, 5, 8] as const;
export const ABILITY_UPGRADE_COUNT = 3;

const upgradeEffects: Record<string, readonly AbilityUpgradeEffect[]> = {
  buddy: Array.from({ length: 3 }, () => ({ kind: "self-power" as const, amount: 1 as const, trigger: "base-success" as const })),
  folks: [{ kind: "self-power", amount: 1, trigger: "base-success" }, { kind: "target-power", amount: 1, target: "friendly", trigger: "base-success" }, { kind: "self-power", amount: 1, trigger: "base-success" }],
  kyle: Array.from({ length: 3 }, () => ({ kind: 'self-power' as const, amount: 1 as const, trigger: 'base-success' as const })),
  stockz: Array.from({ length: 3 }, () => ({ kind: 'self-power' as const, amount: 1 as const, trigger: 'base-success' as const })),
  guap: Array.from({ length: 3 }, () => ({ kind: "self-power" as const, amount: 1 as const, trigger: "base-success" as const })),
  ...commonUpgradeEffects,
  ...superCommonUpgradeEffects,
  ...expansionUpgradeEffects,
  ...supportUpgradeEffects,
  ...streetWaveUpgradeEffects,
  ...mythicLegendUpgradeEffects,
  ...characterWaveUpgradeEffects,
  ...homecomingUpgradeEffects,
  ...selectedUpgradeEffects,
  ...neighborhoodWaveUpgradeEffects,
  ...cellblockWaveUpgradeEffects,
  ...fairytaleUpgradeEffects,
  ...afterHoursWaveUpgradeEffects,
  ...elementalBondWaveUpgradeEffects,
  ...kumiteCardUpgradeEffects,
  ...sideOzWaveUpgradeEffects,
  ...storyCharacterWaveUpgradeEffects,
  ...tripleOgUpgradeEffects,
  ...blockbusterWaveUpgradeEffects,
  ...squabblehouseUpgradeEffects,
  ...streetLegendsUpgradeEffects,
  ...musicIndustryUpgradeEffects,
  bossbabe: Array.from({ length: 3 }, () => ({ kind: "self-power" as const, amount: 1 as const, trigger: "base-success" as const })),
  scammer: Array.from({ length: 3 }, () => ({ kind: "self-power" as const, amount: 1 as const, trigger: "base-success" as const })),
  rastamon: [{ kind: "self-power", amount: 1, trigger: "base-success" }, { kind: "target-power", amount: 1, target: "friendly", trigger: "base-success" }, { kind: "self-power", amount: 1, trigger: "base-success" }],
  roaster: [{ kind: "target-power", amount: -1, target: "enemy", trigger: "base-success" }, { kind: "self-power", amount: 1, trigger: "base-success" }, { kind: "target-power", amount: -1, target: "enemy", trigger: "base-success" }],
  nerd: [{ kind: "self-power", amount: 1, trigger: "base-success" }, { kind: "target-power", amount: -1, target: "enemy", trigger: "base-success" }, { kind: "self-power", amount: 1, trigger: "base-success" }],
  cornball: [{ kind: "self-power", amount: 1, trigger: "base-success" }, { kind: "self-power", amount: 1, trigger: "base-success" }, { kind: "target-power", amount: -1, target: "enemy", trigger: "base-success" }],
  plug: Array.from({ length: 3 }, () => ({ kind: "self-power" as const, amount: 1 as const, trigger: "base-success" as const })),
  streamer: Array.from({ length: 3 }, () => ({ kind: "self-power" as const, amount: 1 as const, trigger: "base-success" as const })),
  gamer: Array.from({ length: 3 }, () => ({ kind: "self-power" as const, amount: 1 as const, trigger: "base-success" as const })),
  techbro: Array.from({ length: 3 }, () => ({ kind: "self-power" as const, amount: 1 as const, trigger: "base-success" as const })),
  bikelife: Array.from({ length: 3 }, () => ({ kind: "self-power" as const, amount: 1 as const, trigger: "base-success" as const })),
  vibe: [{ kind: "target-power", amount: 1, target: "friendly", trigger: "base-success" }, { kind: "self-power", amount: 1, trigger: "base-success" }, { kind: "target-power", amount: 1, target: "friendly", trigger: "base-success" }],
  hooper: [{ kind: "self-power", amount: 1, trigger: "base-success" }, { kind: "target-power", amount: -1, target: "enemy", trigger: "base-success" }, { kind: "self-power", amount: 1, trigger: "base-success" }],
  baby: Array.from({ length: 3 }, () => ({ kind: "self-power" as const, amount: 1 as const, trigger: "base-success" as const })),
  oink: [{ kind: "target-power", amount: -1, target: "enemy", trigger: "base-success" }, { kind: "self-power", amount: 1, trigger: "base-success" }, { kind: "target-power", amount: -1, target: "enemy", trigger: "base-success" }],
  snow: [{ kind: "self-power", amount: 1, trigger: "base-success" }, { kind: "target-power", amount: -1, target: "enemy", trigger: "base-success" }, { kind: "self-power", amount: 1, trigger: "base-success" }],
  wifey: Array.from({ length: 3 }, () => ({ kind: "self-power" as const, amount: 1 as const, trigger: "base-success" as const })),
  drfade: [{ kind: "target-power", amount: 1, target: "friendly", trigger: "base-success" }, { kind: "self-power", amount: 1, trigger: "base-success" }, { kind: "target-power", amount: -1, target: "enemy", trigger: "base-success" }],
  barber: [{ kind: "self-power", amount: 1, trigger: "base-success" }, { kind: "target-power", amount: 1, target: "friendly", trigger: "base-success" }, { kind: "target-power", amount: -1, target: "enemy", trigger: "base-success" }],
  bottle: Array.from({ length: 3 }, () => ({ kind: "self-power" as const, amount: 1 as const, trigger: "base-success" as const })),
  sneaker: Array.from({ length: 3 }, () => ({ kind: "self-power" as const, amount: 1 as const, trigger: "base-success" as const })),
  church: [{ kind: "target-power", amount: 1, target: "friendly", trigger: "base-success" }, { kind: "self-power", amount: 1, trigger: "base-success" }, { kind: "target-power", amount: 1, target: "friendly", trigger: "base-success" }],
  landlord: Array.from({ length: 3 }, () => ({ kind: "self-power" as const, amount: 1 as const, trigger: "base-success" as const })),
  carmeet: Array.from({ length: 3 }, () => ({ kind: "self-power" as const, amount: 1 as const, trigger: "base-success" as const })),
  promoter: Array.from({ length: 3 }, () => ({ kind: "self-power" as const, amount: 1 as const, trigger: "base-success" as const })),
  nail: [{ kind: "target-power", amount: 1, target: "friendly", trigger: "base-success" }, { kind: "self-power", amount: 1, trigger: "base-success" }, { kind: "target-power", amount: 1, target: "friendly", trigger: "base-success" }],
  og: [{ kind: "self-power", amount: 1, trigger: "base-success" }, { kind: "target-power", amount: -1, target: "enemy", trigger: "base-success" }, { kind: "self-power", amount: 1, trigger: "base-success" }],
  delivery: Array.from({ length: 3 }, () => ({ kind: "self-power" as const, amount: 1 as const, trigger: "base-success" as const })),
};

const upgrade = (cardId: string, index: 0 | 1 | 2, name: string, description: string): AbilityUpgrade => {
  const effect = upgradeEffects[cardId][index];
  const mechanics = effect.kind === "self-power"
    ? "After the base ability succeeds, this card gains +1 Hands."
    : `After the base ability succeeds, its ${effect.target} target ${effect.amount > 0 ? "gains +1" : "loses 1"} Hands.`;
  return {
    id: `${cardId}:upgrade:${index + 1}`,
    name,
    description: `${description} ${mechanics}`,
    unlockLevel: ABILITY_UPGRADE_UNLOCK_LEVELS[index],
    effect,
  };
};

const upgrades = (cardId: string, entries: readonly [string, string, string, string, string, string][]) =>
  entries.flatMap((entry) => [0, 1, 2].map((index) =>
    upgrade(cardId, index as 0 | 1 | 2, entry[index * 2], entry[index * 2 + 1]),
  )) as readonly AbilityUpgrade[];
export type Deck = {
  id: string;
  name: string;
  archetype: string;
  accent: string;
  plan: string;
  cards: string[];
  hero: string;
};

export const CARD_RARITIES = ["SuperCommon", "Common", "Uncommon", "Rare", "Epic", "Legendary", "Mythical"] as const;
export type CardRarity = (typeof CARD_RARITIES)[number];

export type CardRarityDefinition = {
  name: CardRarity;
  label: string;
  order: number;
  color: string;
  cue: string;
  accessibilityLabel: string;
};

export const CARD_RARITY_DEFINITIONS: Record<CardRarity, CardRarityDefinition> = {
  SuperCommon: { name: "SuperCommon", label: "Super Common", order: -1, color: "#cbb99c", cue: "◇", accessibilityLabel: "Super Common rarity, one outline diamond" },
  Common: { name: "Common", label: "Common", order: 0, color: "#a8ada9", cue: "◆", accessibilityLabel: "Common rarity, one diamond" },
  Uncommon: { name: "Uncommon", label: "Uncommon", order: 1, color: "#4ade80", cue: "◆◆", accessibilityLabel: "Uncommon rarity, two diamonds" },
  Rare: { name: "Rare", label: "Rare", order: 2, color: "#3b82f6", cue: "◆◆◆", accessibilityLabel: "Rare rarity, three diamonds" },
  Epic: { name: "Epic", label: "Super Rare", order: 3, color: "#a855f7", cue: "◆◆◆◆", accessibilityLabel: "Super Rare rarity, four diamonds" },
  Legendary: { name: "Legendary", label: "Legendary", order: 4, color: "#eab308", cue: "◆◆◆◆◆", accessibilityLabel: "Legendary rarity, five diamonds" },
  Mythical: { name: "Mythical", label: "Mythical", order: 5, color: "#ef4444", cue: "◆◆◆◆◆◆", accessibilityLabel: "Mythical rarity, six diamonds" },
};

export type CardVariantSlot = {
  id: string;
  name: string;
  description: string;
  shardCost: number;
};

export type CatalogCard = Card & {
  catalogId: string;
  engineId: string;
  artworkId: string;
  rarity: CardRarity;
  faction: string;
  crewTags: string[];
  acquisitionSources: string[];
  variantSlots: CardVariantSlot[];
};

export type DeckLegality = {
  valid: boolean;
  issues: string[];
  missingCardIds: string[];
  unknownCardIds: string[];
};

export const cards: Record<string, Card> = {
  buddy: { id: "buddy", name: "BUDDY", kind: "character", type: "Plant", cost: 3, power: 4, ability: "Buddy Buds", effect: "Normal form: cards played in BUDDY's district cost 1 less Motion (minimum 0). After two rounds, BUDDY gains +3 Hands and planted Buddy Buds sprout. On reveal, plant Buds in two or three randomly chosen eligible districts; when each Bud sprouts, it gives +3 Hands to the last eligible friendly character already in its district. Full districts are skipped; Buds that sprout with no eligible friendly recipient remain harmless and give no Hands. Buds planted too late to sprout before match end are not placed.", roles: ["Growth", "Support"], abilityUpgrades: upgrades("buddy", [["Strong Roots", "BUDDY's Buds draw strength into their roots.", "Earthbound", "BUDDY's Buds anchor BUDDY more firmly.", "Deep Roots", "BUDDY's growth keeps drawing strength."]]), entryVfx: { accent: "#74a84a" }, portraitAccent: "#74a84a" },
  folks: { id: "folks", name: "FOLKS", kind: "character", type: "Fire", cost: 4, power: 3, ability: "Whole Block Hot", effect: "On Reveal: Apply 3 Burn to every enemy on the board. Give every other friendly Fire character +1 Hand. Burn deals its stacked Hands loss once at round end; Fire deals +1 Burn against Plant.", roles: ["Disruption", "Support"], abilityUpgrades: upgrades("folks", [["Heat Check", "After the ability succeeds, FOLKS gains +1 Hand.", "Feed the Flame", "One Fire ally buffed by the ability gains another Hand.", "Still Hot", "After the ability succeeds, FOLKS gains +1 Hand."]]), entryVfx: { accent: "#ff6b25" }, portraitAccent: "#ff6b25" },
  drfade: { id: "dr-fade", name: "Dr. Fade", kind: "character", type: "Light", cost: 4, power: 6, ability: "The First Lesson", effect: "On Reveal: Give the strongest enemy here -2 Hands. Give your weakest ally in another district +2 Hands.", roles: ["Pressure", "Support"], abilityUpgrades: upgrades("drfade", [["Corner Advice", "Your coached ally gains another Hand.", "Lead by Example", "Dr. Fade gets stronger.", "Class Dismissed", "Your punch hits harder."]]), entryVfx: { accent: "#69e7a3" }, portraitAccent: "#69e7a3" },
  guap: { id: "guap", name: "GUAP", type: "Fire", cost: 6, power: 6, ability: "FINNAM!", effect: "On Reveal: Gain +1 Hands for each other friendly character across the board, up to +5. Give every enemy across the board -1 Hands. Once per round. Ongoing: While GUAP is in your hand, your other Fire characters gain +1 Hands at round end.", roles: ["Pressure", "Disruption"], elementalBond: "Fire", abilityUpgrades: upgrades("guap", [["Golden Charge", "FINNAM! gathers golden energy.", "Falcon Ascendant", "FINNAM! spreads its burning wings.", "Phoenix Supernova", "FINNAM! erupts in a golden supernova."]]), entryVfx: { accent: "#f5c542" }, portraitAccent: "#f5c542" /* GUAP is the Fire bond in the elemental-bond system; Ice Cream Truck is Water, Rooftop Gardener is Plant, Pirate Radio DJ is Electric. */ },
  bossbabe: { id: "boss-babe", name: "Boss Bae", type: "Electric", cost: 3, power: 3, ability: "Network Boost", effect: "The first 2 times you play a card in another district, gain +1 Hands. After the second, your next card costing 4 or more costs 1 less Motion.", abilityUpgrades: upgrades("bossbabe", [["First Meeting", "Network Boost grants +1 Hands to Boss Bae.", "Closing Deals", "Network Boost grants +1 Hands to Boss Bae.", "Corner Office", "Network Boost grants +1 Hands to Boss Bae."]]) },
  scammer: { id: "scammer", name: "Scammer", type: "Dark", cost: 3, power: 3, ability: "Imposter", effect: "On Reveal: Copy the base Hands (up to 7) and printed ability of the highest-Hands enemy here. Copied On Reveal abilities do not trigger.", roles: ["Disruption", "Copy"], abilityUpgrades: upgrades("scammer", [["New Alias", "Imposter grants +1 Hands to Scammer.", "Fine Print", "Imposter grants +1 Hands to Scammer.", "Perfect Cover", "Imposter grants +1 Hands to Scammer."]]) },
  rastamon: { id: "rastamon", name: "Rastamon", type: "Plant", cost: 2, power: 2, ability: "Natural Cure", effect: "Cleanse a frozen or silenced ally here and give it +2 Hands. If none needs cleansing, give your weakest other ally here +1 Hand.", abilityUpgrades: upgrades("rastamon", [["Rooted Remedy", "Natural Cure grants +1 Hands to Rastamon.", "Herbal Guard", "Natural Cure grants +1 Hands to Rastamon.", "Evergreen", "Natural Cure grants +1 Hands to Rastamon."]]), entryVfx: { accent: "#4ade80", keyframeId: "vine-burst" }, portraitAccent: "#4ade80", immersiveAssetId: { backgroundAssetId: "assets/cards/immersive/rastamon/bg.webp", foregroundAssetId: "assets/cards/immersive/rastamon/fg.webp" } },
  roaster: { id: "all-jokes-roaster", name: "All Jokes Roaster", type: "Air", cost: 3, power: 3, ability: "Ratio'd Receipts", effect: "On Reveal: Apply 1 Burn to the highest-Hands enemy here and deal 1 immediate damage, or 2 if it was played this round.", roles: ["Disruption"], abilityUpgrades: upgrades("roaster", [["Extra Receipts", "Ratio'd Receipts grants +1 Hands to Roaster.", "Pinned Reply", "Ratio'd Receipts grants +1 Hands to Roaster.", "Closing Argument", "Ratio'd Receipts grants +1 Hands to Roaster."]]), entryVfx: { accent: "#a78bfa" }, portraitAccent: "#a78bfa" },
  nerd: { id: "closet-nerd", name: "Closet Nerd", type: "Dark", cost: 3, power: 3, ability: "Unaware", effect: "Silence the highest-Hands enemy here, bypassing Wifey's Side Eye. Protection on that enemy still blocks this.", roles: ["Disruption"], abilityUpgrades: upgrades("nerd", [["Deep Read", "Unaware grants +1 Hands to Nerd.", "Receipts Folder", "Unaware grants +1 Hands to Nerd.", "Final Draft", "Unaware grants +1 Hands to Nerd."]]) },
  cornball: { id: "cornball", name: "Cornball", type: "Normal", cost: 1, power: 1, ability: "Scare the Hoes", effect: "On Reveal: Apply 1 Burn to every enemy here.", roles: ["Disruption"], abilityUpgrades: upgrades("cornball", [["Awkward Energy", "Scare the Hoes grants +1 Hands to Cornball.", "No Chill", "Scare the Hoes grants +1 Hands to Cornball.", "Room Clearer", "Scare the Hoes grants +1 Hands to Cornball."]]) },
  plug: { id: "plug", name: "Plug", type: "Electric", cost: 1, power: 2, ability: "Connections", effect: "Your next card in another district costs 1 less Motion.", abilityUpgrades: upgrades("plug", [["Open Line", "Connections grants +1 Hands to Plug.", "Direct Connect", "Connections grants +1 Hands to Plug.", "Network King", "Connections grants +1 Hands to Plug."]]), entryVfx: { accent: "#22d3ee" }, portraitAccent: "#22d3ee" },
  streamer: { id: "live-streamer", name: "Live Streamer", type: "Electric", cost: 2, power: 3, ability: "Follower Frenzy", effect: "On Reveal: Reset your cheap-play trigger counter. The next 2 cards you play this turn with cost 2 or less gain +1 Hand each.", abilityUpgrades: upgrades("streamer", [["Chat Hype", "Follower Frenzy grants +1 Hands to Streamer.", "Trending", "Follower Frenzy grants +1 Hands to Streamer.", "Front Page", "Follower Frenzy grants +1 Hands to Streamer."]]) },
  gamer: { id: "gamer", name: "Gamer", type: "Dark", cost: 3, power: 3, ability: "City Tour", effect: "On Reveal: Give your lowest-Hands ally in each other district +2 Hands. Ongoing: While on board, the first time each round you newly Silence or Weaken an enemy, your lowest-Hands Dark ally gains +2 Hands.", abilityUpgrades: upgrades("gamer", [["Warmup", "City Tour grants +1 Hands to Gamer.", "Ranked Focus", "City Tour grants +1 Hands to Gamer.", "Clutch Mode", "City Tour grants +1 Hands to Gamer."]]) },
  techbro: { id: "techbro-rich", name: "Techbro Rich", type: "Electric", cost: 3, power: 4, ability: "VC Funded Flex", effect: "On Reveal: If another friendly card is here, gain +2 Hands.", abilityUpgrades: upgrades("techbro", [["Seed Round", "VC Funded Flex grants +1 Hands to Techbro.", "Series A", "VC Funded Flex grants +1 Hands to Techbro.", "Unicorn", "VC Funded Flex grants +1 Hands to Techbro."]]) },
  bikelife: { id: "bikelife-yn", name: "Bikelife YN", type: "Electric", cost: 2, power: 2, ability: "Ride Out", effect: "After reveal, ride to your weakest other district and gain +1 Hands.", abilityUpgrades: upgrades("bikelife", [["Wheelie", "Ride Out grants +1 Hands to Bikelife.", "Night Ride", "Ride Out grants +1 Hands to Bikelife.", "City Loop", "Ride Out grants +1 Hands to Bikelife."]]) },
  vibe: { id: "cool-vibe-yn", name: "Cool Vibe YN", type: "Water", cost: 2, power: 2, ability: "Wave Check", effect: "Pull your lowest ally from another district here. Both gain +1 Hands.", abilityUpgrades: upgrades("vibe", [["Good Energy", "Wave Check grants +1 Hands to Vibe.", "Tidal Pull", "Wave Check grants +1 Hands to Vibe.", "High Tide", "Wave Check grants +1 Hands to Vibe."]]) },
  hooper: { id: "hooper", name: "Hooper", type: "Fire", cost: 5, power: 5, ability: "Ankle Breaker", effect: "If losing here, enemy highest gets -2 and Hooper gains +2.", abilityUpgrades: upgrades("hooper", [["First Step", "Ankle Breaker grants +1 Hands to Hooper.", "Hot Hand", "Ankle Breaker grants +1 Hands to Hooper.", "Game Winner", "Ankle Breaker grants +1 Hands to Hooper."]]) },
  baby: { id: "baby-momma", name: "Baby Momma", type: "Fire", cost: 4, power: 5, ability: "Mama Bear", effect: "If opponent has more cards here, gain +2 Hands.", abilityUpgrades: upgrades("baby", [["Watchful Eye", "Mama Bear grants +1 Hands to Baby Momma.", "Protective", "Mama Bear grants +1 Hands to Baby Momma.", "Mama Lion", "Mama Bear grants +1 Hands to Baby Momma."]]) },
  oink: { id: "officer-oink", name: "Officer Oink", type: "Normal", cost: 5, power: 6, ability: "Civic Pressure", effect: "On Reveal: Apply Weaken to every enemy card here. Gain +1 Hands for each enemy Weakened.", roles: ["Disruption"], abilityUpgrades: upgrades("oink", [["Patrol", "Civic Pressure grants +1 Hands to Officer Oink.", "Crackdown", "Civic Pressure grants +1 Hands to Officer Oink.", "Lockdown", "Civic Pressure grants +1 Hands to Officer Oink."]]) },
  snow: { id: "snow-bunny", name: "Snow Bunny", type: "Water", cost: 3, power: 2, ability: "Cold Shoulder", effect: "Freeze the highest enemy card here. Frozen cards add 0 Hands until cleansed.", roles: ["Disruption"], abilityUpgrades: upgrades("snow", [["Frostbite", "Cold Shoulder grants +1 Hands to Snow Bunny.", "Ice Cold", "Cold Shoulder grants +1 Hands to Snow Bunny.", "Whiteout", "Cold Shoulder grants +1 Hands to Snow Bunny."]]), entryVfx: { accent: "#60a5fa" }, portraitAccent: "#60a5fa" },
  wifey: { id: "wifey", name: "Wifey", type: "Normal", cost: 4, power: 4, ability: "Side Eye", effect: "Block the first targeted enemy effect here each round.", abilityUpgrades: upgrades("wifey", [["Sharp Look", "Side Eye grants +1 Hands to Wifey.", "Read the Room", "Side Eye grants +1 Hands to Wifey.", "Unbothered", "Side Eye grants +1 Hands to Wifey."]]), entryVfx: { accent: "#fda4af" }, portraitAccent: "#fda4af", immersiveAssetId: { backgroundAssetId: "assets/cards/immersive/wifey/bg.webp", foregroundAssetId: "assets/cards/immersive/wifey/fg.webp" } },
  barber: { id: "barber-bro", name: "Barber Bro", type: "Normal", cost: 4, power: 4, ability: "Line Up", effect: "On Reveal: Give your lowest-Hands other card here +2 Hands. Give the highest-Hands enemy here -1 Hands.", roles: ["Disruption"], abilityUpgrades: upgrades("barber", [["Fresh Fade", "Line Up grants +1 Hands to Barber Bro.", "Detail Work", "Line Up grants +1 Hands to its friendly target.", "Clean Finish", "Line Up makes its enemy target lose 1 more Hands."]]) },
  bottle: { id: "bottle-girl", name: "Bottle Girl", type: "Poison", cost: 2, power: 3, ability: "Last Call", effect: "On Reveal: If played on Round 4 or later, gain +2 Hands. Your next Poison character costs 1 less Motion, minimum 1, through the next round.", abilityUpgrades: upgrades("bottle", [["After Hours", "Last Call grants +1 Hands to Bottle Girl.", "VIP Section", "Last Call grants +1 Hands to Bottle Girl.", "Closing Time", "Last Call grants +1 Hands to Bottle Girl."]]) },
  sneaker: { id: "sneaker-reseller", name: "Sneaker Reseller", type: "Normal", cost: 3, power: 3, ability: "Flip Season", effect: "On Reveal: Gain +X Hands where X is the printed Power of the highest-Hands enemy on the board, up to +3. Apply Weaken to that enemy.", abilityUpgrades: upgrades("sneaker", [["Authenticated", "Flip Season grants +1 Hands to Sneaker Reseller.", "Markup", "Flip Season grants +1 Hands to Sneaker Reseller.", "Sold Out", "Flip Season grants +1 Hands to Sneaker Reseller."]]) },
  church: { id: "church-auntie", name: "Church Auntie", type: "Light", cost: 3, power: 4, artworkLayout: "portrait", ability: "Covered", effect: "On Reveal: Give your lowest-Hands other ally here +3 Hands if Light, or +2 otherwise, and Protect. Ongoing: While on board, the first time each round protection blocks a hostile effect on one of your Light characters, it gains +2 Hands.", abilityUpgrades: upgrades("church", [["Prayer Circle", "Covered grants +1 Hands to its friendly target.", "Sunday Best", "Covered grants +1 Hands to Church Auntie.", "Amen Corner", "Covered grants +1 Hands to its friendly target."]]) },
  landlord: { id: "landlord", name: "Landlord", type: "Earth", cost: 2, power: 3, ability: "Rent Due", effect: "Ongoing: The first enemy card played at this district each round costs 1 additional Motion. When that tax is actually paid, Landlord gains +1 Hands once per round.", roles: ["Disruption"], abilityUpgrades: upgrades("landlord", [["Late Fee", "Rent Due grants +1 Hands to Landlord.", "Lease Renewal", "Rent Due grants +1 Hands to Landlord.", "Keyholder", "Rent Due grants +1 Hands to Landlord."]]), entryVfx: { accent: "#d4a373" }, portraitAccent: "#d4a373" },
  carmeet: { id: "car-meet-kid", name: "Car Meet Kid", type: "Electric", cost: 2, power: 2, ability: "Sideshow", effect: "On Reveal: Move Car Meet Kid to your weakest other district. Then give its lowest-Hands other friendly card +1 Hands.", roles: ["Movement"], abilityUpgrades: upgrades("carmeet", [["Clean Slide", "Sideshow grants +1 Hands to Car Meet Kid.", "Rev Limit", "Sideshow grants +1 Hands to Car Meet Kid.", "Burnout", "Sideshow grants +1 Hands to Car Meet Kid."]]) },
  promoter: { id: "promoter", name: "Promoter", type: "Air", cost: 3, power: 3, ability: "Guest List", effect: "On Reveal: Reveal one enemy hand card. If it costs 4+, your next card in another district costs 1 less Motion. Ongoing: While on board, the first Air ally, Bottle Girl, Pirate Radio DJ, or Dance Captain to move each round gains +2 Hands (one shared trigger).", abilityUpgrades: upgrades("promoter", [["Plus One", "Guest List grants +1 Hands to Promoter.", "Wristband", "Guest List grants +1 Hands to Promoter.", "Headliner", "Guest List grants +1 Hands to Promoter."]]) },
  nail: { id: "nail-tech", name: "Nail Tech", type: "Poison", cost: 2, power: 3, ability: "Fresh Set", effect: "On Reveal: Give another friendly card here +2 Hands. The next time that card is hit by an enemy Hands reduction, reduce that loss by 1.", abilityUpgrades: upgrades("nail", [["Chrome Finish", "Fresh Set grants +1 Hands to its friendly target.", "Gem Detail", "Fresh Set grants +1 Hands to Nail Tech.", "Top Coat", "Fresh Set grants +1 Hands to its friendly target."]]) },
  og: { id: "og-uncle", name: "OG Uncle", type: "Fire", cost: 4, power: 5, ability: "Back In My Day", effect: "On Reveal: If your opponent has more total cards on the board than you, gain +3 Hands. If they have at least 3 more, also give their lowest-Hands card here -1 Hands.", roles: ["Disruption"], abilityUpgrades: upgrades("og", [["Real History", "Back In My Day grants +1 Hands to OG Uncle.", "Outside Check", "Back In My Day makes its enemy target lose 1 more Hands.", "Old School", "Back In My Day grants +1 Hands to OG Uncle."]]) },
  delivery: { id: "delivery-demon", name: "Delivery Demon", type: "Air", cost: 1, power: 1, ability: "Drop Off", effect: "On Reveal: Move the lowest-Hands other friendly 1- or 2-Cost card here to your weakest other district.", roles: ["Movement"], abilityUpgrades: upgrades("delivery", [["Express Route", "Drop Off grants +1 Hands to Delivery Demon.", "Priority Order", "Drop Off grants +1 Hands to Delivery Demon.", "Doorstep", "Drop Off grants +1 Hands to Delivery Demon."]]) },
  ...neighborhoodCommons,
  ...superCommonCards,
  ...expansionCards,
  ...supportCards,
  ...streetWaveCards,
  ...mythicLegendCards,
  ...characterWaveCards,
  ...homecomingCards,
  ...selectedCards,
  ...neighborhoodWaveCards,
  ...cellblockWaveCards,
  ...fairytaleCards,
  ...afterHoursWaveCards,
  ...elementalBondWaveCards,
  ...kumiteCards,
  ...sideOzWaveCards,
  ...storyCharacterWaveCards,
  ...tripleOgCards,
  ...blockbusterWaveCards,
  ...squabblehouseWaveCards,
  ...streetLegendsCards,
  ...musicIndustryWaveCards,
  kyle: { id: 'kyle', name: 'KYLE', kind: 'character', type: 'Fire', cost: 4, power: 4, ability: 'Smile Bombs', effect: 'On Reveal: Plant 4 Smile Bombs in random enemy districts. At the start of the next round, each explodes for -2 Hands to one random enemy in its district. KYLE gains +1 Hands for every enemy hit, plus +1 more if that enemy is destroyed.', roles: ['Disruption', 'Growth'], artworkLayout: 'portrait', abilityUpgrades: upgrades('kyle', [['Good Company', 'Keep smiling.', 'Big Grin', 'Turn up the pressure.', 'Last Laugh', 'Make it count.']]), entryVfx: { accent: '#ffe02e' }, portraitAccent: '#ffe02e' },
  stockz: { id: 'stockz', name: 'STOCKZ', kind: 'character', type: 'Electric', cost: 3, power: 3, ability: 'Compound Interest', effect: 'Ongoing: After you play another character in any district, gain +1 Hand. This continues for the rest of the game.', roles: ['Growth', 'Combo'], artworkLayout: 'portrait', abilityUpgrades: upgrades('stockz', [['Seed Money', 'Build your position.', 'Reinvest', 'Let the gains compound.', 'Long Game', 'Stay invested.']]), entryVfx: { accent: '#8aff68' }, portraitAccent: '#8aff68' },
};

applyCreativeCardKits(cards);
applyRosterBalance(cards);
applyFullRosterBuffs(cards);
applyCrewMatchupBalance(cards);
applyElementalHandBonuses(cards);
applyBasePvpBalance(cards);

/** Complete authored crews without changing their existing draw order. Never use for submitted decks. */
export function completeEngineCrew(ids: readonly string[], candidates: readonly string[] = ['buspass', 'soulfood', 'cognac', 'bustdown', 'energydrink', 'subwaymap']): string[] {
  const result = [...ids];
  for (const id of [...candidates, ...Object.keys(cards)]) {
    if (result.length >= DECK_SIZE) break;
    if (cards[id] && !isKumiteExclusiveCard(id) && !result.includes(id)) result.push(id);
  }
  return result;
}

/** Throws at content-build time rather than allowing an incomplete ability path to ship. */
export function validateCardAbilityUpgrades(value: Record<string, Card> = cards): Record<string, Card> {
  for (const [cardId, card] of Object.entries(value)) {
    const path = card.abilityUpgrades;
    if (!Array.isArray(path) || path.length !== ABILITY_UPGRADE_COUNT) throw new Error(`${cardId} must have exactly three ability upgrades`);
    path.forEach((item, index) => {
      if (!item.name.trim() || !item.description.trim() || item.id !== `${cardId}:upgrade:${index + 1}`) throw new Error(`${cardId} has an invalid ability upgrade`);
      const expected = upgradeEffects[cardId]?.[index];
      if (item.unlockLevel !== ABILITY_UPGRADE_UNLOCK_LEVELS[index] || !expected || JSON.stringify(item.effect) !== JSON.stringify(expected)) throw new Error(`${cardId} has an unbalanced ability upgrade`);
    });
  }
  return value;
}
export const decks: Deck[] = [
  { id: "block", name: "THE BLOCK IS HOT", archetype: "Turf Control", accent: "LOCK", plan: "Claim two districts, tax entry, freeze threats, and close lanes.", cards: ["cornball", "snow", "roaster", "rastamon", "wifey", "oink", "baby"], hero: "officer-oink" },
  { id: "slide", name: "SLIDE THRU", archetype: "Movement", accent: "MOVE", plan: "Spread Hands early, then relocate it late into a moving target.", cards: ["cornball", "bikelife", "vibe", "plug", "snow", "hooper", "baby"], hero: "bikelife-yn" },
  { id: "combo", name: "WHO YOU KNOW", archetype: "Combo / Network", accent: "CHAIN", plan: "Build connections across districts, grow each follow-up play, then swing a contested lane with a closer.", cards: ["cornball", "plug", "streamer", "gamer", "techbro", "bossbabe", "wifey", "buspass", "stockz", "sneaker"], hero: "techbro-rich" },
  { id: "receipts", name: "RECEIPTS", archetype: "Disruption", accent: "EXPOSE", plan: "Expose the plan, Silence engines, and turn investments into bad ones.", cards: ["cornball", "roaster", "nerd", "snow", "plug", "baby", "hooper"], hero: "all-jokes-roaster" },
  { id: "crashout", name: "CRASHOUT SEASON", archetype: "Comeback", accent: "FLIP", plan: "Absorb early deficits, then flip contested districts with late Hands spikes.", cards: ["cornball", "rastamon", "snow", "wifey", "baby", "hooper", "roaster"], hero: "hooper" },
  { id: "vibes", name: "GOOD VIBES ONLY", archetype: "Sustain", accent: "CLEANSE", plan: "Cleanse, Protect, suppress hostile rules, and keep scaling pieces alive.", cards: ["rastamon", "wifey", "snow", "vibe", "hooper", "oink", "plug"], hero: "rastamon" },
  { id: "compound", name: "COMPOUND INTEREST", archetype: "Growth / Scaling", accent: "GROW", plan: "Invest early in STOCKZ and BUDDY, then freeze a threat from The Opps while follow-up plays build late district value.", cards: ["cornball", "plug", "streamer", "rastamon", "gamer", "stockz", "snow", "buspass", "buddy", "cognac"], hero: "gamer" },
  { id: "voltage", name: "VOLTAGE IN MOTION", archetype: "Electric Tempo", accent: "CHARGE", plan: "Keep an Electric bond in hand, spread plays across districts, and turn clean sequencing into extra tempo.", cards: ["batteryback", "circuitcaptain", "wiretap", "livewire", "stockz", "bossbabe", "plug", "streamer", "techbro", "bikelife"], hero: "circuit-captain" },
  { id:'sunday-dinner',name:'FIX YOU A PLATE',archetype:'Fire / Family Movement',accent:'FAMILY',plan:'Move the family between districts, serve real recovery, and convert arrivals and Burn into a bounded dinner finish.',cards:['the-favorite-grandchild','cousin-back-from-college','plate-auntie','church-aunties-rival','big-sister','second-plate-cousin','grill-uncle','grandma-said-sit-down','group-chat-instigator','black-air-fade-1s'],hero:'grandma-said-sit-down' },
  { id:'fitness-routes',name:'NO EQUIPMENT NEEDED',archetype:'Fitness / Circuit',accent:'ROUTE',plan:'Cheap runners establish a three-district circuit. Spotter protects the first leg; Last Set and OG Calisthenics convert complete routes into crew value.',cards:['track-suit-auntie','gym-bag-yn','stairwell-sprinter','gym-spotter-yn','calisthenics-yn','jump-rope-menace','personal-trainer','fitness-girl','last-set-og','og-calisthenics'],hero:'og-calisthenics' },
  { id:'music-tour',name:'TOUR MONEY',archetype:'Music / Movement',accent:'TOUR',plan:'Wake up the couch, establish a second stage, bring the tour together, then cash a bounded Merch discount and One-Man Band finish.',cards:['studio-couch-yn','the-opening-act','mixtape-cousin','the-rapper','the-hype-man','tour-van-driver','merch-table-hustler','the-manager-nice','the-dj','one-man-band'],hero:'one-man-band' },
  { id:'community-table',name:'EVERYBODY EATS',archetype:'Homeless / Recovery',accent:'COMMUNITY',plan:'Cook heals the Homeless crew, then cleanses, strengthens and protects each meal recipient. Foodz cleanses the whole board and serves one protected community meal in each district. Bus and Cyclist spread the crew, Unc restores voices, Booster checks enemy growth, and Cracked Head finishes a crowded district.',cards:['homelessguy','homelessyn','homelesslegend','cracked-head','community-cook','foodz','night-bus-driver','delivery-app-cyclist','bluetooth-unc','booster'],hero:'community-cook' },
  { id: 'music-industry', name: 'WHO GOT THE AUX', archetype: 'Music / Sequencing', accent: 'PERFORM', plan: 'Soundcheck a second stage, perform across districts, protect the artist, Spinback one entrance, and Pass the Torch into the finish.', cards: [...MUSIC_INDUSTRY_IDS], hero: 'the-og-rap-legend' },
  { id: 'fitness-circuit', name: 'ONE MORE REP', archetype: 'Fitness / Movement', accent: 'TRAIN', plan: 'Train a circuit across three districts, recover actual damage, and earn a bounded comeback after an athlete falls.', cards: ['failedathlete', 'fitness-girl', 'fitness-bro', 'personal-trainer', 'lash-tech', 'apartment-maintenance-sage', 'yn-atv-lord', 'hooper', 'sportsprodigy', 'demon-trainer'], hero: 'demon-trainer' },
  { id: "squabblehouse-shift", name: "SQUABBLEHOUSE SHIFT", archetype: "Staff & Support", accent: "SHIFT", plan: "Bring the diner staff together across all three districts for Waffle Warlord, while Bus Boy clears a lane, Cashier pins a threat, and A Side of Hands serves both sides. Teknician echoes staff reveals and Janitor reverses attacks. Dogs and Triple OGs belong in gang decks.", cards: ["squabble-house-manager", "squabblehouse-bus-boy", "squabblehouse-cashier", "squabblehouse-security", "squabblehouse-teknician", "griddle-master", "inmate-reformed", "janitor", "waffle-warlord", "sideofhands"], hero: "squabblehouse-security" },
].map(deck => ({ ...deck, cards: completeEngineCrew(deck.cards) }));

export const rarityByEngineId = {
  buddy: "Legendary",
  folks: "Legendary",
  drfade: "Legendary",
  ...streetWaveRarities,
  ...mythicLegendRarities,
  ...characterWaveRarities,
  ...homecomingRarities,
  ...selectedRarities,
  ...fairytaleRarities,
  ...neighborhoodWaveRarities,
  ...cellblockWaveRarities,
  ...afterHoursWaveRarities,
  ...elementalBondWaveRarities,
  ...kumiteCardRarities,
  ...sideOzWaveRarities,
  ...storyCharacterWaveRarities,
  ...tripleOgRarities,
  ...blockbusterWaveRarities,
  ...squabblehouseRarityById,
  ...streetLegendsRarities,
  ...musicIndustryRarities,
  // City Legends overrides: four utility focused legends sit below the Mythical finishers.
  dragonflyjones: "Legendary",
  tron: "Legendary",
  mansamusa: "Legendary",
  shonuff: "Legendary",
  ashlee: "Mythical",
  captainjigga: "Mythical",
  // johnhenry + yasuke stay Mythical — no override needed (source already says Mythical).
  ...supportRarities,
  guap: "Mythical",
  ...expansionRarities,
  // Street Wave + Expansion overrides — Wave 1 tier inflation cleanup.
  bbldemon: "Legendary",
  redpill: "Legendary",
  sportsprodigy: "Legendary",
  failedathlete: "Rare",
  piratedj: "Epic",
  cornercoach: "Uncommon",
  mural: "Uncommon",
  shiesty: "SuperCommon", torta: "SuperCommon", waterboy: "SuperCommon", buspass: "SuperCommon",
  cognac: "SuperCommon", bustdown: "SuperCommon", soulfood: "SuperCommon", concrete: "SuperCommon",
  bossbabe: "Rare", scammer: "Rare",
  youngbull: "Common", transplant: "Common", tayaty: "Common", edgar: "Common", nguyen: "Common", manman: "Common",
  pinaynurse: "Common", honestthot: "Common", earthy: "Common", abuela: "Common", icecream: "Common",
  cornball: "Common",
  hooper: "Rare",
  plug: "Common",
  snow: "Common",
  wifey: "Common",
  baby: "Uncommon",
  bikelife: "Uncommon",
  gamer: "Epic",
  rastamon: "Uncommon",
  vibe: "Rare",
  nerd: "Rare",
  roaster: "Rare",
  streamer: "Rare",
  oink: "Legendary",
  kyle: "Legendary",
  stockz: "Rare",
  techbro: "Legendary",
  barber: "Uncommon",
  bottle: "Rare",
  sneaker: "Legendary",
  church: "Epic",
  landlord: "Legendary",
  carmeet: "Uncommon",
  promoter: "Epic",
  nail: "Uncommon",
  og: "Mythical",
  delivery: "Common",
} as const satisfies Record<keyof typeof cards, CardRarity>;

export function validateCardCatalogRarities(
  cardEntries: Record<string, Card> = cards,
  assignments: Record<string, unknown> = rarityByEngineId,
): void {
  const supported = new Set<string>(CARD_RARITIES);
  for (const engineId of Object.keys(cardEntries)) {
    const rarity = assignments[engineId];
    if (typeof rarity !== "string" || !supported.has(rarity)) {
      throw new Error(`Card ${engineId} has missing or unsupported rarity: ${String(rarity)}`);
    }
  }
  for (const engineId of Object.keys(assignments)) {
    if (!cardEntries[engineId]) {
      throw new Error(`Rarity assignment references unknown card ${engineId}`);
    }
  }
}

const factionByEngineId: Record<string, string> = {
  lola: "Old Heads Know", repoman: "Around the Block", madhatter: "Wonderland",
  ...Object.fromEntries(Object.entries(blockbusterWaveCards).map(([id,c]) => [id,c.kind === "blockbuster" ? "Blockbusters" : "Block Party"])),
  ...squabblehouseFactionById,
  ...streetLegendsFactions,
  ...musicIndustryFactions,
  ...selectedFactions,
  ...Object.fromEntries(Object.keys(afterHoursWaveCards).map(id => [id, 'After Hours'])),
  ...Object.fromEntries(Object.keys(elementalBondWaveCards).map(id => [id, 'Elemental Bonds'])),
  ...sideOzWaveFactions,
  'inmate-crafty': 'Cellblock', 'inmate-boyfriend': 'Cellblock', 'inmate-informant': 'Cellblock', 'inmate-contraband': 'Cellblock',
  'lebron-james': 'Independent',
  'hair-stylist': 'Neighborhood Creatives', stylist: 'Neighborhood Creatives',
  demario: 'Neighborhood Heroes', luigion: 'Neighborhood Heroes', 'black-cowboy': 'Independent',
  ...Object.fromEntries(Object.keys(fairytaleCards).map(id => [id, ['dorothy', 'scarecrow', 'tinman', 'lion', 'oz'].includes(id) ? 'The Wiz' : ['alice', 'cheshire', 'queenofhearts', 'mrrabbit'].includes(id) ? 'Wonderland' : 'Around the Block'])),
  ...Object.fromEntries(Object.keys(streetWaveCards).map(id => [id, streetWaveRarities[id] === 'Mythical' ? 'City Legends' : ['break', 'krump', 'bboy'].includes(id) ? 'The Cypher' : 'Around the Block'])),
  ...Object.fromEntries(Object.keys(mythicLegendCards).map(id => [id, 'City Legends'])),
  ...Object.fromEntries(Object.keys(tripleOgCards).map(id => [id, 'Triple OGs'])),
  ...Object.fromEntries(Object.keys(characterWaveCards).map(id => [id, characterWaveRarities[id] === 'Mythical' ? 'City Legends' : 'Around the Block'])),
  ...Object.fromEntries(Object.keys(supportCards).map(id => [id, 'Everyday Essentials'])),
  sideofhands: 'Squabblehouse',
  buddy: "City Legends",
  folks: "Around the Block",
  drfade: "Old Heads Know",
  guap: "City Legends",
  ...Object.fromEntries(Object.keys(expansionCards).map(id => [id, expansionRarities[id] === 'Mythical' ? 'City Legends' : 'Around the Block'])),
  bossbabe: "Who You Know",
  scammer: "Receipts",
  ...Object.fromEntries(Object.keys(neighborhoodCommons).map(id => [id, "Around the Block"])),
  'squabble-house-manager': 'Squabblehouse',
  squabblecook: 'Squabblehouse',
  squabbleserver: 'Squabblehouse',
  ...Object.fromEntries(Object.keys(superCommonCards).map(id => [id, "Everyday Essentials"])),
  rastamon: "Good Vibes",
  roaster: "Receipts",
  nerd: "Receipts",
  cornball: "The Block",
  plug: "Who You Know",
  streamer: "Who You Know",
  gamer: "Compound",
  kyle: "Good Vibes",
  stockz: "Compound",
  techbro: "Compound",
  bikelife: "Slide Thru",
  vibe: "Good Vibes",
  hooper: "Crashout",
  baby: "Crashout",
  oink: "The Block",
  snow: "The Block",
  wifey: "Good Vibes",
  barber: "City Never Sleeps",
  bottle: "The Function",
  sneaker: "City Never Sleeps",
  church: "Old Heads Know",
  landlord: "Rent's Due",
  carmeet: "Side Show",
  promoter: "The Function",
  nail: "City Never Sleeps",
  og: "Old Heads Know",
  delivery: "Side Show",
  ashlee: "City Legends",
  captainjigga: "City Legends",
};

const sourceByEngineId: Record<string, string[]> = {
  ...Object.fromEntries(Object.keys(kumiteCards).map(id => [id, ['Kumite progression']])),
  ...Object.fromEntries(Object.keys(afterHoursWaveCards).map(id => [id, ['Street Packs']])),
  ...Object.fromEntries(Object.keys(squabblehouseWaveCards).map(id => [id, ['Street Packs']])),
  ...Object.fromEntries(Object.keys(elementalBondWaveCards).map(id => [id, ['Street Packs']])),
  ...Object.fromEntries(Object.keys(sideOzWaveCards).map(id => [id, ['Street Packs']])),
  ...Object.fromEntries(STORY_ONLY_CARD_IDS.map(id => [id, ['Story Rewards']])),
  ...Object.fromEntries(Object.keys(cellblockWaveCards).map(id => [id, ['Street Packs']])),
  buddy: ["Street Packs"],
  folks: ["Street Packs"],
  drfade: ["Guaranteed tutorial Legendary", "Street Packs"],
  cornball: ["Starter gangs", "Street Packs"],
  snow: ["Starter gangs", "Collection Road"],
  roaster: ["Starter gangs", "Street Packs"],
  rastamon: ["Starter gangs", "Collection Road"],
  wifey: ["Starter gangs", "Street Packs"],
  oink: ["Starter gangs", "Collection Road"],
  baby: ["Starter gangs", "Street Packs"],
  bikelife: ["Starter gangs", "Collection Road"],
  vibe: ["Starter gangs", "Street Packs"],
  plug: ["Starter gangs", "Collection Road"],
  hooper: ["Starter gangs", "Street Packs"],
  streamer: ["Starter gangs", "Collection Road"],
  gamer: ["Starter gangs", "Street Packs"],
  techbro: ["Starter gangs", "Collection Road"],
  nerd: ["Starter gangs", "Chapter One boss"],
};

validateCardCatalogRarities();

export const cardCatalog: CatalogCard[] = Object.entries(cards).map(
  ([engineId, card]) => ({
    ...card,
    catalogId: card.id,
    engineId,
    artworkId: card.id,
    rarity: rarityByEngineId[engineId as keyof typeof rarityByEngineId],
    faction: isKumiteExclusiveCard(engineId) ? 'Kumite' : factionByEngineId[engineId] ?? "Independent",
    crewTags: decks
      .filter((deck) => deck.cards.includes(engineId))
      .map((deck) => deck.id).concat(Object.hasOwn(neighborhoodWaveCards, engineId) ? ['neighborhood'] : [],
        squabblehouseStaffCardIds.has(engineId) ? ['Squabblehouse'] : [],
        ['cane-corso-red', 'blue-nose-pit'].includes(engineId) ? ['OG-support'] : [],
        MUSIC_CHARACTER_IDS.includes(engineId) ? ['Music Industry'] : [],
        FITNESS_CHARACTER_IDS.includes(engineId) ? ['Fitness'] : [],
        selectedFactions[engineId] ? [selectedFactions[engineId]] : [],
        Object.hasOwn(streetLegendsCards, engineId) ? [engineId === 'lash-tech' ? 'Beauty' : 'Street Legends'] : [],
        Object.hasOwn(sideOzWaveCards, engineId) ? ['side-oz', sideOzWaveFactions[engineId] === 'Red Side' ? 'red-side'
          : sideOzWaveFactions[engineId] === 'Blue Side' ? 'blue-side' : 'the-wiz'] : []),
    acquisitionSources: sourceByEngineId[engineId] ?? (["barber", "bottle", "sneaker", "church", "landlord", "carmeet", "promoter", "nail", "og", "delivery"].includes(engineId) ? ["City Never Sleeps"] : ["Street Packs"]),
    variantSlots: [
      ...(FAIRYTALE_ALTERNATE_ART.some(id => id === card.id) ? [{
        id: card.id + ':alternate', name: 'Alternate Art',
        description: 'A second original illustration of this character.', shardCost: 180,
      }] : []),
      {
        id: `${card.id}:tagged`,
        name: "Tagged",
        description: "Raised gold ink, vermilion tags and a lacquered frame over the original foil.",
        shardCost: 80,
      },
      {
        id: `${card.id}:chrome`,
        name: "Chrome",
        description: "Reflective showcase frame for your favorite gang.",
        shardCost: 140,
      },
      {
        id: `${card.id}:prismatic`,
        name: "Prismatic Reverse Holo",
        description: "Ultimate spectral foil across the card stock and frame, with the character art kept sharp and matte.",
        shardCost: 300,
      },
      ...(engineId === 'colognecriminal' ? [{
        id: 'cologne-criminal:crazy',
        name: 'Crazy',
        description: 'The Cologne Criminal crashes through the frame in his full airborne showcase art.',
        shardCost: 180,
      }] : []),
    ],
  }),
);

export const catalogCardById = Object.fromEntries(
  cardCatalog.map((card) => [card.catalogId, card]),
) as Record<string, CatalogCard>;

export const catalogCardByEngineId = Object.fromEntries(
  cardCatalog.map((card) => [card.engineId, card]),
) as Record<string, CatalogCard>;

export const starterRecipes = decks.map((deck) => ({
  ...deck,
  catalogCardIds: deck.cards.map(
    (engineId) => catalogCardByEngineId[engineId].catalogId,
  ),
}));

// Fairytale characters are reserved for a later drop, never introductory recruits.
export const LATER_DROP_STARTER_IDS = ['alice', 'oz', 'tin-man', 'lion', 'dorothy', 'scarecrow', 'cheshire', 'queen-of-hearts'] as const;
export const STARTER_STREET_REPLACEMENTS: Record<string, string> = {
  alice: 'bikelife-yn', oz: 'dr-fade', 'tin-man': 'wifey', lion: 'hooper',
  dorothy: 'cool-vibe-yn', scarecrow: 'bus-pass', cheshire: 'plug', 'queen-of-hearts': 'all-jokes-roaster',
};

// Versioned onboarding entitlement, not a playable recipe or faction restriction.
export const ROOKIE_FOUNDATION_ID = "foundation-v1";
export const ROOKIE_DECK_ID = "my-first-crew";
export const ROOKIE_CORE_IDS = ["cornball", "plug", "snow-bunny", "wifey", "hooper", "rastamon", "all-jokes-roaster", "bus-pass", "soul-food", "cognac-bottle"];
export const ROOKIE_MENTOR_ID = "dr-fade";
// Existing saved lineups retain their slots; only new crews use the mentor lineup.
export const ROOKIE_MENTOR_CORE_IDS = ["cornball", "plug", "snow-bunny", "wifey", ROOKIE_MENTOR_ID, "rastamon", "all-jokes-roaster", "bus-pass", "soul-food", "cognac-bottle"];
export const ROOKIE_FOUNDATION_IDS = [...new Set([ROOKIE_MENTOR_ID, ...ROOKIE_CORE_IDS, ...ROOKIE_MENTOR_CORE_IDS, ...["waterboy", "shiesty", "torta"].map(id => catalogCardByEngineId[id].catalogId), ...["barber", "bottle", "sneaker", "church", "landlord", "carmeet", "promoter", "nail", "og", "delivery"].map(id => catalogCardByEngineId[id].catalogId)])];

/** Only used for unfinished onboarding; earned cards and completed player crews stay intact. */
export function starterStreetCrew(ids: readonly string[]): string[] {
  const result: string[] = [];
  for (const id of ids) {
    const preferred = STARTER_STREET_REPLACEMENTS[id] ?? id;
    const next = result.includes(preferred) ? ROOKIE_MENTOR_CORE_IDS.find(candidate => !result.includes(candidate) && !ids.includes(candidate)) : preferred;
    if (next) result.push(next);
  }
  for (const id of ROOKIE_MENTOR_CORE_IDS) if (result.length < DECK_SIZE && !result.includes(id)) result.push(id);
  return result.slice(0, DECK_SIZE);
}


export function catalogIdsToEngineIds(catalogIds: string[]): string[] {
  return catalogIds.map((catalogId) => {
    const card = catalogCardById[catalogId];
    if (!card) throw new Error(`Unknown catalog card ${catalogId}`);
    return card.engineId;
  });
}

export function engineIdsToCatalogIds(engineIds: string[]): string[] {
  return engineIds.map((engineId) => {
    const card = catalogCardByEngineId[engineId];
    if (!card) throw new Error(`Unknown engine card ${engineId}`);
    return card.catalogId;
  });
}

/** Expand a previously legal seven-card save using only cards already owned. */
export function upgradeLegacySavedDeck(cardIds: readonly string[], ownedCardIds: readonly string[]): string[] {
  const result = [...cardIds];
  if (result.length !== 7 || new Set(result).size !== 7 || result.some(id => !catalogCardById[id] || !ownedCardIds.includes(id))) return result;
  const candidates = [...new Set(ownedCardIds)].filter(id => catalogCardById[id] && !result.includes(id))
    .sort((a, b) => Number(catalogCardById[b].kind === 'support') - Number(catalogCardById[a].kind === 'support') || catalogCardById[a].cost - catalogCardById[b].cost || a.localeCompare(b));
  return [...result, ...candidates.slice(0, DECK_SIZE - result.length)];
}

export function validateSavedDeck(
  cardIds: string[],
  ownedCardIds: string[],
  heroCardId?: string | null,
): DeckLegality {
  const unknownCardIds = cardIds.filter((id) => !catalogCardById[id]);
  const owned = new Set(ownedCardIds);
  const missingCardIds = cardIds.filter(
    (id) => catalogCardById[id] && !owned.has(id),
  );
  const issues: string[] = [];
  if (cardIds.length !== DECK_SIZE) {
    issues.push(
      cardIds.length < DECK_SIZE
        ? `Add ${DECK_SIZE - cardIds.length} more card${DECK_SIZE - cardIds.length === 1 ? "" : "s"}.`
        : `Remove ${cardIds.length - DECK_SIZE} card${cardIds.length - DECK_SIZE === 1 ? "" : "s"}.`,
    );
  }
  if (new Set(cardIds).size !== cardIds.length) {
    issues.push("A deck can only use one gameplay copy of each card.");
  }
  if (unknownCardIds.length) {
    issues.push("Some saved cards are temporarily unavailable. Your lineup is preserved.");
  }
  if (missingCardIds.length) {
    issues.push(
      `Unlock ${missingCardIds.length} missing card${missingCardIds.length === 1 ? "" : "s"}.`,
    );
  }
  if (!heroCardId) {
    issues.push("Choose a gang hero.");
  } else if (!cardIds.includes(heroCardId)) {
    issues.push("Your gang hero must be one of the ten cards.");
  }
  return {
    valid: issues.length === 0,
    issues,
    missingCardIds,
    unknownCardIds,
  };
}

export const districts = [
  { name: "THE TOWN", rule: "Fire + Dark cards gain +2 Hands.", strategy: "A raw-Hands lane. Contest it with Fire or Dark, or bluff it to pull The Opps away." },
  { name: "GROUP CHAT", rule: "Disruption cards gain +2 Hands.", strategy: "Interaction pays here. Commit when your ability has a real target; abandon it when The Opps are baiting disruption." },
  { name: "SERVER ROOM", rule: "Electric cards gain +3 Hands.", strategy: "The biggest district bonus. Electric threats demand an answer, but stacking here can concede the other two lanes." },
];
