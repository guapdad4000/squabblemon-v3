import type { AbilityUpgradeEffect, Card, CardRarity } from './data';

// The first friends-beta expansion. Every character has an explicit rarity,
// a bounded reveal effect, and the same three-tier training budget.
export const BLOCK_EXPANSION = [
  ['bodegacat', 'bodega-cat', 'Bodega Cat', 'Common', 'Normal', 1, 1, 'Counter Claim', 'If you have no other friendly cards here, gain +1 Hands.', 'Opener'],
  ['crossingguard', 'crossing-guard', 'Crossing Guard', 'Common', 'Light', 2, 3, 'Safe Crossing', 'Protect your lowest-Hands other ally here from one targeted hostile ability.', 'Support'],
  ['laundry', 'laundromat-regular', 'Laundromat Regular', 'Common', 'Water', 2, 3, 'Fresh Cycle', 'Cleanse your lowest-Hands frozen or silenced ally here. If cleansed, give it +1 Hands.', 'Support'],
  ['busker', 'corner-busker', 'Corner Busker', 'Common', 'Air', 2, 1, 'Loose Change', 'Give each of your other 1-Cost cards here +1 Hands.', 'Support'],
  ['cornercoach', 'corner-coach', 'Corner Coach', 'Uncommon', 'Fire', 3, 3, 'Run It Back', 'Give your lowest-Hands other ally here +2 Hands.', 'Support'],
  ['nightcashier', 'night-cashier', 'Night Cashier', 'Common', 'Electric', 2, 2, 'Late Shift', 'On round 4 or later, restore 1 Motion.', 'Tempo'],
  ['dogwalker', 'dog-walker', 'Dog Walker', 'Common', 'Normal', 2, 2, 'Walk the Pack', 'If at least two other friendly cards are here, gain +2 Hands.', 'Pressure'],
  ['mural', 'mural-apprentice', 'Mural Apprentice', 'Uncommon', 'Poison', 2, 2, 'Fresh Color', 'On Reveal: If another friendly card with a different type is here, apply Lock to the highest-Hands enemy here. Otherwise gain +1 Hands.', 'Disruption'],
  ['chessregular', 'chess-regular', 'Chess Regular', 'Common', 'Dark', 3, 3, 'Quiet Fork', 'On Reveal: If exactly one enemy is here, apply 1 Burn. If they have 3 or more Hands, apply 2 Burn instead.', 'Disruption'],
  ['gardener', 'rooftop-gardener', 'Rooftop Gardener', 'Common', 'Plant', 1, 2, 'Plant Bond', 'Ongoing: While Rooftop Gardener is in your hand, your other Plant characters gain +1 Hand at round end.', 'Tempo', 'Plant'],
  ['piratedj', 'pirate-radio-dj', 'Pirate Radio DJ', 'Epic', 'Electric', 3, 2, 'Citywide Signal', 'On Reveal: Give your lowest-Hands ally in each other district +1 Hand. Ongoing: In hand, your other Electric characters gain +1 Hand at round end. On board, your second Electric character played each round gains +1 Hand.', 'Support', 'Electric'],
  ['dancecaptain', 'dance-circle-captain', 'Dance Circle Captain', 'Rare', 'Fire', 3, 3, 'Whole Block Moving', 'If you have a friendly card in all three districts, gain +3 Hands.', 'Pressure'],
  ['nightmedic', 'night-shift-medic', 'Night Shift Medic', 'Epic', 'Light', 3, 4, 'All Clear', 'On Reveal: Cleanse Freeze, Silence, Burn, Weaken, and Lock from every other ally here. Give your weakest other Light character here +1 Hand, even if healthy. Ongoing: While on board, the first Light character you cleanse each round gains +2 Hands.', 'Support'],
  ['subwaymagician', 'subway-magician', 'Subway Magician', 'Rare', 'Dark', 4, 3, 'Now You See Me', 'On Reveal: Apply Weaken to the highest-Hands enemy here, then move to your weakest other district.', 'Movement'],
  ['ogdominican', 'og-dominican', 'OG Dominican', 'Rare', 'Air', 3, 4, 'Block Shortcut', 'Move to your weakest other district. If moved, gain +2 Hands.', 'Movement'],
  ['conductor', 'last-train-conductor', 'Last Train Conductor', 'Mythical', 'Water', 4, 3, 'Last Stop', 'Move your lowest-Hands other ally here to your weakest other district. If moved, Cleanse it and give it +2 Hands, or +3 if it is Water.', 'Movement'],
  ['midnightmayor', 'midnight-mayor', 'Midnight Mayor', 'Mythical', 'Dark', 3, 2, 'Keys to the City', 'Gain +1 Hands for each different friendly card type here, up to +3.', 'Pressure'],
  ['bigzoey', 'big-zoey', 'Big Zoey', 'Legendary', 'Earth', 3, 3, 'Hold the Block', 'Give your lowest-Hands other ally here +2 Hands and the lowest-Hands enemy here -2 Hands.', 'Disruption'],
  ['leroy', 'leroy', 'Leroy', 'Mythical', 'Light', 3, 4, 'Golden Glow', 'On Reveal: Confiscate up to 4 removable bonus Hands from the enemy here with the most bonus, then hit that enemy for 2; with no bonus target, hit the strongest enemy here for 2. If your board has at least three friendly elements, gain +3 Hands and Protection. Confiscation never takes printed Hands or creates healing credit. Protection and immunity block the hostile package.', 'Disruption'],
  ['partytitan', 'block-party-titan', 'Block Party Titan', 'Mythical', 'Earth', 6, 7, 'Everybody Outside', 'Give your weakest other friendly card in each district +1 Hand.', 'Support'],
] as const;

export const expansionUpgradeEffects: Record<string, readonly AbilityUpgradeEffect[]> = Object.fromEntries(
  BLOCK_EXPANSION.map(([id]) => [id, [0, 1, 2].map(() => ({kind: 'self-power' as const, amount: 1 as const, trigger: 'base-success' as const}))]),
);
export const expansionRarities: Record<string, CardRarity> = Object.fromEntries(BLOCK_EXPANSION.map(([id, , , rarity]) => [id, rarity]));
export const expansionCards: Record<string, Card> = Object.fromEntries(BLOCK_EXPANSION.map(
  ([engineId, id, name, , type, cost, power, ability, effect, role, elementalBond]) => [engineId, {
    id, name, type, cost, power, ability,
    effect: /^(On Reveal|Ongoing):/.test(effect) ? effect : `On Reveal: ${effect}`,
    kind: 'character', roles: [role],
    ...(elementalBond ? { elementalBond } : {}),
    abilityUpgrades: [2, 5, 8].map((unlockLevel, index) => ({
      id: `${engineId}:upgrade:${index + 1}`, name: `${ability} ${['Practice', 'Confidence', 'Mastery'][index]}`,
      description: elementalBond && effect.startsWith('Ongoing:')
        ? 'While this card is in your hand, one bonded ally gains an additional +1 Hand at round end.'
        : engineId === 'leroy'
          ? 'Once per match, after the base ability succeeds, this card gains +1 Hand.'
          : 'After the base ability succeeds, this card gains +1 Hands.',
      unlockLevel, effect: expansionUpgradeEffects[engineId][index],
    })),
  }],
));
