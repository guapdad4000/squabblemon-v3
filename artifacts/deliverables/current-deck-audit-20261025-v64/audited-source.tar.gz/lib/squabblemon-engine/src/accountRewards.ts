import type { CardRarity } from './data';
import type { StyleShardRarity } from './styleShards';

export type AccountReward = {
  softCurrency: number;
  packTickets: number;
  styleShards: number;
};
export const LOGIN_REWARDS: readonly AccountReward[] = [
  50, 75, 100, 125, 150, 200, 300,
].map((softCurrency, i) => ({
  softCurrency,
  packTickets: i === 6 ? 2 : 0,
  styleShards: i === 6 ? 25 : 0,
}));
export const NEW_PLAYER_BONUS: AccountReward = {
  softCurrency: 250,
  packTickets: 3,
  styleShards: 0,
};
export const FIRST_LOGIN_BONUS: AccountReward = {
  softCurrency: 100,
  packTickets: 1,
  styleShards: 0,
};
export const LEVEL_MILESTONE_REWARD: AccountReward = {
  softCurrency: 250,
  packTickets: 1,
  styleShards: 50,
};
export type AccountRewardGrant = AccountReward & {
  key: string;
  title: string;
  cardId?: string;
  cardName?: string;
  cardRarity?: CardRarity;
  isNewCard?: boolean;
  /** Matching shards from an exhausted monthly rarity pool; omitted means Universal. */
  shardRarity?: StyleShardRarity;
  monthlyDay?: number;
  streak?: number;
  date?: string;
};
export type AccountRewardStatus = {
  date: string;
  streak: number;
  claimedToday: boolean;
  nextResetAt: string;
  pending: AccountRewardGrant[];
  growth: GrowthLabStatus;
  monthly: MonthlyLoginStatus;
};
/** Extra free gameplay cards; the existing seven-day currency track is unchanged. */
export const MONTHLY_LOGIN_MILESTONES = [
  { day: 1, rarity: 'SuperCommon', label: 'Super Common' },
  { day: 5, rarity: 'Common', label: 'Common' },
  { day: 10, rarity: 'Uncommon', label: 'Uncommon' },
  { day: 15, rarity: 'Rare', label: 'Rare' },
  { day: 20, rarity: 'Epic', label: 'Super Rare' },
  { day: 25, rarity: 'Legendary', label: 'Legendary' },
  { day: 30, rarity: 'Mythical', label: 'Mythical' },
] as const satisfies readonly { day: number; rarity: CardRarity; label: string }[];
export type MonthlyLoginStatus = {
  month: string;
  claimedDays: number;
  requiredDays: number;
  claimedToday: boolean;
  nextResetAt: string;
  milestones: {
    key: string;
    day: number;
    rarity: CardRarity;
    label: string;
    /** Ready includes today's still-unclaimed check-in. */
    ready: boolean;
    reward: AccountRewardGrant | null;
  }[];
};
/** Count distinct saved UTC check-ins, never browser dates or consecutive-day streaks. */
export function monthlyLoginStatus(receipts: AccountRewardGrant[], now = new Date()): MonthlyLoginStatus {
  const date = now.toISOString().slice(0, 10), month = date.slice(0, 7);
  const nextMonth = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth() + 1, 1));
  const requiredDays = Math.min(30, new Date(nextMonth.getTime() - 86400000).getUTCDate());
  const dates = new Set(receipts.filter(reward => reward.date && reward.key === `login:${reward.date}` && reward.date.startsWith(`${month}-`) && reward.date <= date).map(reward => reward.date!));
  const claimedToday = dates.has(date), claimedDays = Math.min(requiredDays, dates.size);
  const availableDays = Math.min(requiredDays, claimedDays + Number(!claimedToday));
  return {
    month, claimedDays, requiredDays, claimedToday, nextResetAt: nextMonth.toISOString(),
    milestones: MONTHLY_LOGIN_MILESTONES.map(milestone => {
      const key = `monthly-login:${month}:${milestone.rarity}`;
      const day = Math.min(milestone.day, requiredDays);
      const reward = receipts.find(receipt => receipt.key === key) ?? null;
      return { ...milestone, key, day, ready: !reward && availableDays >= day, reward };
    }),
  };
}
export const GROWTH_GARDEN_SIZE = 7;
export const GROWTH_GARDEN_REWARD: AccountReward = { softCurrency: 350, packTickets: 1, styleShards: 25 };
export const GROWTH_TASKS = [
  { key: 'login', title: 'Show your plants some love', detail: 'Collect your daily check-in.', action: 'Check in' },
  { key: 'daily-show-up', title: 'Put down roots', detail: 'Finish one fade today.', action: 'Play a fade' },
  { key: 'daily-take-room', title: 'Find your sunshine', detail: 'Win one fade today.', action: 'Play a fade' },
] as const;
export const GROWTH_BUDDY_CYCLES = 3;
export const GROWTH_ROTATING_TASKS = [
 {key:'training',title:'Practice makes roots',detail:'Finish a training fade.',action:'Train',href:'/game/training',goal:1},
 {key:'training-win',title:'Soak up the sunshine',detail:'Win a training fade.',action:'Train',href:'/game/training',goal:1},
 {key:'story-win',title:'Branch into the story',detail:'Win a story fade.',action:'Story',href:'/game/story',goal:1},
 {key:'fire-win',title:'Warm the greenhouse',detail:'Win after playing a Fire card.',action:'Train',href:'/game/training',goal:1},
 {key:'support-win',title:'Help the garden thrive',detail:'Win after playing a Support card.',action:'Train',href:'/game/training',goal:1},
 {key:'sweep-win',title:'Room to bloom',detail:'Win all three districts.',action:'Train',href:'/game/training',goal:1},
] as const;
export function growthTasksForDate(now=new Date()){
 const day=Math.floor(now.getTime()/86400000);
 const base=GROWTH_TASKS.map(t=>({...t,href:t.key==='login'?'':'/game/play',goal:1}));
 const plans=[base,[base[0],GROWTH_ROTATING_TASKS[0],GROWTH_ROTATING_TASKS[1]],[base[0],GROWTH_ROTATING_TASKS[2],GROWTH_ROTATING_TASKS[4]],[base[0],GROWTH_ROTATING_TASKS[0],GROWTH_ROTATING_TASKS[3]],[base[0],GROWTH_ROTATING_TASKS[1],GROWTH_ROTATING_TASKS[5]]];
 return plans[day%plans.length];
}
export type GrowthLabMission = { missionKey: string; progress: number; goal: number; resetAt: Date | string | null };
export type GrowthLabStatus = {
  tasks: { key: string; title: string; detail: string; action: string; href: string; progress: number; goal: number; complete: boolean }[];
  water: number;
  ready: boolean;
  wateredToday: boolean;
  totalPlants: number;
  plantsInGarden: number;
  gardenNumber: number;
  completedGardens: number;
};
/** Only server receipts and unexpired, verified mission progress grow the garden. */
export function growthLabStatus(receipts: AccountRewardGrant[], missions: GrowthLabMission[], now = new Date(), daily:unknown={}): GrowthLabStatus {
  const date = now.toISOString().slice(0, 10);
  const keys = new Set(receipts.filter(r => !r.date || r.date <= date).map(r => r.key));
  const wateredToday = keys.has(`growth:water:${date}`);
  const counters=daily&&typeof daily==='object'&&'date' in daily&&daily.date===date&&'counters' in daily?daily.counters as Record<string,number>:{};
  const tasks = growthTasksForDate(now).map(task => {
    const mission = missions.find(m => m.missionKey === task.key);
    const goal = Math.max(1, mission?.goal ?? task.goal);
    const current = mission?.resetAt && new Date(mission.resetAt).getTime() > now.getTime();
    const progress = task.key === 'login' ? Number(keys.has(`login:${date}`)) : mission ? current ? Math.max(0, Math.min(goal, mission.progress)) : 0 : Math.max(0,Math.min(goal,Number(counters?.[task.key])||0));
    return { ...task, progress, goal, complete: progress >= goal };
  });
  const totalPlants = [...keys].filter(key => key.startsWith('growth:water:')).length;
  return {
    tasks, wateredToday, totalPlants,
    water: wateredToday ? 0 : tasks.reduce((sum, task) => sum + task.progress / task.goal, 0) / tasks.length,
    ready: !wateredToday && tasks.every(task => task.complete),
    plantsInGarden: totalPlants ? (totalPlants - 1) % GROWTH_GARDEN_SIZE + 1 : 0,
    gardenNumber: Math.floor(Math.max(0, totalPlants - 1) / GROWTH_GARDEN_SIZE) + 1,
    completedGardens: Math.floor(totalPlants / GROWTH_GARDEN_SIZE),
  };
}
export function accountRewardStatus(
  level: number,
  createdAt: Date,
  receipts: AccountRewardGrant[],
  now = new Date(),
  missions: GrowthLabMission[] = [],
  growthDaily:unknown={},
): AccountRewardStatus {
  const date = now.toISOString().slice(0, 10);
  const yesterday = new Date(now.getTime() - 86400000)
    .toISOString()
    .slice(0, 10);
  const daily = receipts
    .filter((r) => r.key.startsWith("login:") && r.date && r.date <= date)
    .sort((a, b) => b.date!.localeCompare(a.date!));
  const latest = daily[0];
  const claimedToday = latest?.date === date;
  const streak = claimedToday
    ? (latest.streak ?? 1)
    : latest?.date === yesterday
      ? (latest.streak ?? 1) + 1
      : 1;
  const keys = new Set(receipts.map((r) => r.key));
  const pending: AccountRewardGrant[] = [];
  if (!claimedToday)
    pending.push({
      key: `login:${date}`,
      title: `Day ${streak} login reward`,
      date,
      streak,
      ...LOGIN_REWARDS[(streak - 1) % 7],
    });
  if (!keys.has("first-login"))
    pending.push({
      key: "first-login",
      title: "First check-in bonus",
      ...FIRST_LOGIN_BONUS,
    });
  if (
    !keys.has("new-player") &&
    now.getTime() - createdAt.getTime() <= 7 * 86400000
  )
    pending.push({
      key: "new-player",
      title: "Welcome to the block",
      ...NEW_PLAYER_BONUS,
    });
  for (let milestone = 10; milestone <= level; milestone += 10) {
    const key = `level:${milestone}`;
    if (!keys.has(key))
      pending.push({
        key,
        title: `Level ${milestone} milestone`,
        ...LEVEL_MILESTONE_REWARD,
      });
  }
  if(growthLabStatus(receipts,missions,now,growthDaily).completedGardens>=GROWTH_BUDDY_CYCLES&&!keys.has('growth:buddy'))pending.push({key:'growth:buddy',title:'Buddy joins your crew',cardId:'buddy',softCurrency:0,packTickets:0,styleShards:0});
  const monthly = monthlyLoginStatus(receipts, now);
  for (const milestone of monthly.milestones) {
    if (milestone.ready) pending.push({
      key: milestone.key, title: `Monthly ${milestone.label} card`, date,
      cardRarity: milestone.rarity, monthlyDay: milestone.day,
      softCurrency: 0, packTickets: 0, styleShards: 0,
    });
  }
  const nextResetAt = new Date(`${date}T00:00:00Z`);
  nextResetAt.setUTCDate(nextResetAt.getUTCDate() + 1);
  return {
    date,
    streak,
    claimedToday,
    nextResetAt: nextResetAt.toISOString(),
    pending,
    monthly,
    growth: growthLabStatus(receipts, missions, now,growthDaily),
  };
}
export const STOCKZ_TICKERS = [
  { id: "DURG", name: "Durag Dynamics", price: 120 },
  { id: "SNKR", name: "Sneaker Supply", price: 85 },
  { id: "BODE", name: "Bodega Brands", price: 60 },
] as const;
export const STOCKZ_STAKES = [10, 25, 50, 100] as const;
export const STOCKZ_DAILY_LIMIT = 5;
export type StockzBet = {
  id: string;
  ticker: string;
  direction: "up" | "down";
  stake: number;
  openPrice: number;
  closePrice: number;
  startedAt: string;
  closesAt: string;
  date: string;
};
export type StockzRound = Omit<StockzBet, "closePrice"> & {
  closePrice?: number;
  payout?: number;
};
export type StockzState = {
  roundsToday: number;
  active: StockzRound | null;
  recent: StockzRound[];
};
